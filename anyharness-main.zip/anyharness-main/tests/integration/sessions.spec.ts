// Owner: harness-test-engineer
// Sessions + steering log flow exercised at the handler boundary (no MCP
// transport). Covers the full lifecycle and the steering recurrence
// heuristic that powers harness.steer.suggest.

import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import {
  handleSessionAppend,
  handleSessionGet,
  handleSessionStart,
  recordSteeringEvent,
} from '../../src/sessions/index.js';
import { suggestSteering } from '../../src/steering/suggest.js';
import { harnessPaths, type HarnessPaths } from '../../src/storage/paths.js';
import type { SessionEvent } from '../../src/shared/schemas/session-event.js';
import type { SteeringEvent } from '../../src/shared/schemas/steering-event.js';
import { makeTempHarness, type TempHarness } from '../mocks/harness-tmp.js';

describe('sessions lifecycle + steering log', () => {
  let tmp: TempHarness;
  let paths: HarnessPaths;

  beforeEach(async () => {
    tmp = await makeTempHarness();
    paths = harnessPaths(tmp.harnessRoot);
  });

  afterEach(async () => {
    await tmp.cleanup();
  });

  it('starts a session and returns a session_id + ISO timestamp', async () => {
    const out = await handleSessionStart(paths, {
      workflow: 'PREVC',
    });
    expect(out.session_id).toMatch(/[0-9a-f-]{36}/);
    expect(() => new Date(out.startedAt).toISOString()).not.toThrow();
    expect(Number.isNaN(Date.parse(out.startedAt))).toBe(false);
  });

  it('appends 5 events and reads them back in order', async () => {
    const start = await handleSessionStart(paths, {});
    const sid = start.session_id;
    const baseTs = Date.parse('2025-01-01T00:00:00Z');

    const events: SessionEvent[] = [
      {
        timestamp: new Date(baseTs).toISOString(),
        kind: 'tool_call',
        tool: 'sensor_run',
        args: { id: 'tsc' },
      },
      {
        timestamp: new Date(baseTs + 1000).toISOString(),
        kind: 'sensor_run',
        sensor: 'tsc',
        passed: true,
        violationCount: 0,
        regulation: 'maintainability',
      },
      {
        timestamp: new Date(baseTs + 2000).toISOString(),
        kind: 'decision',
        what: 'continue',
        rationale: 'tsc clean',
      },
      {
        timestamp: new Date(baseTs + 3000).toISOString(),
        kind: 'judge_review',
        rubric: 'spec-adherence',
        passed: true,
        violationCount: 0,
      },
      {
        timestamp: new Date(baseTs + 4000).toISOString(),
        kind: 'task_completed',
        task_id: 'task-001',
      },
    ];

    for (const [i, ev] of events.entries()) {
      const result = await handleSessionAppend(paths, {
        session_id: sid,
        event: ev,
      });
      expect(result.appended).toBe(true);
      expect(result.eventCount).toBe(i + 1);
    }

    const got = await handleSessionGet(paths, { session_id: sid });
    expect(got.header.session_id).toBe(sid);
    expect(got.events).toHaveLength(events.length);
    expect(got.events.map((e) => e.kind)).toEqual([
      'tool_call',
      'sensor_run',
      'decision',
      'judge_review',
      'task_completed',
    ]);
    expect(got.events.map((e) => e.timestamp)).toEqual(
      events.map((e) => e.timestamp),
    );
  });

  it('promotes recurring sensor failures to a `new-rule` steering suggestion', async () => {
    const sensorEvent = (
      idx: number,
      what: string,
    ): SteeringEvent => ({
      timestamp: new Date(Date.now() - idx * 1000).toISOString(),
      kind: 'sensor',
      id: 'eslint',
      target: `src/file-${idx}.ts`,
      regulation: 'maintainability',
      passed: false,
      inconclusive: false,
      violationCount: 1,
      violations: [
        {
          severity: 'error',
          what,
          why: 'rule recurred',
          remediation: 'fix it',
          filesAffected: [`src/file-${idx}.ts`],
          linesAffected: [],
        },
      ],
    });

    // Three recurrences with three distinct `what` values trips the
    // SENSOR_DISTINCT_WHATS_MIN + SENSOR_TOTAL_OCCURRENCES_MIN thresholds.
    await recordSteeringEvent(paths, sensorEvent(1, 'no-unused-vars'));
    await recordSteeringEvent(paths, sensorEvent(2, 'no-explicit-any'));
    await recordSteeringEvent(paths, sensorEvent(3, 'prefer-const'));

    const result = await suggestSteering(paths, { windowDays: 30 });
    expect(result.eventCountAnalyzed).toBe(3);
    const newRules = result.suggestions.filter((s) => s.kind === 'new-rule');
    expect(newRules).toHaveLength(1);
    const evidence = newRules[0]?.evidence as { sensorId: string; totalFlags: number };
    expect(evidence.sensorId).toBe('eslint');
    expect(evidence.totalFlags).toBe(3);
  });
});
