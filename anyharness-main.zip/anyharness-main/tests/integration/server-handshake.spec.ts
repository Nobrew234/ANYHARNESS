// Owner: harness-test-engineer
// End-to-end MCP handshake: spawn the server stdio binary in a child process,
// drive it through `@modelcontextprotocol/sdk` Client, validate the surface
// (server info, tools/list, resources/list, prompts/list).

import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = path.resolve(__dirname, '..', '..');

interface Handle {
  client: Client;
  transport: StdioClientTransport;
}

async function spawnClient(harnessRoot: string): Promise<Handle> {
  const tsxBin = path.join(REPO_ROOT, 'node_modules', '.bin', 'tsx');
  const transport = new StdioClientTransport({
    command: tsxBin,
    args: [path.join(REPO_ROOT, 'src', 'bin.ts')],
    env: {
      ...(process.env as Record<string, string>),
      HARNESS_ROOT: harnessRoot,
    },
    cwd: REPO_ROOT,
    stderr: 'pipe',
  });
  const client = new Client(
    { name: 'harness-test-client', version: '0.0.0' },
    { capabilities: {} },
  );
  await client.connect(transport);
  return { client, transport };
}

describe('MCP server handshake', () => {
  let handle: Handle;

  beforeAll(async () => {
    // Use the project's own .harness/ — it ships with the canonical templates
    // (3 sensors, 1 judge, 1 spec, 2 workflows) the server is meant to
    // surface.
    handle = await spawnClient(path.join(REPO_ROOT, '.harness'));
  }, 30_000);

  afterAll(async () => {
    if (handle) {
      await handle.client.close();
      await handle.transport.close();
    }
  });

  it('returns server info on initialize', () => {
    const version = handle.client.getServerVersion();
    expect(version).toBeDefined();
    expect(version?.name).toBe('anyharness');
  });

  it('advertises the MVP tool surface (>=13 tools)', async () => {
    const result = await handle.client.listTools();
    expect(result.tools.length).toBeGreaterThanOrEqual(13);
    const names = new Set(result.tools.map((t) => t.name));
    for (const expected of [
      'sensor_list',
      'sensor_run',
      'sensor_register',
      'judge_list',
      'judge_review',
      'judge_record',
      'session_start',
      'session_append',
      'session_get',
      'contract_spec_validate',
      'contract_task_next',
      'contract_task_complete',
      'harness_steer_suggest',
    ]) {
      expect(names.has(expected), `missing tool '${expected}'`).toBe(true);
    }
  });

  it('advertises resources from .harness/ templates (>=3)', async () => {
    const result = await handle.client.listResources();
    expect(result.resources.length).toBeGreaterThanOrEqual(3);
    const uris = result.resources.map((r) => r.uri);
    // Expected from the seeded .harness/: 1 spec + 2 workflows.
    expect(uris).toContain('harness://contracts/specs/example-signup');
    expect(uris).toContain('harness://workflows/PREVC');
    expect(uris).toContain('harness://workflows/bug-fix');
  });

  it('advertises the two MVP workflow prompts', async () => {
    const result = await handle.client.listPrompts();
    expect(result.prompts.length).toBe(2);
    const names = new Set(result.prompts.map((p) => p.name));
    expect(names.has('workflow.PREVC')).toBe(true);
    expect(names.has('workflow.bug-fix')).toBe(true);
  });
});
