// Owner: harness-test-engineer
// Phase 2 two-phase judge flow: judge.review + judge.record handlers,
// exercised directly (no MCP transport). Verifies the SPEC §15.6 contract
// that the server never calls an LLM, returns the envelope the client needs,
// and only emits a SteeringEvent when judge.record is called.
//
// All tests run without ANTHROPIC_API_KEY — its absence should be invisible.

import * as fs from 'node:fs/promises';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import {
  handleJudgeList,
  handleJudgeReview,
  handleJudgeRecord,
} from '../../src/judges/index.js';
import { harnessPaths, type HarnessPaths } from '../../src/storage/paths.js';
import { readSteeringLog } from '../../src/sessions/steering-log.js';
import { makeTempHarness, type TempHarness } from '../mocks/harness-tmp.js';

// ---------------------------------------------------------------------------
// Shared rubric fixtures
// ---------------------------------------------------------------------------

const SPEC_ADHERENCE_BODY = `---
id: spec-adherence
regulation: behaviour
description: Checks spec adherence
---

Review the artifact against the spec.

## Artifact
<<<TARGET>>>

## Spec
<<<SPEC>>>

## Schema
<<<SCHEMA>>>
`;

const SPEC_ADHERENCE_SCHEMA = {
  $schema: 'http://json-schema.org/draft-07/schema#',
  type: 'object',
  required: ['tool', 'regulation', 'passed', 'summary', 'violations'],
  additionalProperties: false,
  properties: {
    tool: { type: 'string', const: 'spec-adherence' },
    regulation: { type: 'string', const: 'behaviour' },
    passed: { type: 'boolean' },
    summary: { type: 'string', minLength: 1 },
    inconclusive: { type: 'boolean' },
    inconclusiveReason: { type: 'string' },
    violations: { type: 'array', items: { type: 'object' } },
  },
};

const SIMPLE_RUBRIC_BODY = `---
id: simple-rubric
regulation: maintainability
description: A simple rubric for testing
---

Evaluate the target for maintainability.

## Target
<<<TARGET>>>
`;

// No schema file — schema-less rubric.

// ---------------------------------------------------------------------------
// Suite
// ---------------------------------------------------------------------------

describe('judge.list / judge.review / judge.record — phase 2 two-phase flow', () => {
  let tmp: TempHarness;
  let paths: HarnessPaths;

  beforeEach(async () => {
    tmp = await makeTempHarness({
      judges: [
        {
          rubricId: 'spec-adherence',
          body: SPEC_ADHERENCE_BODY,
          schema: SPEC_ADHERENCE_SCHEMA,
        },
        {
          rubricId: 'simple-rubric',
          body: SIMPLE_RUBRIC_BODY,
          // no schema
        },
      ],
    });
    paths = harnessPaths(tmp.harnessRoot);
  });

  afterEach(async () => {
    await tmp.cleanup();
  });

  // ------------------------------------------------------------------
  // judge.list
  // ------------------------------------------------------------------

  it('judge.list enumerates rubrics from .harness/judges/', async () => {
    const out = await handleJudgeList(paths, {});
    expect(out.rubrics).toHaveLength(2);
    const ids = out.rubrics.map((r) => r.rubric_id).sort();
    expect(ids).toEqual(['simple-rubric', 'spec-adherence']);
  });

  it('judge.list filters by rubric id', async () => {
    const out = await handleJudgeList(paths, { rubric: 'spec-adherence' });
    expect(out.rubrics).toHaveLength(1);
    expect(out.rubrics[0]?.rubric_id).toBe('spec-adherence');
    expect(out.rubrics[0]?.regulation).toBe('behaviour');
  });

  it('judge.list rejects retired model/budget rubric frontmatter keys', async () => {
    await fs.writeFile(
      `${paths.judges}/legacy-rubric.md`,
      `---
id: legacy-rubric
regulation: behaviour
description: Legacy rubric
model: claude-legacy
budget: 1000
---

Evaluate the target.
`,
      'utf8',
    );

    await expect(handleJudgeList(paths, {})).rejects.toThrow(/model|budget/);
  });

  // ------------------------------------------------------------------
  // judge.review — phase 1: returns envelope, never calls LLM
  // ------------------------------------------------------------------

  it('judge.review returns instructions+schema+context+submission without calling any LLM', async () => {
    // Deliberately clear ANTHROPIC_API_KEY to prove the server does not need it.
    const origKey = process.env['ANTHROPIC_API_KEY'];
    delete process.env['ANTHROPIC_API_KEY'];

    try {
      const out = await handleJudgeReview(paths, {
        rubric_id: 'spec-adherence',
        target: 'function signUp() { return 200; }',
      });

      // Shape checks
      expect(out.rubric_id).toBe('spec-adherence');
      expect(out.regulation).toBe('behaviour');
      expect(typeof out.instructions).toBe('string');
      expect(out.instructions.length).toBeGreaterThan(0);
      // instructions should have TARGET substituted in
      expect(out.instructions).toContain('function signUp()');
      expect(out.schema).toBeDefined();
      expect(out.context.target).toBe('function signUp() { return 200; }');
      expect(out.submission.tool).toBe('judge_record');
      expect(out.submission.correlation.rubric_id).toBe('spec-adherence');
      expect(out.submission.correlation.target).toBe('function signUp() { return 200; }');
    } finally {
      if (origKey !== undefined) process.env['ANTHROPIC_API_KEY'] = origKey;
    }
  });

  it('judge.review does NOT emit a SteeringEvent', async () => {
    // Read log length before
    const before = await readSteeringLog(paths);

    await handleJudgeReview(paths, {
      rubric_id: 'simple-rubric',
      target: 'const x = 1;',
    });

    const after = await readSteeringLog(paths);
    // Log must not have grown
    expect(after.length).toBe(before.length);
  });

  it('judge.review with spec_id includes spec content in context and instructions', async () => {
    // Write a spec file the handler can resolve
    const specBody = `id: test-spec\ntitle: Test\nacceptanceCriteria:\n  - Returns 200\nchecks: []\ntasks: []\n`;
    await fs.writeFile(
      paths.contracts.specs + '/test-spec.yaml',
      specBody,
      'utf8',
    );

    const out = await handleJudgeReview(paths, {
      rubric_id: 'spec-adherence',
      target: 'const handler = () => 200;',
      spec_id: 'test-spec',
    });

    expect(out.context.spec).toBeDefined();
    expect(out.context.spec).toContain('Returns 200');
    // instructions should contain spec content where <<<SPEC>>> was
    expect(out.instructions).toContain('Returns 200');
  });

  it('judge.review throws RubricNotFoundError for unknown rubric id', async () => {
    await expect(
      handleJudgeReview(paths, {
        rubric_id: 'nonexistent-rubric',
        target: 'some code',
      }),
    ).rejects.toThrow(/rubric 'nonexistent-rubric' not found/);
  });

  // ------------------------------------------------------------------
  // judge.record — phase 2: validate verdict, normalize, log
  // ------------------------------------------------------------------

  it('judge.record with valid result returns §9 envelope and emits SteeringEvent', async () => {
    const validResult = {
      tool: 'spec-adherence',
      regulation: 'behaviour',
      passed: true,
      summary: 'Artifact satisfies the spec.',
      inconclusive: false,
      violations: [],
    };

    const out = await handleJudgeRecord(paths, {
      rubric_id: 'spec-adherence',
      target: 'function signUp() { return 200; }',
      result: validResult,
    });

    // §9 envelope fields
    expect(out.tool).toBe('spec-adherence');
    expect(out.regulation).toBe('behaviour');
    expect(out.passed).toBe(true);
    expect(out.summary).toBe('Artifact satisfies the spec.');
    expect(out.inconclusive).toBe(false);
    expect(out.violations).toEqual([]);
    // No validation errors on valid result
    expect(out.validationErrors).toBeUndefined();

    // SteeringEvent must have been written
    const events = await readSteeringLog(paths);
    expect(events).toHaveLength(1);
    expect(events[0]?.kind).toBe('judge');
    expect(events[0]?.id).toBe('spec-adherence');
    expect(events[0]?.passed).toBe(true);
    expect(events[0]?.inconclusive).toBe(false);
  });

  it('judge.record with failing result emits SteeringEvent with passed=false', async () => {
    const failingResult = {
      tool: 'spec-adherence',
      regulation: 'behaviour',
      passed: false,
      summary: 'Spec criterion #1 not implemented.',
      inconclusive: false,
      violations: [
        {
          severity: 'error',
          what: 'Missing POST /auth/signup handler',
          why: 'Spec criterion #1',
          remediation: 'Add the handler',
          filesAffected: [],
          linesAffected: [],
        },
      ],
    };

    const out = await handleJudgeRecord(paths, {
      rubric_id: 'spec-adherence',
      target: 'const placeholder = true;',
      result: failingResult,
    });

    expect(out.passed).toBe(false);
    expect(out.violations).toHaveLength(1);
    expect(out.validationErrors).toBeUndefined();

    const events = await readSteeringLog(paths);
    expect(events).toHaveLength(1);
    expect(events[0]?.passed).toBe(false);
    expect(events[0]?.violationCount).toBe(1);
  });

  it('judge.record with schema-invalid result returns inconclusive envelope and still emits SteeringEvent', async () => {
    // `passed` is a boolean per SensorOutput zod schema — passing a string
    // fails zod validation.
    const invalidResult = {
      tool: 'spec-adherence',
      regulation: 'behaviour',
      passed: 'yes-it-passes', // wrong type — should be boolean
      summary: 'all good',
      violations: [],
    };

    const out = await handleJudgeRecord(paths, {
      rubric_id: 'spec-adherence',
      target: 'const x = 1;',
      result: invalidResult,
    });

    expect(out.passed).toBe(false);
    expect(out.inconclusive).toBe(true);
    expect(out.inconclusiveReason).toBe('result_failed_schema_validation');
    expect(Array.isArray(out.validationErrors)).toBe(true);
    expect((out.validationErrors ?? []).length).toBeGreaterThan(0);
    // The validation error should mention the `passed` field
    const errPaths = (out.validationErrors ?? []).map((e) => e.path);
    expect(errPaths).toContain('passed');

    // Even schema-invalid records produce a SteeringEvent (audit trail).
    // The handler logs every judge.record call including invalid ones.
    const events = await readSteeringLog(paths);
    expect(events).toHaveLength(1);
    expect(events[0]?.inconclusive).toBe(true);
  });

  it('judge.record with missing required field (summary) returns inconclusive', async () => {
    const missingRequired = {
      tool: 'spec-adherence',
      regulation: 'behaviour',
      passed: false,
      // summary missing
      violations: [],
    };

    const out = await handleJudgeRecord(paths, {
      rubric_id: 'spec-adherence',
      target: 'const x = 1;',
      result: missingRequired,
    });

    expect(out.inconclusive).toBe(true);
    expect(out.inconclusiveReason).toBe('result_failed_schema_validation');
    expect((out.validationErrors ?? []).some((e) => e.path === 'summary')).toBe(true);
  });

  it('judge.record injects tool/regulation identity when client omits them', async () => {
    // Client sends a minimal result without tool/regulation — server should
    // coerce them from the rubric.
    const minimalResult = {
      passed: true,
      summary: 'All good.',
      violations: [],
    };

    const out = await handleJudgeRecord(paths, {
      rubric_id: 'simple-rubric',
      target: 'const x = 1;',
      result: minimalResult,
    });

    expect(out.tool).toBe('simple-rubric');
    expect(out.regulation).toBe('maintainability');
    expect(out.passed).toBe(true);
    expect(out.inconclusive).toBe(false);
  });

  it('judge.record with rubric const violation (tool mismatch) returns inconclusive', async () => {
    // spec-adherence schema requires tool === "spec-adherence" via const.
    // Sending a different tool name should fail the const check.
    const wrongTool = {
      tool: 'wrong-tool-name',
      regulation: 'behaviour',
      passed: true,
      summary: 'Passes.',
      violations: [],
    };

    const out = await handleJudgeRecord(paths, {
      rubric_id: 'spec-adherence',
      target: 'const x = 1;',
      result: wrongTool,
    });

    expect(out.inconclusive).toBe(true);
    expect(out.inconclusiveReason).toBe('result_failed_schema_validation');
    const errPaths = (out.validationErrors ?? []).map((e) => e.path);
    expect(errPaths).toContain('tool');
  });

  // ------------------------------------------------------------------
  // judge.review vs judge.record: SteeringEvent emission asymmetry
  // ------------------------------------------------------------------

  it('only judge.record emits SteeringEvent — judge.review followed by judge.record produces exactly 1 event', async () => {
    // Phase 1: review
    await handleJudgeReview(paths, {
      rubric_id: 'simple-rubric',
      target: 'const x = 1;',
    });
    const afterReview = await readSteeringLog(paths);
    expect(afterReview).toHaveLength(0);

    // Phase 2: record
    await handleJudgeRecord(paths, {
      rubric_id: 'simple-rubric',
      target: 'const x = 1;',
      result: {
        tool: 'simple-rubric',
        regulation: 'maintainability',
        passed: true,
        summary: 'Clean.',
        violations: [],
      },
    });
    const afterRecord = await readSteeringLog(paths);
    expect(afterRecord).toHaveLength(1);
  });

  // ------------------------------------------------------------------
  // No ANTHROPIC_API_KEY requirement
  // ------------------------------------------------------------------

  it('all judge handlers work when ANTHROPIC_API_KEY is absent', async () => {
    const origKey = process.env['ANTHROPIC_API_KEY'];
    delete process.env['ANTHROPIC_API_KEY'];

    try {
      // list
      const listOut = await handleJudgeList(paths, {});
      expect(listOut.rubrics.length).toBeGreaterThan(0);

      // review
      const reviewOut = await handleJudgeReview(paths, {
        rubric_id: 'simple-rubric',
        target: 'const y = 2;',
      });
      expect(reviewOut.instructions).toBeTruthy();

      // record
      const recordOut = await handleJudgeRecord(paths, {
        rubric_id: 'simple-rubric',
        target: 'const y = 2;',
        result: {
          tool: 'simple-rubric',
          regulation: 'maintainability',
          passed: true,
          summary: 'OK.',
          violations: [],
        },
      });
      expect(recordOut.passed).toBe(true);
    } finally {
      if (origKey !== undefined) process.env['ANTHROPIC_API_KEY'] = origKey;
    }
  });
});
