// Owner: harness-test-engineer
// Contract validate + task lifecycle. Drives the handlers directly with a
// mock CheckRunners so we never shell out to a real sensor.
//
// Phase 2 coverage: judge checks in a spec are returned as `pending[]` sub-
// results (the server no longer calls an LLM). Aggregation rules:
//   - passed: true only when all sensors passed AND pending is empty.
//   - pending non-empty → passed: false, inconclusive: false, summary mentions
//     "pending agent review".

import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import {
  handleContractSpecValidate,
  handleContractTaskComplete,
  handleContractTaskNext,
  type CheckRunners,
} from '../../src/contracts/index.js';
import { harnessPaths, type HarnessPaths } from '../../src/storage/paths.js';
import type { SensorOutput } from '../../src/shared/schemas/sensor-output.js';
import { makeTempHarness, type TempHarness } from '../mocks/harness-tmp.js';

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

const SENSOR_ONLY_SPEC = `id: signup-spec
title: User signup MVP
acceptanceCriteria:
  - "POST /auth/signup returns 200"
checks:
  - kind: sensor
    id: tsc
tasks:
  - id: signup-handler
    description: Implement /auth/signup handler
`;

const JUDGE_ONLY_SPEC = `id: judge-only-spec
title: Spec with only judge check
acceptanceCriteria:
  - Artifact follows guidelines
checks:
  - kind: judge
    rubric: spec-adherence
tasks:
  - id: task-a
    description: Implement it
`;

const MIXED_SPEC = `id: mixed-spec
title: Spec with both sensor and judge check
acceptanceCriteria:
  - Types compile
  - Follows spec
checks:
  - kind: sensor
    id: tsc
  - kind: judge
    rubric: spec-adherence
tasks:
  - id: task-b
    description: Implement both
`;

const SPEC_ADHERENCE_RUBRIC = `---
id: spec-adherence
regulation: behaviour
description: Checks spec adherence
---

Evaluate the artifact.

## Artifact
<<<TARGET>>>
`;

const SPEC_ADHERENCE_SCHEMA = {
  $schema: 'http://json-schema.org/draft-07/schema#',
  type: 'object',
  required: ['tool', 'regulation', 'passed', 'summary', 'violations'],
  properties: {
    tool: { type: 'string', const: 'spec-adherence' },
    regulation: { type: 'string', const: 'behaviour' },
    passed: { type: 'boolean' },
    summary: { type: 'string' },
    inconclusive: { type: 'boolean' },
    violations: { type: 'array' },
  },
};

function passingTscOutput(): SensorOutput {
  return {
    tool: 'tsc',
    regulation: 'maintainability',
    passed: true,
    summary: 'tsc clean',
    inconclusive: false,
    violations: [],
  };
}

function failingTscOutput(): SensorOutput {
  return {
    tool: 'tsc',
    regulation: 'maintainability',
    passed: false,
    summary: 'tsc errors',
    inconclusive: false,
    violations: [
      {
        severity: 'error',
        what: 'TS2345',
        why: 'Wrong type',
        remediation: 'Fix the type',
        filesAffected: ['src/auth.ts'],
        linesAffected: [],
      },
    ],
  };
}

// ---------------------------------------------------------------------------
// Suite: sensor-only spec (existing behaviour, preserved)
// ---------------------------------------------------------------------------

describe('contract spec validate — sensor-only spec', () => {
  let tmp: TempHarness;
  let paths: HarnessPaths;
  let runners: CheckRunners;

  beforeEach(async () => {
    tmp = await makeTempHarness({
      specs: [{ id: 'signup-spec', body: SENSOR_ONLY_SPEC }],
      sensors: [{ id: 'tsc' }],
    });
    paths = harnessPaths(tmp.harnessRoot);
    runners = {
      sensor: async () => passingTscOutput(),
    };
  });

  afterEach(async () => {
    await tmp.cleanup();
  });

  it('aggregates passing sensor checks into passed=true, no pending', async () => {
    const out = await handleContractSpecValidate(paths, runners, {
      id: 'signup-spec',
      artifact: 'src/auth/signup.ts',
    });
    expect(out.passed).toBe(true);
    expect(out.regulation).toBe('behaviour');
    expect(out.summary).toContain('1/1 checks passed');
    expect(out.violations).toEqual([]);
    expect(out.pending).toBeUndefined();
  });

  it('sensor failure → passed=false, violations propagate, no pending', async () => {
    runners = { sensor: async () => failingTscOutput() };

    const out = await handleContractSpecValidate(paths, runners, {
      id: 'signup-spec',
      artifact: 'src/auth/signup.ts',
    });
    expect(out.passed).toBe(false);
    expect(out.inconclusive).toBe(false);
    expect(out.violations).toHaveLength(1);
    expect(out.pending).toBeUndefined();
  });
});

// ---------------------------------------------------------------------------
// Suite: judge-only spec — new phase 2 behaviour
// ---------------------------------------------------------------------------

describe('contract spec validate — judge-only spec (phase 2)', () => {
  let tmp: TempHarness;
  let paths: HarnessPaths;
  let runners: CheckRunners;

  beforeEach(async () => {
    tmp = await makeTempHarness({
      specs: [{ id: 'judge-only-spec', body: JUDGE_ONLY_SPEC }],
      judges: [
        {
          rubricId: 'spec-adherence',
          body: SPEC_ADHERENCE_RUBRIC,
          schema: SPEC_ADHERENCE_SCHEMA,
        },
      ],
    });
    paths = harnessPaths(tmp.harnessRoot);
    runners = {
      sensor: async () => {
        throw new Error('sensor runner must not be called for judge-only spec');
      },
    };
  });

  afterEach(async () => {
    await tmp.cleanup();
  });

  it('judge check appears in pending[] with correct shape', async () => {
    const out = await handleContractSpecValidate(paths, runners, {
      id: 'judge-only-spec',
      artifact: 'src/auth/signup.ts',
    });

    expect(out.passed).toBe(false);
    expect(out.inconclusive).toBe(false);
    expect(Array.isArray(out.pending)).toBe(true);
    expect(out.pending).toHaveLength(1);

    const pending = out.pending![0]!;
    expect(pending.kind).toBe('judge');
    expect(pending.rubric).toBe('spec-adherence');
    expect(pending.status).toBe('requires_agent_review');
    expect(typeof pending.instructions).toBe('string');
    expect(pending.instructions.length).toBeGreaterThan(0);
    expect(pending.schema).toBeDefined();
    expect(pending.context.target).toBeTruthy();
    expect(pending.submission.tool).toBe('judge_record');
    expect(pending.submission.correlation.rubric_id).toBe('spec-adherence');
    expect(pending.submission.correlation.target).toBe('src/auth/signup.ts');
  });

  it('summary mentions "pending agent review" when judge checks are pending', async () => {
    const out = await handleContractSpecValidate(paths, runners, {
      id: 'judge-only-spec',
      artifact: 'src/auth/signup.ts',
    });

    expect(out.summary.toLowerCase()).toContain('pending agent review');
  });

  it('passed=false when pending is non-empty (even when all sensors passed)', async () => {
    const out = await handleContractSpecValidate(paths, runners, {
      id: 'judge-only-spec',
      artifact: 'src/auth/signup.ts',
    });

    expect(out.passed).toBe(false);
    expect(out.inconclusive).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// Suite: mixed spec (sensor + judge) — core phase 2 scenario
// ---------------------------------------------------------------------------

describe('contract spec validate — mixed sensor + judge spec (phase 2)', () => {
  let tmp: TempHarness;
  let paths: HarnessPaths;

  beforeEach(async () => {
    tmp = await makeTempHarness({
      specs: [{ id: 'mixed-spec', body: MIXED_SPEC }],
      sensors: [{ id: 'tsc' }],
      judges: [
        {
          rubricId: 'spec-adherence',
          body: SPEC_ADHERENCE_RUBRIC,
          schema: SPEC_ADHERENCE_SCHEMA,
        },
      ],
    });
    paths = harnessPaths(tmp.harnessRoot);
  });

  afterEach(async () => {
    await tmp.cleanup();
  });

  it('passing sensor + pending judge → passed=false, 1 pending, no violations', async () => {
    const runners: CheckRunners = {
      sensor: async () => passingTscOutput(),
    };

    const out = await handleContractSpecValidate(paths, runners, {
      id: 'mixed-spec',
      artifact: 'src/auth/signup.ts',
    });

    expect(out.passed).toBe(false);
    expect(out.inconclusive).toBe(false);
    expect(out.violations).toEqual([]);
    expect(out.pending).toHaveLength(1);
    expect(out.pending![0]!.kind).toBe('judge');
    expect(out.pending![0]!.rubric).toBe('spec-adherence');
    // Summary covers total checks including pending
    expect(out.summary).toContain('1 judge check');
  });

  it('failing sensor + pending judge → passed=false, violations from sensor, 1 pending', async () => {
    const runners: CheckRunners = {
      sensor: async () => failingTscOutput(),
    };

    const out = await handleContractSpecValidate(paths, runners, {
      id: 'mixed-spec',
      artifact: 'src/auth/signup.ts',
    });

    expect(out.passed).toBe(false);
    expect(out.inconclusive).toBe(false);
    expect(out.violations).toHaveLength(1);
    expect(out.pending).toHaveLength(1);
  });

  it('passed=true requires all sensors passed AND pending empty — pending alone prevents it', async () => {
    // Even with a passing sensor, pending judge prevents passed=true.
    const runners: CheckRunners = {
      sensor: async () => passingTscOutput(),
    };

    const out = await handleContractSpecValidate(paths, runners, {
      id: 'mixed-spec',
      artifact: 'src/auth/signup.ts',
    });

    // Must be false because pending is non-empty
    expect(out.passed).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// Suite: unknown judge rubric (graceful degradation)
// ---------------------------------------------------------------------------

describe('contract spec validate — rubric not found degrades gracefully', () => {
  let tmp: TempHarness;
  let paths: HarnessPaths;

  beforeEach(async () => {
    tmp = await makeTempHarness({
      specs: [{ id: 'mixed-spec', body: MIXED_SPEC }],
      sensors: [{ id: 'tsc' }],
      // No judges — rubric missing
    });
    paths = harnessPaths(tmp.harnessRoot);
  });

  afterEach(async () => {
    await tmp.cleanup();
  });

  it('unknown rubric produces pending entry with inconclusiveReason=rubric_not_found', async () => {
    const runners: CheckRunners = {
      sensor: async () => passingTscOutput(),
    };

    const out = await handleContractSpecValidate(paths, runners, {
      id: 'mixed-spec',
      artifact: 'src/auth/signup.ts',
    });

    // Still non-fatal — result is a pending entry with inconclusiveReason
    expect(out.pending).toHaveLength(1);
    expect(out.pending![0]!.inconclusiveReason).toContain('rubric_not_found');
    expect(out.passed).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// Suite: task lifecycle (preserved from original)
// ---------------------------------------------------------------------------

describe('contract task lifecycle', () => {
  let tmp: TempHarness;
  let paths: HarnessPaths;

  beforeEach(async () => {
    tmp = await makeTempHarness({
      specs: [{ id: 'signup-spec', body: SENSOR_ONLY_SPEC }],
      sensors: [{ id: 'tsc' }],
    });
    paths = harnessPaths(tmp.harnessRoot);
  });

  afterEach(async () => {
    await tmp.cleanup();
  });

  it('walks the task lifecycle: next -> in_progress -> complete -> next null', async () => {
    const first = await handleContractTaskNext(paths, { spec_id: 'signup-spec' });
    expect(first.task).not.toBeNull();
    expect(first.task?.id).toBe('signup-handler');
    expect(first.task?.status).toBe('in_progress');

    const completed = await handleContractTaskComplete(paths, {
      task_id: 'signup-handler',
      evidence: [
        {
          kind: 'sensor_run',
          sensor: 'tsc',
          passed: true,
          timestamp: new Date().toISOString(),
        },
      ],
    });
    expect(completed.task.status).toBe('completed');
    expect(completed.task.evidence).toHaveLength(1);

    const next = await handleContractTaskNext(paths, { spec_id: 'signup-spec' });
    expect(next.task).toBeNull();
  });
});
