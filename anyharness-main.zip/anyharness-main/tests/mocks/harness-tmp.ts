// Owner: harness-test-engineer
// Helper for spinning up a throwaway `.harness/` tree in `mkdtemp`. Tests
// declare only the pieces they care about; everything else is left empty so
// behaviour mirrors a fresh repo. Returns an absolute path + cleanup callback
// suitable for use in afterEach/finally blocks.

import * as fs from 'node:fs/promises';
import * as os from 'node:os';
import * as path from 'node:path';

export interface SensorYaml {
  id: string;
  /** Raw YAML body. If omitted, a minimal stub is generated. */
  body?: string;
}

export interface JudgeFile {
  rubricId: string;
  /** Markdown body (frontmatter + prompt). */
  body: string;
  /** Optional output schema JSON; written next to the prompt when supplied. */
  schema?: Record<string, unknown>;
}

export interface SpecFile {
  id: string;
  /** YAML body. The id key inside MUST match `id`. */
  body: string;
}

export interface GuideFile {
  kind: 'rules' | 'skills' | 'subagents';
  id: string;
  body: string;
}

export interface WorkflowFile {
  id: string;
  body: string;
}

export interface MakeTempHarnessOptions {
  sensors?: SensorYaml[];
  judges?: JudgeFile[];
  specs?: SpecFile[];
  guides?: GuideFile[];
  workflows?: WorkflowFile[];
}

export interface TempHarness {
  /** Absolute path to the `.harness/` root. Pass this to `harnessPaths(root)`. */
  harnessRoot: string;
  /** Removes the temp dir tree. Safe to call multiple times. */
  cleanup: () => Promise<void>;
}

const DEFAULT_SENSOR_BODY = (id: string): string =>
  `id: ${id}\nkind: type-check\nregulation: maintainability\ncommand: "echo ok"\nadapter: ${id}\ndescription: "test sensor ${id}"\n`;

export async function makeTempHarness(
  opts: MakeTempHarnessOptions = {},
): Promise<TempHarness> {
  const tmpRoot = await fs.mkdtemp(path.join(os.tmpdir(), 'harness-test-'));
  const harnessRoot = path.join(tmpRoot, '.harness');

  // Always create the canonical directory layout so loaders that readdir() a
  // missing folder don't return empty just because the test didn't populate
  // a category — they'll still return empty, but the path resolves cleanly.
  await Promise.all([
    fs.mkdir(path.join(harnessRoot, 'guides', 'rules'), { recursive: true }),
    fs.mkdir(path.join(harnessRoot, 'guides', 'skills'), { recursive: true }),
    fs.mkdir(path.join(harnessRoot, 'guides', 'subagents'), { recursive: true }),
    fs.mkdir(path.join(harnessRoot, 'sensors'), { recursive: true }),
    fs.mkdir(path.join(harnessRoot, 'judges'), { recursive: true }),
    fs.mkdir(path.join(harnessRoot, 'contracts', 'specs'), { recursive: true }),
    fs.mkdir(path.join(harnessRoot, 'contracts', 'tasks'), { recursive: true }),
    fs.mkdir(path.join(harnessRoot, 'workflows'), { recursive: true }),
    fs.mkdir(path.join(harnessRoot, '.local', 'sessions'), { recursive: true }),
    fs.mkdir(path.join(harnessRoot, '.local', 'steering'), { recursive: true }),
    fs.mkdir(path.join(harnessRoot, '.local', 'judges'), { recursive: true }),
    fs.mkdir(path.join(harnessRoot, '.local', 'telemetry'), { recursive: true }),
  ]);

  for (const sensor of opts.sensors ?? []) {
    const body = sensor.body ?? DEFAULT_SENSOR_BODY(sensor.id);
    await fs.writeFile(
      path.join(harnessRoot, 'sensors', `${sensor.id}.yaml`),
      body,
      'utf8',
    );
  }

  for (const judge of opts.judges ?? []) {
    await fs.writeFile(
      path.join(harnessRoot, 'judges', `${judge.rubricId}.md`),
      judge.body,
      'utf8',
    );
    if (judge.schema !== undefined) {
      await fs.writeFile(
        path.join(harnessRoot, 'judges', `${judge.rubricId}.schema.json`),
        JSON.stringify(judge.schema, null, 2),
        'utf8',
      );
    }
  }

  for (const spec of opts.specs ?? []) {
    await fs.writeFile(
      path.join(harnessRoot, 'contracts', 'specs', `${spec.id}.yaml`),
      spec.body,
      'utf8',
    );
  }

  for (const guide of opts.guides ?? []) {
    await fs.writeFile(
      path.join(harnessRoot, 'guides', guide.kind, `${guide.id}.md`),
      guide.body,
      'utf8',
    );
  }

  for (const workflow of opts.workflows ?? []) {
    await fs.writeFile(
      path.join(harnessRoot, 'workflows', `${workflow.id}.md`),
      workflow.body,
      'utf8',
    );
  }

  let cleaned = false;
  const cleanup = async (): Promise<void> => {
    if (cleaned) return;
    cleaned = true;
    await fs.rm(tmpRoot, { recursive: true, force: true });
  };

  return { harnessRoot, cleanup };
}
