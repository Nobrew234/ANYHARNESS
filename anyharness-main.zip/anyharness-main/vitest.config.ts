// Owner: harness-test-engineer
// Vitest configuration for unit + integration suites. E2E lives under
// tests/e2e/ and uses the same config but is invoked via `npm run test:e2e`.
import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'node',
    testTimeout: 20000,
    include: ['tests/**/*.spec.ts', 'src/**/*.spec.ts'],
    exclude: ['node_modules/**', 'dist/**'],
  },
});
