# ADR-001 — Decisões iniciais (SPEC §15)

- **Status:** Accepted
- **Date:** 2026-04-30
- **Decisores:** humano + harness-architect

## Contexto

A SPEC.md §15 listava 6 decisões pendentes que bloqueavam implementação concreta. Antes de começar a Fase 2 (paralelização entre agentes de domínio), todas foram fechadas.

## Decisões

1. **Nome:** pacote npm e binário = `anyharness`. Marca neutralidade de cliente (Claude Code, Cursor, Codex).
2. **Tool namespace:** sem prefixo (`sensor.list`, `judge.review`, `contract.spec.validate`, `session.start`). Exceção: `harness.steer.suggest` mantém prefixo `harness.` por convenção da SPEC §3 (steering loop é meta-tool sobre o próprio harness).
3. **URI scheme:** `harness://`.
4. **Sessions e steering log:** gitignored em `.harness/.local/` por default. Override via config futura.
5. **Workflows:** primário como `prompts/` MCP (`workflow.PREVC`, `workflow.bug-fix`); fallback como resource `harness://workflows/<id>` para clientes que não suportam `prompts/`.
6. **Modelo default do judge:** `claude-sonnet-4-6`.

## Consequências

- Schemas zod e helpers de path em `src/shared/schemas/` e `src/storage/paths.ts` ficam estáveis para os agentes de Fase 2 importarem sem coordenação adicional.
- Reverter decisão 4 (commitar sessions) é trivial — só muda config; estrutura de paths já permite ambos.
- Decisão 5 implica que `src/server/` tem que registrar workflow tanto em `prompts/list` quanto em `resources/list`. `harness-mcp-server` é dono dessa duplicidade.
