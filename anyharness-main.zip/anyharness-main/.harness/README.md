# `.harness/` — template

Source-of-truth do harness deste projeto. Versionado em Git, exceto `.local/` (gitignored).

## Layout

```
.harness/
├── guides/{rules,skills,subagents}/     # feedforward, expostos como harness:// resources
├── sensors/<id>.yaml                    # registro: command, schema, regulation
├── judges/<rubric>.{md,schema.json}     # prompts versionados + output schemas
├── contracts/{specs,tasks}/             # behaviour harness
├── workflows/<id>.md                    # MCP prompts (PREVC, bug-fix)
└── .local/                              # gitignored: sessions, steering log, custos
```

Esses diretórios estão criados vazios como template. Conteúdo real é responsabilidade do humano operando o harness, com auxílio do agente:

- `sensor.register` adiciona arquivo em `sensors/`.
- `harness.steer.suggest` propõe novos arquivos em `guides/rules/` (humano aprova).
- Specs e tasks são autoradas em markdown/yaml direto.
- Judges (`spec-adherence` etc.) chegam como template no MVP e podem ser editados pelo time.
