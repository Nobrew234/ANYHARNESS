# PREVC — Plan, Research, Execute, Validate, Commit

A five-step loop for landing changes safely against a contract. Tools used at each step are listed inline; the agent should call them via MCP rather than guessing.

## 1. Plan
Restate the goal in one paragraph. If a `spec_id` is in scope, fetch it via `harness://contracts/specs/<id>` and call `contract.task.next(spec_id)` to anchor on the next pending task. Note open questions; refuse to invent acceptance criteria the spec does not state.

## 2. Research
Read the relevant guides (`harness://guides/rules/*`, `harness://guides/skills/*`) and the surrounding code. Map every acceptance criterion in the spec to a concrete file or interface. If something is missing, surface it before writing code.

## 3. Execute
Make the smallest change that satisfies the current task. Stay inside files mentioned in the spec or the chosen task. If you must touch code outside that scope, record the rationale in `session.append`.

## 4. Validate
Run the cheapest sensors first via `sensor.run` (linter, type-check, structural). If they pass, escalate to `judge.review` against `spec-adherence` or another rubric the spec demands. Finally, call `contract.spec.validate(spec_id, artifact)` to dispatch all spec-declared checks. Do not move on while any sensor or judge reports an unresolved violation.

## 5. Commit
Capture evidence — sensor and judge outputs, PR link — and call `contract.task.complete(task_id, evidence)`. Open the PR with a description that quotes the spec section being satisfied and the validation summary.

If validation fails at any step, return to Plan or Research; never paper over a failing sensor by editing the sensor itself.
