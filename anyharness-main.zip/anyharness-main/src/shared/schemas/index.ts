// Barrel for all shared schemas. Domain owners contribute via their files;
// harness-mcp-server consumes for tool I/O validation. See SPEC §9.
export * from './common.js';
export * from './violation.js';
export * from './sensor-output.js';
export * from './sensor-registry.js';
export * from './judge-rubric.js';
export * from './spec.js';
export * from './task.js';
export * from './session-event.js';
export * from './steering-event.js';
export * from './tools/index.js';
