// Owner: harness-architect — SPEC §9. Used by sensor.run, judge.review, contract.spec.validate.
import { z } from 'zod';
import { Regulation } from './common.js';
import { Violation } from './violation.js';

export const SensorOutput = z.object({
  tool: z.string().min(1),
  regulation: Regulation,
  passed: z.boolean(),
  summary: z.string(),
  inconclusive: z.boolean().default(false),
  inconclusiveReason: z.string().optional(),
  violations: z.array(Violation).default([]),
});
export type SensorOutput = z.infer<typeof SensorOutput>;
