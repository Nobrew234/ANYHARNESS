// Owner: harness-architect — see SPEC §9.
import { z } from 'zod';
import { Severity } from './common.js';

export const LineRange = z.tuple([z.number().int().nonnegative(), z.number().int().nonnegative()]);
export type LineRange = z.infer<typeof LineRange>;

export const Violation = z.object({
  severity: Severity,
  what: z.string().min(1),
  why: z.string().min(1),
  remediation: z.string().min(1),
  filesAffected: z.array(z.string()).default([]),
  linesAffected: z.array(LineRange).default([]),
  guideUri: z.string().regex(/^harness:\/\//).optional(),
});
export type Violation = z.infer<typeof Violation>;
