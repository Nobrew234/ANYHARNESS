// Owner: harness-architect — format of .harness/sensors/<id>.yaml. SPEC §6.
import { z } from 'zod';
import { Regulation, SensorKind } from './common.js';

export const SensorRegistryEntry = z.object({
  id: z.string().min(1).regex(/^[a-z0-9][a-z0-9._-]*$/i),
  kind: SensorKind,
  regulation: Regulation,
  command: z.string().min(1),
  adapter: z.string().min(1),
  description: z.string().optional(),
  defaults: z.object({
    target: z.string().optional(),
  }).optional(),
});
export type SensorRegistryEntry = z.infer<typeof SensorRegistryEntry>;
