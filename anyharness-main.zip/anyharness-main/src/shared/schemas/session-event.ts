// Owner: harness-architect — appended to .harness/.local/sessions/<id>.jsonl. SPEC §11.
import { z } from 'zod';
import { Regulation, IsoTimestamp } from './common.js';

const Base = { timestamp: IsoTimestamp };

const ToolCall = z.object({
  ...Base,
  kind: z.literal('tool_call'),
  tool: z.string(),
  args: z.unknown(),
});

const SensorRun = z.object({
  ...Base,
  kind: z.literal('sensor_run'),
  sensor: z.string(),
  passed: z.boolean(),
  violationCount: z.number().int().nonnegative(),
  regulation: Regulation,
});

const JudgeReview = z.object({
  ...Base,
  kind: z.literal('judge_review'),
  rubric: z.string(),
  passed: z.boolean(),
  violationCount: z.number().int().nonnegative(),
});

const Decision = z.object({
  ...Base,
  kind: z.literal('decision'),
  what: z.string(),
  rationale: z.string(),
});

const HumanIntervention = z.object({
  ...Base,
  kind: z.literal('human_intervention'),
  what: z.string(),
});

const TaskStarted = z.object({
  ...Base,
  kind: z.literal('task_started'),
  task_id: z.string(),
});

const TaskCompleted = z.object({
  ...Base,
  kind: z.literal('task_completed'),
  task_id: z.string(),
});

export const SessionEvent = z.discriminatedUnion('kind', [
  ToolCall, SensorRun, JudgeReview, Decision, HumanIntervention, TaskStarted, TaskCompleted,
]);
export type SessionEvent = z.infer<typeof SessionEvent>;

export const SessionHeader = z.object({
  session_id: z.string().min(1),
  workflow: z.string().optional(),
  contract_id: z.string().optional(),
  startedAt: IsoTimestamp,
});
export type SessionHeader = z.infer<typeof SessionHeader>;
