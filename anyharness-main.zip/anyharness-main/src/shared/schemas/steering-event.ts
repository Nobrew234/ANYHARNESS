// Owner: harness-architect — appended to .harness/.local/steering/log.jsonl. SPEC §8.
import { z } from 'zod';
import { Regulation, IsoTimestamp } from './common.js';
import { Violation } from './violation.js';

export const SteeringEvent = z.object({
  timestamp: IsoTimestamp,
  kind: z.enum(['sensor', 'judge']),
  id: z.string().min(1),
  target: z.string(),
  regulation: Regulation,
  passed: z.boolean(),
  inconclusive: z.boolean().default(false),
  violationCount: z.number().int().nonnegative(),
  violations: z.array(Violation).default([]),
});
export type SteeringEvent = z.infer<typeof SteeringEvent>;
