// Owner: harness-architect — .harness/contracts/tasks/<task_id>.yaml. SPEC §10.
import { z } from 'zod';
import { TaskStatus, IsoTimestamp } from './common.js';

const EvidenceSensorRun = z.object({
  kind: z.literal('sensor_run'),
  sensor: z.string(),
  passed: z.boolean(),
  timestamp: IsoTimestamp,
});

const EvidenceJudgeReview = z.object({
  kind: z.literal('judge_review'),
  rubric: z.string(),
  passed: z.boolean(),
  timestamp: IsoTimestamp,
});

const EvidencePrLink = z.object({
  kind: z.literal('pr_link'),
  url: z.string().url(),
  timestamp: IsoTimestamp,
});

const EvidenceNote = z.object({
  kind: z.literal('note'),
  text: z.string(),
  timestamp: IsoTimestamp,
});

export const Evidence = z.discriminatedUnion('kind', [
  EvidenceSensorRun,
  EvidenceJudgeReview,
  EvidencePrLink,
  EvidenceNote,
]);
export type Evidence = z.infer<typeof Evidence>;

export const Task = z.object({
  id: z.string().min(1),
  spec_id: z.string().min(1),
  description: z.string().min(1),
  status: TaskStatus.default('pending'),
  evidence: z.array(Evidence).default([]),
  completedAt: IsoTimestamp.nullable().default(null),
});
export type Task = z.infer<typeof Task>;
