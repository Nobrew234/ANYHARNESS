// Owner: harness-architect — .harness/contracts/specs/<id>.{yaml,md}. SPEC §10.
import { z } from 'zod';

export const SpecCheckSensor = z.object({
  kind: z.literal('sensor'),
  id: z.string().min(1),
});

export const SpecCheckJudge = z.object({
  kind: z.literal('judge'),
  rubric: z.string().min(1),
});

export const SpecCheck = z.discriminatedUnion('kind', [SpecCheckSensor, SpecCheckJudge]);
export type SpecCheck = z.infer<typeof SpecCheck>;

export const SpecTaskRef = z.object({
  id: z.string().min(1),
  description: z.string().min(1),
  acceptanceRefs: z.array(z.number().int().nonnegative()).optional(),
});
export type SpecTaskRef = z.infer<typeof SpecTaskRef>;

export const Spec = z.object({
  id: z.string().min(1).regex(/^[a-z0-9][a-z0-9._-]*$/i),
  title: z.string().min(1),
  acceptanceCriteria: z.array(z.string()).default([]),
  checks: z.array(SpecCheck).default([]),
  tasks: z.array(SpecTaskRef).default([]),
});
export type Spec = z.infer<typeof Spec>;
