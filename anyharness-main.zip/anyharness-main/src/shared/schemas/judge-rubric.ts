// Owner: harness-architect — frontmatter of .harness/judges/<rubric>.md. SPEC §7, §15.6.
import { z } from 'zod';
import { Regulation } from './common.js';

export const RubricInputKind = z.enum(['target', 'spec-ref', 'diff-stats']);

export const JudgeRubricFrontmatter = z.object({
  id: z.string().min(1).regex(/^[a-z0-9][a-z0-9._-]*$/i),
  regulation: Regulation,
  description: z.string(),
  inputs: z.array(z.object({
    kind: RubricInputKind,
    optional: z.boolean().default(false),
  })).default([]),
}).strict();
export type JudgeRubricFrontmatter = z.infer<typeof JudgeRubricFrontmatter>;
