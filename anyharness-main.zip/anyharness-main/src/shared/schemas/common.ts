// Owner: harness-architect — shared primitives.
import { z } from 'zod';

export const Regulation = z.enum(['maintainability', 'fitness', 'behaviour']);
export type Regulation = z.infer<typeof Regulation>;

export const Severity = z.enum(['error', 'warning', 'info']);
export type Severity = z.infer<typeof Severity>;

export const SensorKind = z.enum(['linter', 'type-check', 'structural', 'custom']);
export type SensorKind = z.infer<typeof SensorKind>;

export const GuideKind = z.enum(['rules', 'skills', 'subagents']);
export type GuideKind = z.infer<typeof GuideKind>;

export const TaskStatus = z.enum(['pending', 'in_progress', 'completed']);
export type TaskStatus = z.infer<typeof TaskStatus>;

export const IsoTimestamp = z.string().datetime({ offset: true });
