// Owner: harness-architect — harness.steer.suggest. SPEC §4, §8.
import { z } from 'zod';

export const SteerSuggestInput = z.object({
  windowDays: z.number().int().positive().default(30),
});
export type SteerSuggestInput = z.infer<typeof SteerSuggestInput>;

export const SteerSuggestion = z.object({
  kind: z.enum(['new-rule', 'new-sensor', 'orphan-guide', 'recurring-judge-flag']),
  rationale: z.string(),
  evidence: z.record(z.unknown()),
  proposedAction: z.record(z.unknown()).optional(),
});
export type SteerSuggestion = z.infer<typeof SteerSuggestion>;

export const SteerSuggestOutput = z.object({
  suggestions: z.array(SteerSuggestion),
  windowDays: z.number(),
  eventCountAnalyzed: z.number().int().nonnegative(),
});
export type SteerSuggestOutput = z.infer<typeof SteerSuggestOutput>;
