// Owner: harness-architect — sensor.* tool I/O. SPEC §4.
import { z } from 'zod';
import { Regulation, SensorKind } from '../common.js';
import { SensorOutput } from '../sensor-output.js';
import { SensorRegistryEntry } from '../sensor-registry.js';

export const SensorListInput = z.object({
  kind: SensorKind.optional(),
  regulation: Regulation.optional(),
});
export type SensorListInput = z.infer<typeof SensorListInput>;

export const SensorListOutput = z.object({
  sensors: z.array(z.object({
    id: z.string(),
    kind: SensorKind,
    regulation: Regulation,
    command: z.string(),
    description: z.string().optional(),
  })),
});
export type SensorListOutput = z.infer<typeof SensorListOutput>;

export const SensorRunInput = z.object({
  id: z.string().min(1),
  target: z.string().optional(),
});
export type SensorRunInput = z.infer<typeof SensorRunInput>;

export const SensorRunOutput = SensorOutput;
export type SensorRunOutput = z.infer<typeof SensorRunOutput>;

export const SensorRegisterInput = SensorRegistryEntry;
export type SensorRegisterInput = z.infer<typeof SensorRegisterInput>;

export const SensorRegisterOutput = z.object({
  registered: z.boolean(),
  path: z.string(),
  changed: z.boolean(),
});
export type SensorRegisterOutput = z.infer<typeof SensorRegisterOutput>;
