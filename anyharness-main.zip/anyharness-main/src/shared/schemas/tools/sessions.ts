// Owner: harness-architect — session.* tool I/O. SPEC §4, §11.
import { z } from 'zod';
import { SessionEvent, SessionHeader } from '../session-event.js';

export const SessionStartInput = z.object({
  workflow: z.string().optional(),
  contract_id: z.string().optional(),
});
export type SessionStartInput = z.infer<typeof SessionStartInput>;

export const SessionStartOutput = z.object({
  session_id: z.string(),
  startedAt: z.string(),
});
export type SessionStartOutput = z.infer<typeof SessionStartOutput>;

export const SessionAppendInput = z.object({
  session_id: z.string().min(1),
  event: SessionEvent,
});
export type SessionAppendInput = z.infer<typeof SessionAppendInput>;

export const SessionAppendOutput = z.object({
  appended: z.boolean(),
  eventCount: z.number().int().nonnegative(),
});
export type SessionAppendOutput = z.infer<typeof SessionAppendOutput>;

export const SessionGetInput = z.object({
  session_id: z.string().min(1),
});
export type SessionGetInput = z.infer<typeof SessionGetInput>;

export const SessionGetOutput = z.object({
  header: SessionHeader,
  events: z.array(SessionEvent),
});
export type SessionGetOutput = z.infer<typeof SessionGetOutput>;
