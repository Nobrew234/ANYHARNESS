// Owner: harness-architect — judge.* tool I/O. SPEC §3, §4, §7, §10, §15.6.
//
// As of the §15.6 design freeze, the server does NOT call an LLM. `judge.review`
// returns a rendered prompt + schema + context envelope; the MCP client
// performs the inference and submits the verdict back via `judge.record`.
import { z } from 'zod';
import { Regulation } from '../common.js';
import { SensorOutput } from '../sensor-output.js';

// ---------------------------------------------------------------------------
// judge.list
// ---------------------------------------------------------------------------

export const JudgeListInput = z.object({
  rubric: z.string().optional(),
});
export type JudgeListInput = z.infer<typeof JudgeListInput>;

export const JudgeListRubricEntry = z.object({
  rubric_id: z.string(),
  regulation: Regulation,
  description: z.string(),
});
export type JudgeListRubricEntry = z.infer<typeof JudgeListRubricEntry>;

export const JudgeListOutput = z.object({
  rubrics: z.array(JudgeListRubricEntry),
});
export type JudgeListOutput = z.infer<typeof JudgeListOutput>;

// ---------------------------------------------------------------------------
// judge.review — server prepares context; client performs inference.
// ---------------------------------------------------------------------------

export const JudgeReviewInput = z.object({
  rubric_id: z.string().min(1),
  target: z.string().min(1),
  spec_id: z.string().optional(),
});
export type JudgeReviewInput = z.infer<typeof JudgeReviewInput>;

export const JudgeReviewContext = z.object({
  spec: z.string().optional(),
  target: z.string(),
});
export type JudgeReviewContext = z.infer<typeof JudgeReviewContext>;

export const JudgeReviewSubmission = z.object({
  tool: z.literal('judge_record'),
  correlation: z.object({
    rubric_id: z.string(),
    target: z.string(),
  }),
});
export type JudgeReviewSubmission = z.infer<typeof JudgeReviewSubmission>;

/**
 * SPEC §15.6 envelope: server returns the rendered prompt + the rubric output
 * schema + the resolved context, plus a hint for which tool the client should
 * call next. There is NO `passed` field here — review is preparation, not a
 * verdict.
 */
export const JudgeReviewOutput = z.object({
  rubric_id: z.string(),
  regulation: Regulation,
  instructions: z.string(),
  // Rubric schema is opaque JSON for the client; we keep it as `unknown` so we
  // never lie about its shape (it is the rubric's own JSON Schema document).
  schema: z.unknown(),
  context: JudgeReviewContext,
  submission: JudgeReviewSubmission,
});
export type JudgeReviewOutput = z.infer<typeof JudgeReviewOutput>;

// ---------------------------------------------------------------------------
// judge.record — client submits verdict; server validates + logs.
// ---------------------------------------------------------------------------

export const JudgeRecordInput = z.object({
  rubric_id: z.string().min(1),
  target: z.string().min(1),
  // The verdict produced by the client. We intentionally accept `unknown` here
  // because the server validates this against the rubric's own JSON Schema
  // (.harness/judges/<rubric>.schema.json), not against the input zod schema.
  result: z.unknown(),
  spec_id: z.string().optional(),
});
export type JudgeRecordInput = z.infer<typeof JudgeRecordInput>;

/**
 * `judge.record` returns the canonical SPEC §9 envelope so callers can treat
 * sensor outputs and judge verdicts uniformly. When validation fails the
 * envelope carries `inconclusive: true` with `inconclusiveReason:
 * "result_failed_schema_validation"` and the offending field paths in
 * `validationErrors`.
 */
export const JudgeRecordOutput = SensorOutput.extend({
  validationErrors: z.array(z.object({
    path: z.string(),
    message: z.string(),
  })).optional(),
});
export type JudgeRecordOutput = z.infer<typeof JudgeRecordOutput>;
