// Owner: harness-architect — contract.* tool I/O. SPEC §4, §10.
import { z } from 'zod';
import { SensorOutput } from '../sensor-output.js';
import { Task, Evidence } from '../task.js';

export const ContractSpecValidateInput = z.object({
  id: z.string().min(1),
  artifact: z.string().min(1),
});
export type ContractSpecValidateInput = z.infer<typeof ContractSpecValidateInput>;

/**
 * Sub-result for a `judge` check inside `contract.spec.validate`. The server
 * does NOT execute the judge — it renders the rubric prompt and packages
 * everything the agent needs to perform the review with its own model and
 * register the verdict via `judge.record` (or attach it as evidence on
 * `contract.task.complete`). See README §"Tool: contract.spec.validate" and
 * §"judge.review (fase 1 — preparação)" for the canonical shape.
 *
 * Mirrors the output of `judge.review` so a contract validation pending entry
 * is interchangeable with what the agent would receive by calling
 * `judge.review` directly.
 *
 * `inconclusiveReason` is set ONLY when the server could not even prepare the
 * pending entry (rubric not found / unreadable). The reason is meant to flow
 * into the agent's decision making — they may still attempt review with
 * partial info, or skip the check.
 */
export const PendingJudgeCheck = z.object({
  kind: z.literal('judge'),
  rubric: z.string().min(1),
  status: z.literal('requires_agent_review'),
  instructions: z.string(),
  schema: z.record(z.unknown()),
  context: z.object({
    spec: z.string().optional(),
    target: z.string(),
  }),
  submission: z.object({
    tool: z.literal('judge_record'),
    correlation: z.object({
      rubric_id: z.string().min(1),
      target: z.string().min(1),
    }),
  }),
  inconclusiveReason: z.string().optional(),
});
export type PendingJudgeCheck = z.infer<typeof PendingJudgeCheck>;

/**
 * Output of `contract.spec.validate`. Extends the canonical `SensorOutput`
 * envelope (SPEC §9) with an optional `pending[]` array that surfaces judge
 * checks deferred to the MCP client. `pending` is unique to this tool — sensor
 * runs and judge.record envelopes never carry it.
 *
 * Aggregation rules (kept here as documentation for callers that only see the
 * schema): `passed` is `true` iff every sensor check passed AND `pending` is
 * absent/empty. `inconclusive` is `true` only when no sensor failed, no
 * pending review is outstanding, and at least one sensor was inconclusive.
 * When `pending` is non-empty the result is `passed: false, inconclusive: false`
 * and `summary` mentions "N judge checks pending agent review".
 */
export const ContractSpecValidateOutput = SensorOutput.extend({
  pending: z.array(PendingJudgeCheck).optional(),
});
export type ContractSpecValidateOutput = z.infer<typeof ContractSpecValidateOutput>;

export const ContractTaskNextInput = z.object({
  spec_id: z.string().min(1),
});
export type ContractTaskNextInput = z.infer<typeof ContractTaskNextInput>;

export const ContractTaskNextOutput = z.object({
  task: Task.nullable(),
});
export type ContractTaskNextOutput = z.infer<typeof ContractTaskNextOutput>;

export const ContractTaskCompleteInput = z.object({
  task_id: z.string().min(1),
  evidence: z.array(Evidence).min(1),
});
export type ContractTaskCompleteInput = z.infer<typeof ContractTaskCompleteInput>;

export const ContractTaskCompleteOutput = z.object({
  task: Task,
});
export type ContractTaskCompleteOutput = z.infer<typeof ContractTaskCompleteOutput>;
