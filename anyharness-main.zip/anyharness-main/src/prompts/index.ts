// Owner: harness-mcp-server (registry); humans author content in .harness/workflows/
// MCP prompts: workflow.PREVC, workflow.bug-fix.
// See SPEC §3 (Workflow row).
export {};
