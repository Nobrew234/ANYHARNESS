// Harness MCP — public entry. See SPEC.md.
// Owner: harness-architect (.claude/agents/harness-architect.md)
export {};
