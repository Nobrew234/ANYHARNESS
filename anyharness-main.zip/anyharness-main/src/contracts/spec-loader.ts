// Owner: harness-contracts
// Parses .harness/contracts/specs/<id>.{yaml,md}. SPEC §10.

import * as fs from 'node:fs/promises';
import { parse as parseYaml } from 'yaml';
import matter from 'gray-matter';
import { Spec } from '../shared/schemas/spec.js';
import type { HarnessPaths } from '../storage/paths.js';

export class SpecParseError extends Error {
  constructor(
    public readonly specId: string,
    public readonly filePath: string,
    message: string,
  ) {
    super(`Failed to parse spec '${specId}' at ${filePath}: ${message}`);
    this.name = 'SpecParseError';
  }
}

export async function loadSpec(
  paths: HarnessPaths,
  id: string,
): Promise<Spec | null> {
  const filePath = await paths.resolveSpecFile(id);
  if (filePath === null) return null;

  const raw = await fs.readFile(filePath, 'utf8');

  if (filePath.endsWith('.yaml') || filePath.endsWith('.yml')) {
    let parsed: unknown;
    try {
      parsed = parseYaml(raw);
    } catch (err) {
      throw new SpecParseError(id, filePath, `invalid YAML: ${(err as Error).message}`);
    }
    return parseSpec(id, filePath, parsed);
  }

  if (filePath.endsWith('.md')) {
    let fm: matter.GrayMatterFile<string>;
    try {
      fm = matter(raw);
    } catch (err) {
      throw new SpecParseError(id, filePath, `invalid frontmatter: ${(err as Error).message}`);
    }
    const data = (fm.data ?? {}) as Record<string, unknown>;

    // If acceptanceCriteria is missing or empty in frontmatter,
    // try harvesting bullets from a `## Acceptance Criteria` body section.
    const fmCriteria = data['acceptanceCriteria'];
    const hasCriteria = Array.isArray(fmCriteria) && fmCriteria.length > 0;
    if (!hasCriteria) {
      const harvested = extractAcceptanceCriteria(fm.content);
      if (harvested.length > 0) {
        data['acceptanceCriteria'] = harvested;
      }
    }

    return parseSpec(id, filePath, data);
  }

  throw new SpecParseError(id, filePath, `unsupported extension`);
}

export async function getSpecContent(
  paths: HarnessPaths,
  id: string,
): Promise<string | null> {
  const filePath = await paths.resolveSpecFile(id);
  if (filePath === null) return null;
  return fs.readFile(filePath, 'utf8');
}

function parseSpec(id: string, filePath: string, data: unknown): Spec {
  const result = Spec.safeParse(data);
  if (!result.success) {
    throw new SpecParseError(id, filePath, result.error.message);
  }
  if (result.data.id !== id) {
    throw new SpecParseError(
      id,
      filePath,
      `spec id mismatch: file resolves as '${id}' but content declares '${result.data.id}'`,
    );
  }
  return result.data;
}

/** Extract `- bullet` items beneath a `## Acceptance Criteria` heading. */
function extractAcceptanceCriteria(markdown: string): string[] {
  const lines = markdown.split(/\r?\n/);
  const out: string[] = [];
  let inSection = false;
  for (const line of lines) {
    const heading = /^#{1,6}\s+(.+?)\s*$/.exec(line);
    if (heading) {
      const title = heading[1] ?? '';
      const isAcceptance = /acceptance\s+criteria/i.test(title);
      if (isAcceptance) {
        inSection = true;
        continue;
      }
      if (inSection) {
        // Different heading ends the section.
        break;
      }
    }
    if (!inSection) continue;
    const bullet = /^\s*[-*]\s+(.*\S)\s*$/.exec(line);
    if (bullet && bullet[1]) {
      out.push(bullet[1]);
    }
  }
  return out;
}
