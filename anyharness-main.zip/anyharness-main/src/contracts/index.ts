// Owner: harness-contracts
// Tools: contract.spec.validate, contract.task.next, contract.task.complete.
// Resource: harness://contracts/specs/{id}. See SPEC §10.

export { loadSpec, getSpecContent, SpecParseError } from './spec-loader.js';
export {
  loadTask,
  saveTask,
  findOrCreateTaskFromSpec,
  TaskParseError,
} from './task-store.js';
export { validateSpec } from './validate.js';
export {
  nextTask,
  completeTask,
  TaskNotFoundError,
  TaskAlreadyCompletedError,
} from './lifecycle.js';
export { defaultRunners } from './runners.js';
export type { CheckRunners } from './runners.js';
export {
  handleContractSpecValidate,
  handleContractTaskNext,
  handleContractTaskComplete,
} from './handlers.js';
