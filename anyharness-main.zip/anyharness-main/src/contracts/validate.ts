// Owner: harness-contracts
// contract.spec.validate: load spec, run each declared check, aggregate to one
// ValidateSpecOutput. SPEC §10 (post-§15.6 closure: judges are NOT executed by
// the server — the MCP client performs inference). Behaviour regulation by
// definition.
//
// Sensors run in-line; judges are returned as `pending` sub-results carrying a
// pre-rendered prompt (`instructions`), the rubric schema, the loaded context
// (spec + target), and a `submission` hint pointing at `judge.record`. The
// agent resolves each pending review and either re-submits or attaches it as
// `evidence` in `contract.task.complete`.

import * as fs from 'node:fs/promises';
import { SensorOutput } from '../shared/schemas/sensor-output.js';
import type { Violation } from '../shared/schemas/violation.js';
import type { SpecCheck } from '../shared/schemas/spec.js';
import type {
  ContractSpecValidateInput,
  ContractSpecValidateOutput,
  PendingJudgeCheck,
} from '../shared/schemas/tools/contracts.js';
import type { JudgeReviewOutput } from '../shared/schemas/tools/judges.js';
import { ContractSpecValidateOutput as ContractSpecValidateOutputSchema } from '../shared/schemas/tools/contracts.js';
import type { HarnessPaths } from '../storage/paths.js';
import { loadSpec, getSpecContent } from './spec-loader.js';
import { renderRubric, RubricNotFoundError } from '../judges/index.js';
import type { CheckRunners } from './runners.js';

export async function validateSpec(
  paths: HarnessPaths,
  runners: CheckRunners,
  input: ContractSpecValidateInput,
): Promise<ContractSpecValidateOutput> {
  const tool = `contract_spec_validate:${input.id}`;

  const spec = await loadSpec(paths, input.id);
  if (spec === null) {
    return ContractSpecValidateOutputSchema.parse({
      tool,
      regulation: 'behaviour',
      passed: false,
      summary: `Spec '${input.id}' not found.`,
      inconclusive: true,
      inconclusiveReason: 'spec_not_found',
      violations: [],
    });
  }

  // Lazily load spec/target content; needed only when at least one judge check
  // is present. Cheap to compute and shared across multiple judge checks.
  let cachedSpecContent: string | null | undefined;
  let cachedTargetContent: string | undefined;

  const sensorResults: SensorOutput[] = [];
  const pending: PendingJudgeCheck[] = [];

  for (const check of spec.checks) {
    if (check.kind === 'sensor') {
      sensorResults.push(await runSensor(runners, check, input));
      continue;
    }

    // judge check: prepare a pending sub-result, do not run inference.
    if (cachedSpecContent === undefined) {
      cachedSpecContent = await getSpecContent(paths, spec.id);
    }
    if (cachedTargetContent === undefined) {
      cachedTargetContent = await readArtifactContent(input.artifact);
    }
    const bindings: JudgeBindings = {
      artifact: input.artifact,
      targetContent: cachedTargetContent,
    };
    if (cachedSpecContent !== null && cachedSpecContent !== undefined) {
      bindings.specContent = cachedSpecContent;
    }
    pending.push(await prepareJudgePending(paths, check.rubric, bindings));
  }

  const sensorTotal = sensorResults.length;
  const sensorPassed = sensorResults.filter((r) => r.passed === true).length;
  const sensorInconclusive = sensorResults.filter((r) => r.inconclusive === true).length;
  const sensorFailed = sensorResults.filter(
    (r) => r.passed === false && !r.inconclusive,
  ).length;

  const totalChecks = sensorTotal + pending.length;
  const pendingCount = pending.length;

  // Aggregation (per README "Tool: contract.spec.validate" + user spec):
  // - passed: only true when every sensor passed AND no judge checks pending.
  // - inconclusive: true only if no sensor failed AND at least one sensor was
  //   inconclusive AND there are no pending judges. (`pending` is its own
  //   state, not "inconclusive".)
  // - pending non-empty: passed=false, inconclusive=false.
  const allSensorsPassed = sensorTotal === 0 || sensorPassed === sensorTotal;
  const aggregatePassed = allSensorsPassed && pendingCount === 0;
  const aggregateInconclusive =
    !aggregatePassed &&
    pendingCount === 0 &&
    sensorFailed === 0 &&
    sensorInconclusive > 0;

  const violations: Violation[] = sensorResults.flatMap((r) => r.violations);

  let summary: string;
  if (totalChecks === 0) {
    summary = 'No checks declared on spec.';
  } else if (pendingCount > 0) {
    summary =
      `${sensorPassed}/${totalChecks} checks passed; ` +
      `${pendingCount} judge ${pendingCount === 1 ? 'check' : 'checks'} pending agent review.`;
  } else {
    summary = `${sensorPassed}/${totalChecks} checks passed`;
  }

  const output: ContractSpecValidateOutput = {
    tool,
    regulation: 'behaviour',
    passed: aggregatePassed,
    summary,
    inconclusive: aggregateInconclusive,
    violations,
  };
  if (aggregateInconclusive) {
    const reasons = sensorResults
      .filter((r) => r.inconclusive)
      .map((r) => r.inconclusiveReason ?? `${r.tool}_inconclusive`);
    output.inconclusiveReason = reasons.join(', ');
  }
  if (pendingCount > 0) {
    output.pending = pending;
  }

  return ContractSpecValidateOutputSchema.parse(output);
}

async function runSensor(
  runners: CheckRunners,
  check: Extract<SpecCheck, { kind: 'sensor' }>,
  input: ContractSpecValidateInput,
): Promise<SensorOutput> {
  try {
    return await runners.sensor({ id: check.id, target: input.artifact });
  } catch (err) {
    return inconclusiveFromError(`sensor:${check.id}`, err);
  }
}

function inconclusiveFromError(toolId: string, err: unknown): SensorOutput {
  const message = err instanceof Error ? err.message : String(err);
  return SensorOutput.parse({
    tool: toolId,
    regulation: 'behaviour',
    passed: false,
    summary: `Check '${toolId}' could not run.`,
    inconclusive: true,
    inconclusiveReason: message,
    violations: [],
  });
}

/**
 * Reads the artifact path's file content for inclusion in judge `context`.
 * Mirrors what `judge.review` is expected to do (server performs the IO so the
 * agent doesn't have to). Falls back to the raw string when the path can't be
 * read (already-inlined content, non-file artifacts, missing file). Errors are
 * never propagated — judge inconclusivity is the rubric's call, not ours.
 */
async function readArtifactContent(artifact: string): Promise<string> {
  try {
    return await fs.readFile(artifact, 'utf8');
  } catch {
    return artifact;
  }
}

interface JudgeBindings {
  artifact: string;
  specContent?: string;
  targetContent: string;
}

/**
 * Prepares a pending judge sub-result: renders the rubric through the shared
 * judges helper and packages
 * `{ instructions, schema, context, submission }` for the agent to consume.
 *
 * Rubric not found / unreadable → surfaces a degenerate pending entry with
 * empty instructions and an `inconclusiveReason` field set so the agent can
 * skip or re-attempt the check. Aggregator never throws on infra failures
 * (SPEC §10 inconclusive-not-throw rule).
 */
async function prepareJudgePending(
  paths: HarnessPaths,
  rubricId: string,
  bindings: JudgeBindings,
): Promise<PendingJudgeCheck> {
  let rendered: JudgeReviewOutput;
  try {
    rendered = await renderRubric(
      paths,
      {
        rubric_id: rubricId,
        target: bindings.targetContent,
      },
      {
        skipTargetSizeGuard: true,
        submissionTarget: bindings.artifact,
        ...(bindings.specContent !== undefined
          ? { specContent: bindings.specContent }
          : {}),
      },
    );
  } catch (err) {
    if (err instanceof RubricNotFoundError) {
      return pendingInconclusive(rubricId, bindings, 'rubric_not_found');
    }
    return pendingInconclusive(rubricId, bindings, `rubric_load_error: ${asMessage(err)}`);
  }

  return {
    kind: 'judge',
    rubric: rendered.rubric_id,
    status: 'requires_agent_review',
    instructions: rendered.instructions,
    schema: pendingSchema(rendered.schema),
    context: rendered.context,
    submission: rendered.submission,
  };
}

function pendingSchema(schema: unknown): Record<string, unknown> {
  if (schema && typeof schema === 'object' && !Array.isArray(schema)) {
    return schema as Record<string, unknown>;
  }
  return {};
}

function pendingInconclusive(
  rubricId: string,
  bindings: JudgeBindings,
  reason: string,
): PendingJudgeCheck {
  const context: PendingJudgeCheck['context'] = {
    target: bindings.targetContent,
  };
  if (bindings.specContent !== undefined) {
    context.spec = bindings.specContent;
  }
  return {
    kind: 'judge',
    rubric: rubricId,
    status: 'requires_agent_review',
    instructions: '',
    schema: {},
    context,
    submission: {
      tool: 'judge_record',
      correlation: { rubric_id: rubricId, target: bindings.artifact },
    },
    inconclusiveReason: reason,
  };
}

function asMessage(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}
