// Owner: harness-contracts
// Persistence for .harness/contracts/tasks/<task_id>.yaml. SPEC §10.

import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import { parse as parseYaml, stringify as stringifyYaml } from 'yaml';
import { Task } from '../shared/schemas/task.js';
import type { Spec, SpecTaskRef } from '../shared/schemas/spec.js';
import type { HarnessPaths } from '../storage/paths.js';

export class TaskParseError extends Error {
  constructor(
    public readonly taskId: string,
    public readonly filePath: string,
    message: string,
  ) {
    super(`Failed to parse task '${taskId}' at ${filePath}: ${message}`);
    this.name = 'TaskParseError';
  }
}

async function exists(p: string): Promise<boolean> {
  try {
    await fs.access(p);
    return true;
  } catch {
    return false;
  }
}

export async function loadTask(
  paths: HarnessPaths,
  task_id: string,
): Promise<Task | null> {
  const filePath = paths.taskFile(task_id);
  if (!(await exists(filePath))) return null;
  const raw = await fs.readFile(filePath, 'utf8');
  let parsed: unknown;
  try {
    parsed = parseYaml(raw);
  } catch (err) {
    throw new TaskParseError(task_id, filePath, `invalid YAML: ${(err as Error).message}`);
  }
  const result = Task.safeParse(parsed);
  if (!result.success) {
    throw new TaskParseError(task_id, filePath, result.error.message);
  }
  if (result.data.id !== task_id) {
    throw new TaskParseError(
      task_id,
      filePath,
      `task id mismatch: file '${task_id}' but content declares '${result.data.id}'`,
    );
  }
  return result.data;
}

export async function saveTask(paths: HarnessPaths, task: Task): Promise<void> {
  // Validate before persisting.
  const validated = Task.parse(task);
  const filePath = paths.taskFile(validated.id);
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  const yaml = stringifyYaml(validated);
  await fs.writeFile(filePath, yaml, 'utf8');
}

export async function findOrCreateTaskFromSpec(
  paths: HarnessPaths,
  spec: Spec,
  taskRef: SpecTaskRef,
): Promise<Task> {
  const existing = await loadTask(paths, taskRef.id);
  if (existing !== null) return existing;

  const fresh: Task = Task.parse({
    id: taskRef.id,
    spec_id: spec.id,
    description: taskRef.description,
    status: 'pending',
    evidence: [],
    completedAt: null,
  });
  await saveTask(paths, fresh);
  return fresh;
}
