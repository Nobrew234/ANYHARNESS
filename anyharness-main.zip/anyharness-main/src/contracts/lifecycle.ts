// Owner: harness-contracts
// Task lifecycle: contract.task.next, contract.task.complete. SPEC §10.

import { Task, type Evidence } from '../shared/schemas/task.js';
import type { HarnessPaths } from '../storage/paths.js';
import { loadSpec } from './spec-loader.js';
import { findOrCreateTaskFromSpec, loadTask, saveTask } from './task-store.js';

export class TaskNotFoundError extends Error {
  constructor(public readonly taskId: string) {
    super(`task '${taskId}' not found`);
    this.name = 'TaskNotFoundError';
  }
}

export class TaskAlreadyCompletedError extends Error {
  constructor(public readonly taskId: string) {
    super(`task '${taskId}' is already completed`);
    this.name = 'TaskAlreadyCompletedError';
  }
}

export async function nextTask(
  paths: HarnessPaths,
  spec_id: string,
): Promise<Task | null> {
  const spec = await loadSpec(paths, spec_id);
  if (spec === null) return null;

  for (const taskRef of spec.tasks) {
    const task = await findOrCreateTaskFromSpec(paths, spec, taskRef);
    if (task.status === 'completed') {
      continue;
    }
    if (task.status === 'pending') {
      const promoted: Task = Task.parse({ ...task, status: 'in_progress' });
      await saveTask(paths, promoted);
      return promoted;
    }
    // in_progress
    return task;
  }
  return null;
}

export async function completeTask(
  paths: HarnessPaths,
  task_id: string,
  evidence: Evidence[],
): Promise<Task> {
  const task = await loadTask(paths, task_id);
  if (task === null) throw new TaskNotFoundError(task_id);
  if (task.status === 'completed') throw new TaskAlreadyCompletedError(task_id);

  const updated: Task = Task.parse({
    ...task,
    status: 'completed',
    evidence: [...task.evidence, ...evidence],
    completedAt: new Date().toISOString(),
  });
  await saveTask(paths, updated);
  return updated;
}
