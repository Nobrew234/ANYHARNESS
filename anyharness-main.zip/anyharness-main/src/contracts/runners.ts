// Owner: harness-contracts
// Adapter pattern that lets contract.spec.validate dispatch sensor checks
// without taking a hard dependency on the sensors package internals.
//
// Note (post-§15.6 closure): judges are NOT dispatched here. The MCP client
// performs inference; `contract.spec.validate` returns judge checks as
// `pending` sub-results (see ./validate.ts). This adapter is therefore
// sensor-only.

import type { SensorOutput } from '../shared/schemas/sensor-output.js';
import type { SensorRunInput } from '../shared/schemas/tools/sensors.js';
import type { HarnessPaths } from '../storage/paths.js';
import { handleSensorRun } from '../sensors/index.js';

export interface CheckRunners {
  sensor: (input: SensorRunInput) => Promise<SensorOutput>;
}

/** Build the default check-dispatch adapter. */
export function defaultRunners(paths: HarnessPaths): CheckRunners {
  return {
    sensor: (input) => handleSensorRun(paths, input),
  };
}
