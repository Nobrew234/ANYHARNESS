// Owner: harness-contracts
// MCP tool handlers for contract.spec.validate, contract.task.next,
// contract.task.complete. Inputs are pre-validated by the server layer; we
// re-validate outputs against schemas to keep the protocol surface honest.

import {
  ContractSpecValidateOutput as ContractSpecValidateOutputSchema,
  ContractTaskNextOutput as ContractTaskNextOutputSchema,
  ContractTaskCompleteOutput as ContractTaskCompleteOutputSchema,
} from '../shared/schemas/tools/contracts.js';
import type {
  ContractSpecValidateInput,
  ContractSpecValidateOutput,
  ContractTaskNextInput,
  ContractTaskNextOutput,
  ContractTaskCompleteInput,
  ContractTaskCompleteOutput,
} from '../shared/schemas/tools/contracts.js';
import type { HarnessPaths } from '../storage/paths.js';
import { validateSpec } from './validate.js';
import { nextTask, completeTask } from './lifecycle.js';
import type { CheckRunners } from './runners.js';

export async function handleContractSpecValidate(
  paths: HarnessPaths,
  runners: CheckRunners,
  input: ContractSpecValidateInput,
): Promise<ContractSpecValidateOutput> {
  const result = await validateSpec(paths, runners, input);
  return ContractSpecValidateOutputSchema.parse(result);
}

export async function handleContractTaskNext(
  paths: HarnessPaths,
  input: ContractTaskNextInput,
): Promise<ContractTaskNextOutput> {
  const task = await nextTask(paths, input.spec_id);
  return ContractTaskNextOutputSchema.parse({ task });
}

export async function handleContractTaskComplete(
  paths: HarnessPaths,
  input: ContractTaskCompleteInput,
): Promise<ContractTaskCompleteOutput> {
  const task = await completeTask(paths, input.task_id, input.evidence);
  return ContractTaskCompleteOutputSchema.parse({ task });
}
