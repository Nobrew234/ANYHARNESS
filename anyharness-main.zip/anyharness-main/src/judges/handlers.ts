// Owner: harness-judges
// MCP tool handlers: judge.list, judge.review, judge.record.
// SPEC §3, §4, §5.7, §7, §9, §15.6.
//
// The server does NOT call an LLM. handleJudgeReview returns a prompt+schema
// envelope for the connected MCP client to evaluate; handleJudgeRecord
// receives the verdict, validates it, normalizes it to the SPEC §9 envelope,
// and emits a SteeringEvent.

import type {
  JudgeListInput,
  JudgeListOutput,
  JudgeRecordInput,
  JudgeRecordOutput,
  JudgeReviewInput,
  JudgeReviewOutput,
} from '../shared/schemas/tools/judges.js';
import type { HarnessPaths } from '../storage/paths.js';
import { loadRubrics } from './rubric-loader.js';
import {
  prepareJudgeReview,
  recordJudgeResult,
  RubricNotFoundError,
  SpecNotFoundError,
  TargetTooLargeError,
} from './runner.js';

export async function handleJudgeList(
  paths: HarnessPaths,
  input: JudgeListInput,
): Promise<JudgeListOutput> {
  const all = await loadRubrics(paths);
  const items: JudgeListOutput['rubrics'] = [];
  for (const [id, rubric] of all) {
    if (input.rubric && input.rubric !== id) continue;
    items.push({
      rubric_id: id,
      regulation: rubric.frontmatter.regulation,
      description: rubric.frontmatter.description,
    });
  }
  items.sort((a, b) => a.rubric_id.localeCompare(b.rubric_id));
  return { rubrics: items };
}

/**
 * `judge.review` — phase 1. Renders the rubric prompt, loads the spec (if
 * any), and returns the bundle the client needs to perform the review with
 * its own model. Does NOT call an LLM and does NOT emit a SteeringEvent.
 */
export async function handleJudgeReview(
  paths: HarnessPaths,
  input: JudgeReviewInput,
): Promise<JudgeReviewOutput> {
  return prepareJudgeReview(paths, input);
}

/**
 * `judge.record` — phase 2. Validates the client-produced verdict against the
 * rubric's JSON Schema, normalizes it to the SPEC §9 envelope, and writes a
 * SteeringEvent. Schema failures are surfaced as `inconclusive: true` with
 * `inconclusiveReason: "result_failed_schema_validation"` and a list of
 * offending paths in `validationErrors`.
 *
 * Idempotency: the schema validation result is deterministic given the same
 * inputs, but the steering log is append-only — duplicate calls produce
 * duplicate events on purpose, so the audit trail captures real intent.
 */
export async function handleJudgeRecord(
  paths: HarnessPaths,
  input: JudgeRecordInput,
): Promise<JudgeRecordOutput> {
  return recordJudgeResult(paths, input);
}

// Re-exporting the typed errors lets the MCP server map them to MCP error
// codes without depending on the runner module directly.
export { RubricNotFoundError, SpecNotFoundError, TargetTooLargeError };
