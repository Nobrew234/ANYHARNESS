// Owner: harness-judges
// Tools: judge.list, judge.review, judge.record. SPEC §3, §4, §5.7, §7, §9, §15.6.
//
// As of §15.6 the server does NOT call an LLM — the connected MCP client
// performs the inference. There is no `LlmRunner`, no `AnthropicRunner`, and
// no `ANTHROPIC_API_KEY` anywhere in this package.

export type { LoadedRubric } from './rubric-loader.js';
export { loadRubric, loadRubrics } from './rubric-loader.js';
export {
  prepareJudgeReview,
  renderRubric,
  recordJudgeResult,
  RubricNotFoundError,
  SpecNotFoundError,
  TargetTooLargeError,
} from './runner.js';
export {
  handleJudgeList,
  handleJudgeReview,
  handleJudgeRecord,
} from './handlers.js';
