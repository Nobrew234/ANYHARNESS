// Owner: harness-judges
// Loads .harness/judges/<rubric>.md (frontmatter + body) plus optional .schema.json.
// SPEC §4, §6, §7.

import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import matter from 'gray-matter';
import { JudgeRubricFrontmatter } from '../shared/schemas/judge-rubric.js';
import type { HarnessPaths } from '../storage/paths.js';

export interface LoadedRubric {
  frontmatter: JudgeRubricFrontmatter;
  body: string;
  schemaJson?: unknown;
  schemaJsonRaw?: string;
  filePath: string;
}

async function exists(p: string): Promise<boolean> {
  try {
    await fs.access(p);
    return true;
  } catch {
    return false;
  }
}

async function readRubricFile(filePath: string): Promise<LoadedRubric> {
  const raw = await fs.readFile(filePath, 'utf8');
  const parsed = matter(raw);
  const frontmatter = JudgeRubricFrontmatter.parse(parsed.data);
  const body = parsed.content.replace(/^\s+/, '');

  const dir = path.dirname(filePath);
  const schemaPath = path.join(dir, `${frontmatter.id}.schema.json`);
  let schemaJson: unknown;
  let schemaJsonRaw: string | undefined;
  if (await exists(schemaPath)) {
    schemaJsonRaw = await fs.readFile(schemaPath, 'utf8');
    try {
      schemaJson = JSON.parse(schemaJsonRaw);
    } catch (err) {
      throw new Error(
        `Failed to parse rubric schema JSON at ${schemaPath}: ${(err as Error).message}`,
      );
    }
  }

  const result: LoadedRubric = { frontmatter, body, filePath };
  if (schemaJson !== undefined) result.schemaJson = schemaJson;
  if (schemaJsonRaw !== undefined) result.schemaJsonRaw = schemaJsonRaw;
  return result;
}

export async function loadRubrics(
  paths: HarnessPaths,
): Promise<Map<string, LoadedRubric>> {
  const result = new Map<string, LoadedRubric>();
  if (!(await exists(paths.judges))) {
    return result;
  }
  const entries = await fs.readdir(paths.judges, { withFileTypes: true });
  for (const dirent of entries) {
    if (!dirent.isFile()) continue;
    if (!dirent.name.endsWith('.md')) continue;
    const filePath = path.join(paths.judges, dirent.name);
    const loaded = await readRubricFile(filePath);
    if (result.has(loaded.frontmatter.id)) {
      throw new Error(
        `Duplicate rubric id '${loaded.frontmatter.id}' (file: ${filePath})`,
      );
    }
    result.set(loaded.frontmatter.id, loaded);
  }
  return result;
}

export async function loadRubric(
  paths: HarnessPaths,
  rubricId: string,
): Promise<LoadedRubric | null> {
  const filePath = paths.judgeMd(rubricId);
  if (!(await exists(filePath))) return null;
  return readRubricFile(filePath);
}
