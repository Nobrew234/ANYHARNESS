// Owner: harness-judges
// SPEC §3, §4, §5.7, §7, §10, §15.6.
//
// The server NEVER calls an LLM. `prepareJudgeReview` renders the rubric
// prompt and packages context for the connected MCP client to evaluate.
// `recordJudgeResult` validates the client's verdict against the rubric's
// JSON Schema, normalizes it into a SPEC §9 envelope, and appends a
// SteeringEvent.

import * as fs from 'node:fs/promises';
import { z } from 'zod';
import { SensorOutput } from '../shared/schemas/sensor-output.js';
import type {
  JudgeRecordInput,
  JudgeRecordOutput,
  JudgeReviewInput,
  JudgeReviewOutput,
} from '../shared/schemas/tools/judges.js';
import type { Regulation } from '../shared/schemas/common.js';
import { recordSteeringEvent } from '../sessions/steering-log.js';
import type { HarnessPaths } from '../storage/paths.js';
import { loadRubric, type LoadedRubric } from './rubric-loader.js';

export class RubricNotFoundError extends Error {
  constructor(public readonly rubricId: string) {
    super(`rubric '${rubricId}' not found in .harness/judges/`);
    this.name = 'RubricNotFoundError';
  }
}

const DEFAULT_TARGET_MAX_LINES = 2000;

// ---------------------------------------------------------------------------
// Prompt rendering
// ---------------------------------------------------------------------------

function renderPrompt(
  body: string,
  bindings: { target: string; spec?: string; schema?: string },
): string {
  return body
    .replaceAll('<<<TARGET>>>', bindings.target)
    .replaceAll('<<<SPEC>>>', bindings.spec ?? '(no spec provided)')
    .replaceAll('<<<SCHEMA>>>', bindings.schema ?? '(no schema provided)');
}

async function readSpecContent(
  paths: HarnessPaths,
  specId: string,
): Promise<string | null> {
  const resolved = await paths.resolveSpecFile(specId);
  if (!resolved) return null;
  return fs.readFile(resolved, 'utf8');
}

export interface PrepareJudgeReviewOptions {
  /** Skip the line-count guard when the caller has already chunked input. */
  skipTargetSizeGuard?: boolean;
}

export interface RenderRubricOptions extends PrepareJudgeReviewOptions {
  /**
   * Already-resolved spec content. Callers that loaded a spec through another
   * path can pass it directly instead of resolving `spec_id` again.
   */
  specContent?: string;
  /**
   * Value to place in the `judge.record` correlation target. Defaults to the
   * rendered target text.
   */
  submissionTarget?: string;
}

export async function renderRubric(
  paths: HarnessPaths,
  input: JudgeReviewInput,
  options: RenderRubricOptions = {},
): Promise<JudgeReviewOutput> {
  const rubric = await loadRubric(paths, input.rubric_id);
  if (!rubric) throw new RubricNotFoundError(input.rubric_id);

  const regulation = rubric.frontmatter.regulation;

  if (!options.skipTargetSizeGuard) {
    const lines = input.target.split(/\r?\n/).length;
    if (lines > DEFAULT_TARGET_MAX_LINES) {
      throw new TargetTooLargeError(input.rubric_id, lines, DEFAULT_TARGET_MAX_LINES);
    }
  }

  let specContent = options.specContent;
  if (specContent === undefined && input.spec_id) {
    const content = await readSpecContent(paths, input.spec_id);
    if (content === null) {
      throw new SpecNotFoundError(input.spec_id);
    }
    specContent = content;
  }

  const instructions = renderPrompt(rubric.body, {
    target: input.target,
    ...(specContent !== undefined ? { spec: specContent } : {}),
    ...(rubric.schemaJsonRaw !== undefined ? { schema: rubric.schemaJsonRaw } : {}),
  });

  return {
    rubric_id: rubric.frontmatter.id,
    regulation,
    instructions,
    schema: rubric.schemaJson ?? null,
    context: {
      target: input.target,
      ...(specContent !== undefined ? { spec: specContent } : {}),
    },
    submission: {
      tool: 'judge_record',
      correlation: {
        rubric_id: rubric.frontmatter.id,
        target: options.submissionTarget ?? input.target,
      },
    },
  };
}

// ---------------------------------------------------------------------------
// judge.review — preparation only. Returns instructions+schema+context, no
// verdict. Does NOT emit a SteeringEvent (that is judge.record's job).
// ---------------------------------------------------------------------------

export async function prepareJudgeReview(
  paths: HarnessPaths,
  input: JudgeReviewInput,
  options: PrepareJudgeReviewOptions = {},
): Promise<JudgeReviewOutput> {
  return renderRubric(paths, input, options);
}

export class TargetTooLargeError extends Error {
  constructor(
    public readonly rubricId: string,
    public readonly lines: number,
    public readonly limit: number,
  ) {
    super(
      `target for rubric '${rubricId}' is ${lines} lines (>${limit}); chunk before review`,
    );
    this.name = 'TargetTooLargeError';
  }
}

export class SpecNotFoundError extends Error {
  constructor(public readonly specId: string) {
    super(`spec '${specId}' not found in .harness/contracts/specs/`);
    this.name = 'SpecNotFoundError';
  }
}

// ---------------------------------------------------------------------------
// judge.record — validate the client's verdict, normalize, and log.
// ---------------------------------------------------------------------------

interface ValidationFailure {
  path: string;
  message: string;
}

interface SchemaConstants {
  /** From `properties.tool.const`. */
  tool?: string;
  /** From `properties.regulation.const`. */
  regulation?: string;
}

function readSchemaConstants(schemaJson: unknown): SchemaConstants {
  if (
    schemaJson === null ||
    typeof schemaJson !== 'object' ||
    Array.isArray(schemaJson)
  ) {
    return {};
  }
  const props = (schemaJson as { properties?: unknown }).properties;
  if (!props || typeof props !== 'object' || Array.isArray(props)) return {};
  const out: SchemaConstants = {};
  const toolProp = (props as Record<string, unknown>)['tool'];
  if (toolProp && typeof toolProp === 'object' && !Array.isArray(toolProp)) {
    const c = (toolProp as { const?: unknown }).const;
    if (typeof c === 'string') out.tool = c;
  }
  const regProp = (props as Record<string, unknown>)['regulation'];
  if (regProp && typeof regProp === 'object' && !Array.isArray(regProp)) {
    const c = (regProp as { const?: unknown }).const;
    if (typeof c === 'string') out.regulation = c;
  }
  return out;
}

function coerceIdentity(
  parsed: unknown,
  rubricId: string,
  regulation: Regulation,
): unknown {
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return parsed;
  }
  const obj = { ...(parsed as Record<string, unknown>) };
  if (typeof obj['tool'] !== 'string' || obj['tool'].length === 0) {
    obj['tool'] = rubricId;
  }
  if (typeof obj['regulation'] !== 'string') {
    obj['regulation'] = regulation;
  }
  return obj;
}

function zodErrorToFailures(error: z.ZodError): ValidationFailure[] {
  return error.issues.map((issue) => ({
    path: issue.path.length === 0 ? '(root)' : issue.path.join('.'),
    message: issue.message,
  }));
}

function inconclusiveEnvelope(
  rubric: LoadedRubric,
  reason: string,
  summary: string,
  validationErrors?: ValidationFailure[],
): JudgeRecordOutput {
  const out: JudgeRecordOutput = {
    tool: rubric.frontmatter.id,
    regulation: rubric.frontmatter.regulation,
    passed: false,
    summary,
    inconclusive: true,
    inconclusiveReason: reason,
    violations: [],
  };
  if (validationErrors && validationErrors.length > 0) {
    out.validationErrors = validationErrors;
  }
  return out;
}

export async function recordJudgeResult(
  paths: HarnessPaths,
  input: JudgeRecordInput,
): Promise<JudgeRecordOutput> {
  const rubric = await loadRubric(paths, input.rubric_id);
  if (!rubric) throw new RubricNotFoundError(input.rubric_id);

  // Inject canonical identity fields if the client omitted them — saves
  // round-trips for clients whose model produces a verdict without echoing
  // the rubric metadata.
  const candidate = coerceIdentity(
    input.result,
    rubric.frontmatter.id,
    rubric.frontmatter.regulation,
  );

  // Step 1: validate against the canonical SPEC §9 envelope (zod). This is
  // the shared contract every rubric output must satisfy.
  const parsed = SensorOutput.safeParse(candidate);

  // Step 2: enforce rubric-specific `const` constraints from the rubric's own
  // JSON Schema (e.g. `tool === "spec-adherence"`, `regulation === "behaviour"`).
  let constViolations: ValidationFailure[] = [];
  if (parsed.success) {
    const constants = readSchemaConstants(rubric.schemaJson);
    if (constants.tool !== undefined && parsed.data.tool !== constants.tool) {
      constViolations.push({
        path: 'tool',
        message: `expected '${constants.tool}' (rubric const), got '${parsed.data.tool}'`,
      });
    }
    if (
      constants.regulation !== undefined &&
      parsed.data.regulation !== constants.regulation
    ) {
      constViolations.push({
        path: 'regulation',
        message: `expected '${constants.regulation}' (rubric const), got '${parsed.data.regulation}'`,
      });
    }
  }

  let envelope: JudgeRecordOutput;

  if (!parsed.success) {
    envelope = inconclusiveEnvelope(
      rubric,
      'result_failed_schema_validation',
      'result_failed_schema_validation',
      zodErrorToFailures(parsed.error),
    );
  } else if (constViolations.length > 0) {
    envelope = inconclusiveEnvelope(
      rubric,
      'result_failed_schema_validation',
      'result_failed_schema_validation',
      constViolations,
    );
  } else {
    envelope = {
      tool: parsed.data.tool,
      regulation: parsed.data.regulation,
      passed: parsed.data.passed,
      summary: parsed.data.summary,
      inconclusive: parsed.data.inconclusive,
      violations: parsed.data.violations,
    };
    if (parsed.data.inconclusiveReason !== undefined) {
      envelope.inconclusiveReason = parsed.data.inconclusiveReason;
    }
  }

  // Step 3: append SteeringEvent. We log every record call, including
  // schema-invalid ones — losing those would hide a class of regressions.
  // judge.review intentionally does NOT log; only judge.record does (§15.6).
  await recordSteeringEvent(paths, {
    timestamp: new Date().toISOString(),
    kind: 'judge',
    id: rubric.frontmatter.id,
    target: input.target,
    regulation: envelope.regulation,
    passed: envelope.passed,
    inconclusive: envelope.inconclusive,
    violationCount: envelope.violations.length,
    violations: envelope.violations,
  });

  return envelope;
}
