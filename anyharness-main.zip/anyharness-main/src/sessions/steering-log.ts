// Owner: harness-sessions — single-writer API for .harness/.local/steering/log.jsonl. SPEC §8.
// All writes go through recordSteeringEvent. Append-only jsonl.
import * as fs from 'node:fs/promises';
import {
  SteeringEvent,
  type SteeringEvent as SteeringEventType,
} from '../shared/schemas/steering-event.js';
import { ensureLocalDirs, type HarnessPaths } from '../storage/paths.js';

async function fileExists(p: string): Promise<boolean> {
  try {
    await fs.access(p);
    return true;
  } catch {
    return false;
  }
}

export async function recordSteeringEvent(
  paths: HarnessPaths,
  event: SteeringEventType,
): Promise<void> {
  const validated = SteeringEvent.parse(event);
  await ensureLocalDirs(paths);
  await fs.appendFile(
    paths.local.steeringLog,
    JSON.stringify(validated) + '\n',
    'utf8',
  );
}

export interface ReadSteeringLogOptions {
  sinceMs?: number;
}

export async function readSteeringLog(
  paths: HarnessPaths,
  opts: ReadSteeringLogOptions = {},
): Promise<SteeringEventType[]> {
  if (!(await fileExists(paths.local.steeringLog))) return [];
  const raw = await fs.readFile(paths.local.steeringLog, 'utf8');
  const lines = raw.split('\n').filter((l) => l.length > 0);
  const events: SteeringEventType[] = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line === undefined) continue;
    let json: unknown;
    try {
      json = JSON.parse(line);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.warn(
        `[steering-log] skipping invalid JSON at line ${i}: ${(err as Error).message}`,
      );
      continue;
    }
    const parsed = SteeringEvent.safeParse(json);
    if (!parsed.success) {
      // eslint-disable-next-line no-console
      console.warn(
        `[steering-log] skipping invalid event at line ${i}: ${parsed.error.message}`,
      );
      continue;
    }
    if (opts.sinceMs !== undefined) {
      const tsMs = Date.parse(parsed.data.timestamp);
      if (Number.isNaN(tsMs) || tsMs < opts.sinceMs) continue;
    }
    events.push(parsed.data);
  }
  return events;
}
