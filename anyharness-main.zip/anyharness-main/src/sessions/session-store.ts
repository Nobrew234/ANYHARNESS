// Owner: harness-sessions — persistence for .harness/.local/sessions/<id>.jsonl. SPEC §11.
// Append-only jsonl. Single-writer surface for session events.
import * as fs from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import {
  SessionEvent,
  SessionHeader,
  type SessionEvent as SessionEventType,
  type SessionHeader as SessionHeaderType,
} from '../shared/schemas/session-event.js';
import type { SessionStartInput } from '../shared/schemas/tools/sessions.js';
import { ensureLocalDirs, type HarnessPaths } from '../storage/paths.js';

export class SessionNotFoundError extends Error {
  constructor(public readonly sessionId: string) {
    super(`session '${sessionId}' not found`);
    this.name = 'SessionNotFoundError';
  }
}

export class SessionParseError extends Error {
  constructor(
    public readonly sessionId: string,
    public readonly line: number,
    public readonly cause: Error,
  ) {
    super(
      `failed to parse session '${sessionId}' at line ${line}: ${cause.message}`,
    );
    this.name = 'SessionParseError';
  }
}

export interface StartSessionResult {
  session_id: string;
  header: SessionHeaderType;
  startedAt: string;
}

async function fileExists(p: string): Promise<boolean> {
  try {
    await fs.access(p);
    return true;
  } catch {
    return false;
  }
}

export async function startSession(
  paths: HarnessPaths,
  input: SessionStartInput,
): Promise<StartSessionResult> {
  await ensureLocalDirs(paths);
  const session_id = randomUUID();
  const startedAt = new Date().toISOString();
  const headerCandidate: Record<string, unknown> = {
    session_id,
    startedAt,
  };
  if (input.workflow !== undefined) headerCandidate['workflow'] = input.workflow;
  if (input.contract_id !== undefined)
    headerCandidate['contract_id'] = input.contract_id;
  const header = SessionHeader.parse(headerCandidate);
  const filePath = paths.sessionFile(session_id);
  await fs.writeFile(filePath, JSON.stringify(header) + '\n', {
    encoding: 'utf8',
    flag: 'wx',
  });
  return { session_id, header, startedAt };
}

export interface AppendEventResult {
  appended: true;
  eventCount: number;
}

export async function appendEvent(
  paths: HarnessPaths,
  session_id: string,
  event: SessionEventType,
): Promise<AppendEventResult> {
  const validated = SessionEvent.parse(event);
  const filePath = paths.sessionFile(session_id);
  if (!(await fileExists(filePath))) {
    throw new SessionNotFoundError(session_id);
  }
  await fs.appendFile(filePath, JSON.stringify(validated) + '\n', 'utf8');
  // eventCount = total lines - 1 (header is line 0)
  const raw = await fs.readFile(filePath, 'utf8');
  const lines = raw.split('\n').filter((l) => l.length > 0);
  const eventCount = Math.max(0, lines.length - 1);
  return { appended: true, eventCount };
}

export interface GetSessionResult {
  header: SessionHeaderType;
  events: SessionEventType[];
}

export async function getSession(
  paths: HarnessPaths,
  session_id: string,
): Promise<GetSessionResult> {
  const filePath = paths.sessionFile(session_id);
  if (!(await fileExists(filePath))) {
    throw new SessionNotFoundError(session_id);
  }
  const raw = await fs.readFile(filePath, 'utf8');
  const lines = raw.split('\n').filter((l) => l.length > 0);
  if (lines.length === 0) {
    throw new SessionParseError(
      session_id,
      0,
      new Error('session file is empty'),
    );
  }
  const headerLine = lines[0];
  if (headerLine === undefined) {
    throw new SessionParseError(
      session_id,
      0,
      new Error('missing header line'),
    );
  }
  let headerJson: unknown;
  try {
    headerJson = JSON.parse(headerLine);
  } catch (err) {
    throw new SessionParseError(session_id, 0, err as Error);
  }
  const headerResult = SessionHeader.safeParse(headerJson);
  if (!headerResult.success) {
    throw new SessionParseError(session_id, 0, new Error(headerResult.error.message));
  }
  const events: SessionEventType[] = [];
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    if (line === undefined) continue;
    let json: unknown;
    try {
      json = JSON.parse(line);
    } catch (err) {
      throw new SessionParseError(session_id, i, err as Error);
    }
    const parsed = SessionEvent.safeParse(json);
    if (!parsed.success) {
      throw new SessionParseError(session_id, i, new Error(parsed.error.message));
    }
    events.push(parsed.data);
  }
  return { header: headerResult.data, events };
}
