// Owner: harness-sessions — thin handlers for session.* tools. SPEC §4, §11.
import type {
  SessionStartInput,
  SessionStartOutput,
  SessionAppendInput,
  SessionAppendOutput,
  SessionGetInput,
  SessionGetOutput,
} from '../shared/schemas/tools/sessions.js';
import type { HarnessPaths } from '../storage/paths.js';
import { startSession, appendEvent, getSession } from './session-store.js';

export async function handleSessionStart(
  paths: HarnessPaths,
  input: SessionStartInput,
): Promise<SessionStartOutput> {
  const result = await startSession(paths, input);
  return {
    session_id: result.session_id,
    startedAt: result.startedAt,
  };
}

export async function handleSessionAppend(
  paths: HarnessPaths,
  input: SessionAppendInput,
): Promise<SessionAppendOutput> {
  const result = await appendEvent(paths, input.session_id, input.event);
  return {
    appended: result.appended,
    eventCount: result.eventCount,
  };
}

export async function handleSessionGet(
  paths: HarnessPaths,
  input: SessionGetInput,
): Promise<SessionGetOutput> {
  const result = await getSession(paths, input.session_id);
  return {
    header: result.header,
    events: result.events,
  };
}
