// Owner: harness-mcp-server
// Resource layer for the MCP server. URIs use the `harness://` scheme:
//   - harness://guides/{rules|skills|subagents}/<id>
//   - harness://contracts/specs/<id>
//   - harness://workflows/<id>
//
// We back resources with a small in-memory cache keyed by URI; entries are
// invalidated either by the file watcher or by a 5-minute TTL safety net (per
// SPEC §3 cache+watcher requirements).

import * as fs from 'node:fs/promises';
import * as path from 'node:path';

import type { HarnessPaths } from '../storage/paths.js';
import { GuideKind } from '../shared/schemas/common.js';

const MIME_MARKDOWN = 'text/markdown';
const MIME_YAML = 'application/yaml';
const TTL_MS = 5 * 60 * 1000;

interface CacheEntry {
  text: string;
  mtimeMs: number;
  loadedAt: number;
}

export interface ResourceDescriptor {
  uri: string;
  name: string;
  description?: string;
  mimeType: string;
}

export interface ResourceContent {
  uri: string;
  mimeType: string;
  text: string;
}

export class ResourceNotFoundError extends Error {
  constructor(public readonly uri: string) {
    super(`Resource not found: ${uri}`);
    this.name = 'ResourceNotFoundError';
  }
}

export class InvalidResourceUriError extends Error {
  constructor(public readonly uri: string, reason: string) {
    super(`Invalid resource URI '${uri}': ${reason}`);
    this.name = 'InvalidResourceUriError';
  }
}

export class ResourceManager {
  private readonly cache = new Map<string, CacheEntry>();

  constructor(private readonly paths: HarnessPaths) {}

  /**
   * Drop a single URI from the cache. Called by the file watcher on change.
   */
  invalidate(uri: string): void {
    this.cache.delete(uri);
  }

  /**
   * Drop the entire cache. Called by the file watcher on bulk add/unlink.
   */
  invalidateAll(): void {
    this.cache.clear();
  }

  async list(): Promise<ResourceDescriptor[]> {
    const out: ResourceDescriptor[] = [];

    // Guides
    for (const kind of GuideKind.options) {
      const dir = this.paths.guides[kind];
      const ids = await listMarkdownIds(dir);
      for (const id of ids) {
        out.push({
          uri: `harness://guides/${kind}/${id}`,
          name: `${kind}/${id}`,
          description: `Guide (${kind}) — ${id}`,
          mimeType: MIME_MARKDOWN,
        });
      }
    }

    // Contract specs (yaml or md)
    const specIds = await listSpecIds(this.paths.contracts.specs);
    for (const id of specIds) {
      out.push({
        uri: `harness://contracts/specs/${id}`,
        name: `specs/${id}`,
        description: `Contract spec — ${id}`,
        mimeType: MIME_YAML,
      });
    }

    // Workflows
    const workflowIds = await listMarkdownIds(this.paths.workflows);
    for (const id of workflowIds) {
      out.push({
        uri: `harness://workflows/${id}`,
        name: `workflows/${id}`,
        description: `Workflow — ${id}`,
        mimeType: MIME_MARKDOWN,
      });
    }

    out.sort((a, b) => a.uri.localeCompare(b.uri));
    return out;
  }

  async read(uri: string): Promise<ResourceContent> {
    const filePath = await this.resolveUri(uri);
    const cached = this.cache.get(uri);
    let stat;
    try {
      stat = await fs.stat(filePath);
    } catch {
      throw new ResourceNotFoundError(uri);
    }
    const now = Date.now();
    if (
      cached &&
      cached.mtimeMs === stat.mtimeMs &&
      now - cached.loadedAt < TTL_MS
    ) {
      return {
        uri,
        mimeType: mimeFor(filePath),
        text: cached.text,
      };
    }

    const text = await fs.readFile(filePath, 'utf8');
    this.cache.set(uri, { text, mtimeMs: stat.mtimeMs, loadedAt: now });
    return { uri, mimeType: mimeFor(filePath), text };
  }

  /**
   * Resolve an `harness://...` URI to an absolute file path.
   */
  private async resolveUri(uri: string): Promise<string> {
    const parsed = parseHarnessUri(uri);
    switch (parsed.kind) {
      case 'guide':
        return this.paths.guideFile(parsed.guideKind, parsed.id);
      case 'spec': {
        const resolved = await this.paths.resolveSpecFile(parsed.id);
        if (!resolved) throw new ResourceNotFoundError(uri);
        return resolved;
      }
      case 'workflow':
        return this.paths.workflowMd(parsed.id);
    }
  }
}

type ParsedUri =
  | { kind: 'guide'; guideKind: 'rules' | 'skills' | 'subagents'; id: string }
  | { kind: 'spec'; id: string }
  | { kind: 'workflow'; id: string };

export function parseHarnessUri(uri: string): ParsedUri {
  if (!uri.startsWith('harness://')) {
    throw new InvalidResourceUriError(uri, 'must start with harness://');
  }
  const rest = uri.slice('harness://'.length);
  const parts = rest.split('/').filter((p) => p.length > 0);

  if (parts.length === 0) {
    throw new InvalidResourceUriError(uri, 'empty path');
  }

  if (parts[0] === 'guides') {
    if (parts.length !== 3) {
      throw new InvalidResourceUriError(
        uri,
        'expected harness://guides/{rules|skills|subagents}/<id>',
      );
    }
    const kindStr = parts[1];
    const id = parts[2];
    if (kindStr === undefined || id === undefined) {
      throw new InvalidResourceUriError(uri, 'missing kind or id');
    }
    const parsed = GuideKind.safeParse(kindStr);
    if (!parsed.success) {
      throw new InvalidResourceUriError(uri, `unknown guide kind '${kindStr}'`);
    }
    return { kind: 'guide', guideKind: parsed.data, id: sanitizeId(uri, id) };
  }

  if (parts[0] === 'contracts') {
    if (parts.length !== 3 || parts[1] !== 'specs') {
      throw new InvalidResourceUriError(
        uri,
        'expected harness://contracts/specs/<id>',
      );
    }
    const id = parts[2];
    if (id === undefined) throw new InvalidResourceUriError(uri, 'missing id');
    return { kind: 'spec', id: sanitizeId(uri, id) };
  }

  if (parts[0] === 'workflows') {
    if (parts.length !== 2) {
      throw new InvalidResourceUriError(uri, 'expected harness://workflows/<id>');
    }
    const id = parts[1];
    if (id === undefined) throw new InvalidResourceUriError(uri, 'missing id');
    return { kind: 'workflow', id: sanitizeId(uri, id) };
  }

  throw new InvalidResourceUriError(uri, `unknown root '${parts[0]}'`);
}

function sanitizeId(uri: string, id: string): string {
  if (id.includes('..') || id.includes('/') || id.includes('\\')) {
    throw new InvalidResourceUriError(uri, `unsafe id '${id}'`);
  }
  return id;
}

function mimeFor(filePath: string): string {
  if (filePath.endsWith('.yaml') || filePath.endsWith('.yml')) return MIME_YAML;
  return MIME_MARKDOWN;
}

async function listMarkdownIds(dir: string): Promise<string[]> {
  let entries: string[];
  try {
    entries = await fs.readdir(dir);
  } catch {
    return [];
  }
  return entries
    .filter((name) => name.endsWith('.md'))
    .map((name) => name.slice(0, -3))
    .sort();
}

async function listSpecIds(dir: string): Promise<string[]> {
  let entries: string[];
  try {
    entries = await fs.readdir(dir);
  } catch {
    return [];
  }
  const ids = new Set<string>();
  for (const name of entries) {
    if (name.endsWith('.yaml')) ids.add(name.slice(0, -5));
    else if (name.endsWith('.yml')) ids.add(name.slice(0, -4));
    else if (name.endsWith('.md')) ids.add(name.slice(0, -3));
  }
  return Array.from(ids).sort();
}

/**
 * Map a filesystem path under .harness/ back to the URI it would serve. Returns
 * null if the path doesn't correspond to a known resource kind. Used by the
 * watcher to translate fs events into URI invalidations + notifications.
 */
export function pathToResourceUri(
  paths: HarnessPaths,
  filePath: string,
): string | null {
  const norm = path.resolve(filePath);

  // Guides
  for (const kind of GuideKind.options) {
    const root = path.resolve(paths.guides[kind]);
    if (norm.startsWith(root + path.sep) && norm.endsWith('.md')) {
      const rel = path.relative(root, norm);
      const id = rel.slice(0, -3);
      if (id.length > 0 && !id.includes(path.sep)) {
        return `harness://guides/${kind}/${id}`;
      }
    }
  }

  // Specs
  const specsRoot = path.resolve(paths.contracts.specs);
  if (norm.startsWith(specsRoot + path.sep)) {
    const rel = path.relative(specsRoot, norm);
    const id = stripSpecExt(rel);
    if (id !== null && !id.includes(path.sep)) {
      return `harness://contracts/specs/${id}`;
    }
  }

  // Workflows
  const wfRoot = path.resolve(paths.workflows);
  if (norm.startsWith(wfRoot + path.sep) && norm.endsWith('.md')) {
    const rel = path.relative(wfRoot, norm);
    const id = rel.slice(0, -3);
    if (id.length > 0 && !id.includes(path.sep)) {
      return `harness://workflows/${id}`;
    }
  }

  return null;
}

function stripSpecExt(rel: string): string | null {
  if (rel.endsWith('.yaml')) return rel.slice(0, -5);
  if (rel.endsWith('.yml')) return rel.slice(0, -4);
  if (rel.endsWith('.md')) return rel.slice(0, -3);
  return null;
}
