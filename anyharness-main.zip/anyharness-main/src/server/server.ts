// Owner: harness-mcp-server
// MCP Server wiring: capabilities, request handlers, file watcher, telemetry.
// Business logic lives in src/<domain>/; this file is glue. SPEC §3, §4.

import * as fs from 'node:fs';
import * as path from 'node:path';

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  ListResourcesRequestSchema,
  ReadResourceRequestSchema,
  SubscribeRequestSchema,
  UnsubscribeRequestSchema,
  ListPromptsRequestSchema,
  GetPromptRequestSchema,
  type ServerResult,
} from '@modelcontextprotocol/sdk/types.js';

import type { ZodTypeAny, z } from 'zod';

import { harnessPaths, ensureLocalDirs, type HarnessPaths } from '../storage/paths.js';
import { buildToolRegistry, toJsonSchema, type AnyToolDefinition } from './registry.js';
import { ResourceManager } from './resources.js';
import { listPrompts, getPrompt } from './prompts.js';
import { startWatcher, type HarnessWatcher } from './watcher.js';

const SERVER_NAME = 'anyharness';
const SERVER_VERSION = '0.0.0';

export interface CreateHarnessServerOptions {
  /** Filesystem root for the harness (defaults to env or `.harness`). */
  harnessRoot: string;
}

export interface HarnessServerHandle {
  server: Server;
  paths: HarnessPaths;
  start: () => Promise<void>;
  close: () => Promise<void>;
}

/**
 * Build a fully-wired MCP server. The returned handle is not yet connected to
 * a transport — call `start()` to attach stdio.
 */
export function createHarnessServer(
  opts: CreateHarnessServerOptions,
): HarnessServerHandle {
  const paths = harnessPaths(opts.harnessRoot);

  const tools = buildToolRegistry({ paths });
  const toolMap = new Map<string, AnyToolDefinition>();
  for (const t of tools) toolMap.set(t.name, t);

  const resources = new ResourceManager(paths);
  const subscriptions = new Set<string>();

  const server = new Server(
    { name: SERVER_NAME, version: SERVER_VERSION },
    {
      capabilities: {
        resources: { subscribe: true, listChanged: true },
        tools: { listChanged: true },
        prompts: { listChanged: false },
      },
    },
  );

  // ---- tools/list ---------------------------------------------------------
  server.setRequestHandler(ListToolsRequestSchema, async () => ({
    tools: tools.map((t) => ({
      name: t.name,
      description: t.description,
      inputSchema: toJsonSchema(t.inputSchema),
    })),
  }));

  // ---- tools/call ---------------------------------------------------------
  server.setRequestHandler(CallToolRequestSchema, async (req) => {
    const name = req.params.name;
    const args = req.params.arguments ?? {};
    const tool = toolMap.get(name);
    if (!tool) {
      return errorResult(`Unknown tool '${name}'.`);
    }

    const parsedInput = tool.inputSchema.safeParse(args);
    if (!parsedInput.success) {
      return errorResult(
        `Invalid input for '${name}': ${parsedInput.error.message}`,
      );
    }

    try {
      const output = await tool.handler(parsedInput.data);
      // Validate output before shipping; failure here is a server bug, but we
      // surface as isError rather than crashing the connection.
      const parsedOutput = (tool.outputSchema as ZodTypeAny).safeParse(output);
      if (!parsedOutput.success) {
        return errorResult(
          `Tool '${name}' produced output that failed schema validation: ${parsedOutput.error.message}`,
        );
      }
      const successOutput = parsedOutput.data as z.infer<ZodTypeAny>;
      writeTelemetry(paths, {
        ts: new Date().toISOString(),
        kind: 'tool_call',
        tool: name,
        ok: true,
      });
      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(successOutput, null, 2),
          },
        ],
      };
    } catch (err) {
      writeTelemetry(paths, {
        ts: new Date().toISOString(),
        kind: 'tool_call',
        tool: name,
        ok: false,
        error: (err as Error).message,
      });
      return errorResult(
        `Tool '${name}' failed: ${(err as Error).message ?? String(err)}`,
      );
    }
  });

  // ---- resources/list -----------------------------------------------------
  server.setRequestHandler(ListResourcesRequestSchema, async () => ({
    resources: await resources.list(),
  }));

  // ---- resources/read -----------------------------------------------------
  server.setRequestHandler(ReadResourceRequestSchema, async (req) => {
    const uri = req.params.uri;
    const content = await resources.read(uri);
    return {
      contents: [
        {
          uri: content.uri,
          mimeType: content.mimeType,
          text: content.text,
        },
      ],
    };
  });

  // ---- resources/subscribe + unsubscribe ----------------------------------
  server.setRequestHandler(SubscribeRequestSchema, async (req) => {
    subscriptions.add(req.params.uri);
    return {} satisfies ServerResult;
  });
  server.setRequestHandler(UnsubscribeRequestSchema, async (req) => {
    subscriptions.delete(req.params.uri);
    return {} satisfies ServerResult;
  });

  // ---- prompts/list -------------------------------------------------------
  server.setRequestHandler(ListPromptsRequestSchema, async () => ({
    prompts: await listPrompts(paths),
  }));

  // ---- prompts/get --------------------------------------------------------
  server.setRequestHandler(GetPromptRequestSchema, async (req) => {
    const payload = await getPrompt(paths, req.params.name);
    return {
      description: payload.description,
      messages: payload.messages,
    };
  });

  let watcher: HarnessWatcher | null = null;

  const start = async (): Promise<void> => {
    await ensureLocalDirs(paths);
    watcher = startWatcher(paths, resources, {
      onResourceUpdated: (uri) => {
        if (!subscriptions.has(uri)) return;
        void server.sendResourceUpdated({ uri }).catch(() => {
          /* connection may be closed; safe to ignore */
        });
      },
      onResourceListChanged: () => {
        void server.sendResourceListChanged().catch(() => {});
      },
      onToolListChanged: () => {
        void server.sendToolListChanged().catch(() => {});
      },
    });
    const transport = new StdioServerTransport();
    await server.connect(transport);
  };

  const close = async (): Promise<void> => {
    if (watcher) {
      await watcher.close();
      watcher = null;
    }
    await server.close();
  };

  return { server, paths, start, close };
}

/**
 * Connect a server handle to stdio and resolve when the transport closes.
 * Suitable for use from `bin.ts`.
 */
export async function runStdio(handle: HarnessServerHandle): Promise<void> {
  await handle.start();
  await new Promise<void>((resolve) => {
    handle.server.onclose = () => {
      resolve();
    };
  });
  await handle.close();
}

function errorResult(message: string): ServerResult {
  return {
    isError: true,
    content: [{ type: 'text' as const, text: message }],
  };
}

interface TelemetryEvent {
  ts: string;
  kind: 'tool_call';
  tool: string;
  ok: boolean;
  error?: string;
}

function writeTelemetry(paths: HarnessPaths, event: TelemetryEvent): void {
  // Best-effort; never throws.
  try {
    fs.mkdirSync(paths.local.telemetry, { recursive: true });
    const file = path.join(paths.local.telemetry, 'mcp.jsonl');
    fs.appendFileSync(file, JSON.stringify(event) + '\n', 'utf8');
  } catch {
    // ignore
  }
}

