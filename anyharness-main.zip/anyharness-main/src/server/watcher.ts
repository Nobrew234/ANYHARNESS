// Owner: harness-mcp-server
// Single chokidar instance watching .harness/. Translates fs events into
// MCP resource/tool list-changed notifications and resource cache
// invalidations. SPEC §3 (cache + watcher), §4.

import * as path from 'node:path';
import chokidar, { type FSWatcher } from 'chokidar';

import type { HarnessPaths } from '../storage/paths.js';
import { pathToResourceUri, type ResourceManager } from './resources.js';

export interface WatcherCallbacks {
  /** Emit notifications/resources/updated{uri} */
  onResourceUpdated: (uri: string) => void;
  /** Emit notifications/resources/list_changed */
  onResourceListChanged: () => void;
  /** Emit notifications/tools/list_changed */
  onToolListChanged: () => void;
}

export interface HarnessWatcher {
  close: () => Promise<void>;
}

/**
 * Start watching `.harness/` (excluding `.local`). Returns a handle whose
 * `close()` should be awaited on shutdown.
 */
export function startWatcher(
  paths: HarnessPaths,
  resources: ResourceManager,
  cb: WatcherCallbacks,
): HarnessWatcher {
  const root = path.resolve(paths.root);
  const localRoot = path.resolve(paths.local.root);

  const watcher: FSWatcher = chokidar.watch(
    [
      path.join(root, 'guides'),
      path.join(root, 'sensors'),
      path.join(root, 'judges'),
      path.join(root, 'contracts'),
      path.join(root, 'workflows'),
    ],
    {
      ignored: (p: string) => {
        const abs = path.resolve(p);
        if (abs === localRoot) return true;
        if (abs.startsWith(localRoot + path.sep)) return true;
        return false;
      },
      ignoreInitial: true,
      persistent: true,
      awaitWriteFinish: {
        stabilityThreshold: 200,
        pollInterval: 50,
      },
    },
  );

  const sensorsDir = path.resolve(paths.sensors);
  const judgesDir = path.resolve(paths.judges);
  const contractsSpecsDir = path.resolve(paths.contracts.specs);
  const workflowsDir = path.resolve(paths.workflows);

  const handleChange = (filePath: string): void => {
    const abs = path.resolve(filePath);
    const uri = pathToResourceUri(paths, abs);
    if (uri) {
      resources.invalidate(uri);
      cb.onResourceUpdated(uri);
    }
  };

  const handleAddOrUnlink = (filePath: string): void => {
    const abs = path.resolve(filePath);
    const uri = pathToResourceUri(paths, abs);
    if (uri) {
      resources.invalidate(uri);
    } else {
      // Sensor / judge / spec auxiliary file (yaml registry, schema.json) —
      // safest to flush the URI cache wholesale.
      resources.invalidateAll();
    }

    // Decide which list-changed notifications to emit.
    const inSensors = abs.startsWith(sensorsDir + path.sep);
    const inJudges = abs.startsWith(judgesDir + path.sep);
    const inSpecs = abs.startsWith(contractsSpecsDir + path.sep);
    const inWorkflows = abs.startsWith(workflowsDir + path.sep);
    const inGuides =
      abs.startsWith(path.resolve(paths.guides.rules) + path.sep) ||
      abs.startsWith(path.resolve(paths.guides.skills) + path.sep) ||
      abs.startsWith(path.resolve(paths.guides.subagents) + path.sep);

    if (inSensors || inJudges) {
      cb.onToolListChanged();
    }
    if (inGuides || inSpecs || inWorkflows) {
      cb.onResourceListChanged();
    }
  };

  watcher.on('change', handleChange);
  watcher.on('add', handleAddOrUnlink);
  watcher.on('unlink', handleAddOrUnlink);
  watcher.on('error', (err: unknown) => {
    // eslint-disable-next-line no-console
    console.error('[harness-watcher] error:', err);
  });

  return {
    close: async () => {
      await watcher.close();
    },
  };
}
