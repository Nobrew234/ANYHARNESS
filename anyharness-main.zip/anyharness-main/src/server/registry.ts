// Owner: harness-mcp-server
// Central registry of MCP tools. Each entry pairs a name with zod schemas for
// inputs/outputs and a typed handler. The server layer (server.ts) wires these
// into setRequestHandler(CallToolRequestSchema, ...) and setRequestHandler(
// ListToolsRequestSchema, ...). Output validation is enforced before content
// is shipped to the client.
//
// SPEC §3, §4. Owner of business logic stays in src/<domain>/; this file only
// describes the surface.

import { z, type ZodTypeAny } from 'zod';
import { zodToJsonSchema } from 'zod-to-json-schema';

import type { HarnessPaths } from '../storage/paths.js';

import {
  SensorListInput,
  SensorListOutput,
  SensorRunInput,
  SensorRunOutput,
  SensorRegisterInput,
  SensorRegisterOutput,
  JudgeListInput,
  JudgeListOutput,
  JudgeReviewInput,
  JudgeReviewOutput,
  JudgeRecordInput,
  JudgeRecordOutput,
  SessionStartInput,
  SessionStartOutput,
  SessionAppendInput,
  SessionAppendOutput,
  SessionGetInput,
  SessionGetOutput,
  ContractSpecValidateInput,
  ContractSpecValidateOutput,
  ContractTaskNextInput,
  ContractTaskNextOutput,
  ContractTaskCompleteInput,
  ContractTaskCompleteOutput,
  SteerSuggestInput,
  SteerSuggestOutput,
} from '../shared/schemas/tools/index.js';

import {
  handleSensorList,
  handleSensorRun,
  handleSensorRegister,
} from '../sensors/index.js';
import {
  handleJudgeList,
  handleJudgeReview,
  handleJudgeRecord,
} from '../judges/index.js';
import {
  handleSessionStart,
  handleSessionAppend,
  handleSessionGet,
  recordSteeringEvent,
} from '../sessions/index.js';
import {
  handleContractSpecValidate,
  handleContractTaskNext,
  handleContractTaskComplete,
  defaultRunners,
} from '../contracts/index.js';
import { handleSteerSuggest } from '../steering/index.js';

import type { SteeringEvent } from '../shared/schemas/steering-event.js';
import type { SensorOutput } from '../shared/schemas/sensor-output.js';

export interface ToolDefinition<I extends ZodTypeAny, O extends ZodTypeAny> {
  readonly name: string;
  readonly description: string;
  readonly inputSchema: I;
  readonly outputSchema: O;
  readonly handler: (input: z.infer<I>) => Promise<z.infer<O>>;
}

export type AnyToolDefinition = ToolDefinition<ZodTypeAny, ZodTypeAny>;

export interface ToolRegistryDeps {
  readonly paths: HarnessPaths;
}

/**
 * Build the tool registry from injected dependencies. The registry is the
 * authoritative list of tools advertised over MCP.
 */
export function buildToolRegistry(deps: ToolRegistryDeps): AnyToolDefinition[] {
  const { paths } = deps;

  // Single recorder used by sensor.run and judge.record wrappers.
  const recorder = (event: SteeringEvent): Promise<void> =>
    recordSteeringEvent(paths, event);

  const tools: AnyToolDefinition[] = [
    defineTool({
      name: 'sensor_list',
      description:
        'List registered sensors, optionally filtered by kind or regulation.',
      inputSchema: SensorListInput,
      outputSchema: SensorListOutput,
      handler: (input) => handleSensorList(paths, input),
    }),
    defineTool({
      name: 'sensor_run',
      description:
        'Run a sensor by id against an optional target. Output is normalized JSON.',
      inputSchema: SensorRunInput,
      outputSchema: SensorRunOutput,
      handler: (input) => handleSensorRun(paths, input, { recorder }),
    }),
    defineTool({
      name: 'sensor_register',
      description: 'Register or update a sensor entry under .harness/sensors/.',
      inputSchema: SensorRegisterInput,
      outputSchema: SensorRegisterOutput,
      handler: (input) => handleSensorRegister(paths, input),
    }),
    defineTool({
      name: 'judge_list',
      description: 'List available LLM-as-judge rubrics.',
      inputSchema: JudgeListInput,
      outputSchema: JudgeListOutput,
      handler: (input) => handleJudgeList(paths, input),
    }),
    defineTool({
      name: 'judge_review',
      description:
        'Prepare a judge review by rendering the rubric prompt, schema, and context. ' +
        'Returns the envelope the client needs to perform inference. ' +
        'The client then submits the verdict via judge.record.',
      inputSchema: JudgeReviewInput,
      outputSchema: JudgeReviewOutput,
      handler: (input) => handleJudgeReview(paths, input),
    }),
    defineTool({
      name: 'judge_record',
      description:
        'Submit the agent\'s structured judge review for validation against the rubric ' +
        'schema and recording in the steering log.',
      inputSchema: JudgeRecordInput,
      outputSchema: JudgeRecordOutput,
      handler: async (input) => {
        const output = await handleJudgeRecord(paths, input);
        await recordJudgeSteering(recorder, input.rubric_id, input.target, output);
        return output;
      },
    }),
    defineTool({
      name: 'session_start',
      description:
        'Open a new session for a workflow or contract; returns a session_id.',
      inputSchema: SessionStartInput,
      outputSchema: SessionStartOutput,
      handler: (input) => handleSessionStart(paths, input),
    }),
    defineTool({
      name: 'session_append',
      description: 'Append an event to an existing session log.',
      inputSchema: SessionAppendInput,
      outputSchema: SessionAppendOutput,
      handler: (input) => handleSessionAppend(paths, input),
    }),
    defineTool({
      name: 'session_get',
      description: 'Read the header and full event log for a session.',
      inputSchema: SessionGetInput,
      outputSchema: SessionGetOutput,
      handler: (input) => handleSessionGet(paths, input),
    }),
    defineTool({
      name: 'contract_spec_validate',
      description:
        'Validate an artifact against a spec by dispatching its checks (sensors and judges).',
      inputSchema: ContractSpecValidateInput,
      outputSchema: ContractSpecValidateOutput,
      handler: (input) =>
        handleContractSpecValidate(paths, defaultRunners(paths), input),
    }),
    defineTool({
      name: 'contract_task_next',
      description: 'Return the next pending task for a spec, or null if none remain.',
      inputSchema: ContractTaskNextInput,
      outputSchema: ContractTaskNextOutput,
      handler: (input) => handleContractTaskNext(paths, input),
    }),
    defineTool({
      name: 'contract_task_complete',
      description: 'Mark a task complete with one or more evidence entries.',
      inputSchema: ContractTaskCompleteInput,
      outputSchema: ContractTaskCompleteOutput,
      handler: (input) => handleContractTaskComplete(paths, input),
    }),
    defineTool({
      name: 'harness_steer_suggest',
      description:
        'Inspect the steering log and propose new guides, sensors, or rule consolidations.',
      inputSchema: SteerSuggestInput,
      outputSchema: SteerSuggestOutput,
      handler: (input) => handleSteerSuggest(paths, input),
    }),
  ];

  return tools;
}

function defineTool<I extends ZodTypeAny, O extends ZodTypeAny>(
  def: ToolDefinition<I, O>,
): AnyToolDefinition {
  return def as unknown as AnyToolDefinition;
}

async function recordJudgeSteering(
  recorder: (event: SteeringEvent) => Promise<void>,
  rubricId: string,
  target: string,
  output: SensorOutput,
): Promise<void> {
  const event: SteeringEvent = {
    timestamp: new Date().toISOString(),
    kind: 'judge',
    id: rubricId,
    target,
    regulation: output.regulation,
    passed: output.passed,
    inconclusive: output.inconclusive,
    violationCount: output.violations.length,
    violations: output.violations,
  };
  try {
    await recorder(event);
  } catch {
    // Steering recording must never fail the tool call.
  }
}

/**
 * Convert a tool's zod input schema into the JSON Schema shape MCP expects on
 * `tools/list`. zod-to-json-schema outputs jsonSchema7 by default; MCP accepts
 * any standard JSON Schema object, so we strip the top-level `$schema` key to
 * keep the surface tidy.
 */
export function toJsonSchema(schema: ZodTypeAny): Record<string, unknown> {
  const json = zodToJsonSchema(schema, { target: 'jsonSchema7' }) as Record<
    string,
    unknown
  >;
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { $schema, ...rest } = json;
  return rest;
}
