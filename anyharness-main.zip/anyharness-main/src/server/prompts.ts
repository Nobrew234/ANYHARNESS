// Owner: harness-mcp-server (registry); humans author content under
// .harness/workflows/<id>.md. The MCP `prompts/` surface enumerates each
// workflow as `workflow.<id>` and returns the markdown body as a single user
// message. SPEC §3 (Workflow row), §15 decision 5.

import * as fs from 'node:fs/promises';

import type { HarnessPaths } from '../storage/paths.js';

const PREFIX = 'workflow.';

export interface PromptDescriptor {
  name: string;
  description: string;
}

export interface PromptMessage {
  role: 'user';
  content: { type: 'text'; text: string };
}

export interface PromptPayload {
  description: string;
  messages: PromptMessage[];
}

export class PromptNotFoundError extends Error {
  constructor(public readonly name: string) {
    super(`Prompt '${name}' not found`);
    this.name = 'PromptNotFoundError';
  }
}

export class InvalidPromptNameError extends Error {
  constructor(public readonly name: string) {
    super(
      `Prompt name '${name}' is not in the expected 'workflow.<id>' format`,
    );
    this.name = 'InvalidPromptNameError';
  }
}

export async function listPrompts(
  paths: HarnessPaths,
): Promise<PromptDescriptor[]> {
  let entries: string[];
  try {
    entries = await fs.readdir(paths.workflows);
  } catch {
    return [];
  }
  const ids = entries
    .filter((name) => name.endsWith('.md'))
    .map((name) => name.slice(0, -3))
    .filter((id) => id.length > 0);
  ids.sort();
  return ids.map((id) => ({
    name: `${PREFIX}${id}`,
    description: `Workflow prompt '${id}' sourced from .harness/workflows/${id}.md`,
  }));
}

export async function getPrompt(
  paths: HarnessPaths,
  name: string,
): Promise<PromptPayload> {
  if (!name.startsWith(PREFIX)) {
    throw new InvalidPromptNameError(name);
  }
  const id = name.slice(PREFIX.length);
  if (id.length === 0 || id.includes('/') || id.includes('..')) {
    throw new InvalidPromptNameError(name);
  }
  const filePath = paths.workflowMd(id);
  let text: string;
  try {
    text = await fs.readFile(filePath, 'utf8');
  } catch {
    throw new PromptNotFoundError(name);
  }
  return {
    description: `Workflow '${id}' from .harness/workflows/${id}.md`,
    messages: [
      {
        role: 'user',
        content: { type: 'text', text },
      },
    ],
  };
}
