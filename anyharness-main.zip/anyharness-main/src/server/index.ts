// Owner: harness-mcp-server
// Public surface for the MCP server: stdio transport, capabilities, registry,
// request loop, file watcher. SPEC §3, §4.

export {
  createHarnessServer,
  runStdio,
  type CreateHarnessServerOptions,
  type HarnessServerHandle,
} from './server.js';
export {
  ResourceManager,
  parseHarnessUri,
  pathToResourceUri,
  ResourceNotFoundError,
  InvalidResourceUriError,
  type ResourceDescriptor,
  type ResourceContent,
} from './resources.js';
export {
  listPrompts,
  getPrompt,
  PromptNotFoundError,
  InvalidPromptNameError,
  type PromptDescriptor,
  type PromptPayload,
} from './prompts.js';
export {
  buildToolRegistry,
  toJsonSchema,
  type ToolDefinition,
  type AnyToolDefinition,
  type ToolRegistryDeps,
} from './registry.js';
export { startWatcher, type WatcherCallbacks, type HarnessWatcher } from './watcher.js';
