#!/usr/bin/env node
// Harness MCP — stdio binary entry.
// Owner: harness-mcp-server (.claude/agents/harness-mcp-server.md)
// Wires the @modelcontextprotocol/sdk Server to stdio. SPEC §3, §4.

import { createHarnessServer, runStdio } from './server/index.js';

const harnessRoot = (process.env.HARNESS_ROOT?.trim() || ' .harness').trim();

await runStdio(createHarnessServer({ harnessRoot }));
