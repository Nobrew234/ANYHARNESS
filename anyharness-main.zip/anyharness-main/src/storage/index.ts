// Owner: harness-mcp-server (cross-cutting). SPEC §6.
export * from './paths.js';
