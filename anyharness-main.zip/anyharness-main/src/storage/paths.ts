// Owner: harness-architect — single source-of-truth for .harness/ paths.
import * as path from 'node:path';
import * as fs from 'node:fs/promises';
import type { GuideKind } from '../shared/schemas/common.js';

export interface HarnessPaths {
  root: string;
  guides: { rules: string; skills: string; subagents: string };
  sensors: string;
  judges: string;
  contracts: { specs: string; tasks: string };
  workflows: string;
  local: {
    root: string;
    sessions: string;
    steeringLog: string;
    judgeCosts: string;
    telemetry: string;
  };
  sensorYaml: (id: string) => string;
  judgeMd: (rubricId: string) => string;
  judgeSchema: (rubricId: string) => string;
  taskFile: (id: string) => string;
  sessionFile: (id: string) => string;
  workflowMd: (id: string) => string;
  guideFile: (kind: GuideKind, id: string) => string;
  resolveSpecFile: (id: string) => Promise<string | null>;
}

export function harnessPaths(root: string): HarnessPaths {
  const guidesRoot = path.join(root, 'guides');
  const sensors = path.join(root, 'sensors');
  const judges = path.join(root, 'judges');
  const contractsSpecs = path.join(root, 'contracts', 'specs');
  const contractsTasks = path.join(root, 'contracts', 'tasks');
  const workflows = path.join(root, 'workflows');
  const localRoot = path.join(root, '.local');
  const sessions = path.join(localRoot, 'sessions');
  const steeringDir = path.join(localRoot, 'steering');
  const judgesLocalDir = path.join(localRoot, 'judges');
  const telemetry = path.join(localRoot, 'telemetry');

  return {
    root,
    guides: {
      rules: path.join(guidesRoot, 'rules'),
      skills: path.join(guidesRoot, 'skills'),
      subagents: path.join(guidesRoot, 'subagents'),
    },
    sensors,
    judges,
    contracts: { specs: contractsSpecs, tasks: contractsTasks },
    workflows,
    local: {
      root: localRoot,
      sessions,
      steeringLog: path.join(steeringDir, 'log.jsonl'),
      judgeCosts: path.join(judgesLocalDir, 'costs.jsonl'),
      telemetry,
    },
    sensorYaml: (id) => path.join(sensors, `${id}.yaml`),
    judgeMd: (rubricId) => path.join(judges, `${rubricId}.md`),
    judgeSchema: (rubricId) => path.join(judges, `${rubricId}.schema.json`),
    taskFile: (id) => path.join(contractsTasks, `${id}.yaml`),
    sessionFile: (id) => path.join(sessions, `${id}.jsonl`),
    workflowMd: (id) => path.join(workflows, `${id}.md`),
    guideFile: (kind, id) => path.join(guidesRoot, kind, `${id}.md`),
    resolveSpecFile: async (id) => {
      const yamlPath = path.join(contractsSpecs, `${id}.yaml`);
      const mdPath = path.join(contractsSpecs, `${id}.md`);
      if (await exists(yamlPath)) return yamlPath;
      if (await exists(mdPath)) return mdPath;
      return null;
    },
  };
}

export async function ensureLocalDirs(p: HarnessPaths): Promise<void> {
  await fs.mkdir(p.local.sessions, { recursive: true });
  await fs.mkdir(path.dirname(p.local.steeringLog), { recursive: true });
  await fs.mkdir(path.dirname(p.local.judgeCosts), { recursive: true });
  await fs.mkdir(p.local.telemetry, { recursive: true });
}

async function exists(p: string): Promise<boolean> {
  try {
    await fs.access(p);
    return true;
  } catch {
    return false;
  }
}
