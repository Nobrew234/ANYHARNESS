// Owner: harness-sessions — heurísticas para harness.steer.suggest. SPEC §8.
// Lê steering log na janela e produz sugestões estruturadas. Read-only, propostas (nunca aplica).
import type {
  SteerSuggestInput,
  SteerSuggestOutput,
  SteerSuggestion,
} from '../shared/schemas/tools/steering.js';
import type { SteeringEvent } from '../shared/schemas/steering-event.js';
import { readSteeringLog } from '../sessions/steering-log.js';
import type { HarnessPaths } from '../storage/paths.js';

const DAY_MS = 86_400_000;

// Thresholds for heurística 1 (rule recurrence).
const SENSOR_DISTINCT_WHATS_MIN = 3;
const SENSOR_TOTAL_OCCURRENCES_MIN = 3;
// Threshold for heurística 2 (recurring judge flag).
const JUDGE_FLAG_MIN = 3;

interface SensorAggregate {
  id: string;
  totalFlags: number;
  whats: Map<string, number>;
  filesAffected: Set<string>;
  representativeRegulation: SteeringEvent['regulation'];
}

interface JudgeAggregate {
  id: string;
  totalFlags: number;
  whats: Map<string, number>;
  representativeRegulation: SteeringEvent['regulation'];
}

function aggregateSensorViolations(events: SteeringEvent[]): Map<string, SensorAggregate> {
  const map = new Map<string, SensorAggregate>();
  for (const ev of events) {
    if (ev.kind !== 'sensor') continue;
    if (ev.passed) continue;
    if (ev.violations.length === 0 && ev.violationCount === 0) continue;
    let agg = map.get(ev.id);
    if (!agg) {
      agg = {
        id: ev.id,
        totalFlags: 0,
        whats: new Map<string, number>(),
        filesAffected: new Set<string>(),
        representativeRegulation: ev.regulation,
      };
      map.set(ev.id, agg);
    }
    agg.totalFlags += 1;
    for (const v of ev.violations) {
      agg.whats.set(v.what, (agg.whats.get(v.what) ?? 0) + 1);
      for (const f of v.filesAffected) agg.filesAffected.add(f);
    }
  }
  return map;
}

function aggregateJudgeFlags(events: SteeringEvent[]): Map<string, JudgeAggregate> {
  const map = new Map<string, JudgeAggregate>();
  for (const ev of events) {
    if (ev.kind !== 'judge') continue;
    if (ev.passed) continue;
    let agg = map.get(ev.id);
    if (!agg) {
      agg = {
        id: ev.id,
        totalFlags: 0,
        whats: new Map<string, number>(),
        representativeRegulation: ev.regulation,
      };
      map.set(ev.id, agg);
    }
    agg.totalFlags += 1;
    for (const v of ev.violations) {
      agg.whats.set(v.what, (agg.whats.get(v.what) ?? 0) + 1);
    }
  }
  return map;
}

function topN<K>(map: Map<K, number>, n: number): Array<{ key: K; count: number }> {
  return [...map.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, n)
    .map(([key, count]) => ({ key, count }));
}

function buildNewRuleSuggestions(
  sensorAggregates: Map<string, SensorAggregate>,
): SteerSuggestion[] {
  const out: SteerSuggestion[] = [];
  for (const agg of sensorAggregates.values()) {
    if (agg.totalFlags < SENSOR_TOTAL_OCCURRENCES_MIN) continue;
    if (agg.whats.size < SENSOR_DISTINCT_WHATS_MIN) continue;
    const topWhats = topN(agg.whats, 5).map((e) => ({
      what: e.key,
      occurrences: e.count,
    }));
    const filesAffected = [...agg.filesAffected].slice(0, 10);
    const evidence: Record<string, unknown> = {
      sensorId: agg.id,
      totalFlags: agg.totalFlags,
      distinctWhats: agg.whats.size,
      topWhats,
      filesAffected,
      regulation: agg.representativeRegulation,
    };
    const proposedAction: Record<string, unknown> = {
      createGuide: {
        kind: 'rules',
        suggestedId: `avoid-${agg.id}-violations`,
        uri: `harness://guides/rules/avoid-${agg.id}-violations`,
        templateContent:
          `# Avoid recurring violations from sensor '${agg.id}'\n\n` +
          `Sensor '${agg.id}' flagged ${agg.totalFlags} times across ${agg.whats.size} distinct issues ` +
          `in the analysis window. Consolidate guidance so agents anticipate the rule and stop tripping it.\n`,
      },
    };
    out.push({
      kind: 'new-rule',
      rationale: `Sensor '${agg.id}' produced ${agg.totalFlags} failing runs covering ${agg.whats.size} distinct issues — recurring rule worth promoting to a guide.`,
      evidence,
      proposedAction,
    });
  }
  return out;
}

function buildJudgeFlagSuggestions(
  judgeAggregates: Map<string, JudgeAggregate>,
): SteerSuggestion[] {
  const out: SteerSuggestion[] = [];
  for (const agg of judgeAggregates.values()) {
    if (agg.totalFlags < JUDGE_FLAG_MIN) continue;
    const topWhats = topN(agg.whats, 5).map((e) => ({
      what: e.key,
      occurrences: e.count,
    }));
    const evidence: Record<string, unknown> = {
      judgeId: agg.id,
      totalFlags: agg.totalFlags,
      distinctWhats: agg.whats.size,
      topWhats,
      regulation: agg.representativeRegulation,
    };
    const proposedAction: Record<string, unknown> = {
      humanReview: {
        prompt:
          `Judge '${agg.id}' is repeatedly flagging similar issues. Consider whether a computational sensor or a guide could prevent the failure earlier in the loop.`,
      },
    };
    out.push({
      kind: 'recurring-judge-flag',
      rationale: `Judge '${agg.id}' flagged ${agg.totalFlags} times in the window — repetition suggests a missing upstream guide or sensor.`,
      evidence,
      proposedAction,
    });
  }
  return out;
}

export async function suggestSteering(
  paths: HarnessPaths,
  input: SteerSuggestInput,
): Promise<SteerSuggestOutput> {
  const windowDays = input.windowDays;
  const sinceMs = Date.now() - windowDays * DAY_MS;
  const events = await readSteeringLog(paths, { sinceMs });

  const sensorAggregates = aggregateSensorViolations(events);
  const judgeAggregates = aggregateJudgeFlags(events);

  const suggestions: SteerSuggestion[] = [
    ...buildNewRuleSuggestions(sensorAggregates),
    ...buildJudgeFlagSuggestions(judgeAggregates),
  ];

  // TODO: orphan-guide heurística — exige rastrear "guide read" em sessões.
  // Skipped no MVP; precisa de novo evento de sessão (`guide_read`) ou
  // pareamento com session events além do steering log.

  return {
    suggestions,
    windowDays,
    eventCountAnalyzed: events.length,
  };
}
