// Owner: harness-sessions — thin handler for harness.steer.suggest. SPEC §4, §8.
import type {
  SteerSuggestInput,
  SteerSuggestOutput,
} from '../shared/schemas/tools/steering.js';
import type { HarnessPaths } from '../storage/paths.js';
import { suggestSteering } from './suggest.js';

export async function handleSteerSuggest(
  paths: HarnessPaths,
  input: SteerSuggestInput,
): Promise<SteerSuggestOutput> {
  return suggestSteering(paths, input);
}
