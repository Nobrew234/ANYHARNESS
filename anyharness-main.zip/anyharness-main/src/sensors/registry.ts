// Owner: harness-sensors
// Loads/saves .harness/sensors/<id>.yaml registry entries. SPEC §3, §4, §6.
import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import { parse as parseYaml, stringify as stringifyYaml } from 'yaml';
import { SensorRegistryEntry } from '../shared/schemas/sensor-registry.js';
import type { HarnessPaths } from '../storage/paths.js';

export class SensorNotFoundError extends Error {
  constructor(public readonly id: string) {
    super(`sensor '${id}' not found in registry`);
    this.name = 'SensorNotFoundError';
  }
}

export interface WriteSensorResult {
  registered: true;
  path: string;
  changed: boolean;
}

async function exists(p: string): Promise<boolean> {
  try {
    await fs.access(p);
    return true;
  } catch {
    return false;
  }
}

export async function loadRegistry(
  paths: HarnessPaths,
): Promise<Map<string, SensorRegistryEntry>> {
  const result = new Map<string, SensorRegistryEntry>();
  if (!(await exists(paths.sensors))) {
    return result;
  }
  const entries = await fs.readdir(paths.sensors, { withFileTypes: true });
  for (const dirent of entries) {
    if (!dirent.isFile()) continue;
    if (!dirent.name.endsWith('.yaml') && !dirent.name.endsWith('.yml')) continue;
    const filePath = path.join(paths.sensors, dirent.name);
    const raw = await fs.readFile(filePath, 'utf8');
    let parsed: unknown;
    try {
      parsed = parseYaml(raw);
    } catch (err) {
      throw new Error(`Failed to parse sensor YAML at ${filePath}: ${(err as Error).message}`);
    }
    const entry = SensorRegistryEntry.parse(parsed);
    if (result.has(entry.id)) {
      throw new Error(`Duplicate sensor id '${entry.id}' (file: ${filePath})`);
    }
    result.set(entry.id, entry);
  }
  return result;
}

export async function getSensor(
  paths: HarnessPaths,
  id: string,
): Promise<SensorRegistryEntry | null> {
  const filePath = paths.sensorYaml(id);
  if (!(await exists(filePath))) return null;
  const raw = await fs.readFile(filePath, 'utf8');
  let parsed: unknown;
  try {
    parsed = parseYaml(raw);
  } catch (err) {
    throw new Error(`Failed to parse sensor YAML at ${filePath}: ${(err as Error).message}`);
  }
  return SensorRegistryEntry.parse(parsed);
}

export async function writeSensor(
  paths: HarnessPaths,
  entry: SensorRegistryEntry,
): Promise<WriteSensorResult> {
  // Validate before writing.
  const validated = SensorRegistryEntry.parse(entry);
  const filePath = paths.sensorYaml(validated.id);

  if (await exists(filePath)) {
    const raw = await fs.readFile(filePath, 'utf8');
    let parsed: unknown;
    try {
      parsed = parseYaml(raw);
    } catch {
      parsed = null;
    }
    if (parsed !== null) {
      const existingResult = SensorRegistryEntry.safeParse(parsed);
      if (existingResult.success && deepEqual(existingResult.data, validated)) {
        return { registered: true, path: filePath, changed: false };
      }
    }
  }

  await fs.mkdir(path.dirname(filePath), { recursive: true });
  const yaml = stringifyYaml(validated);
  await fs.writeFile(filePath, yaml, 'utf8');
  return { registered: true, path: filePath, changed: true };
}

function deepEqual(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  if (typeof a !== typeof b) return false;
  if (a === null || b === null) return a === b;
  if (typeof a !== 'object') return false;
  if (Array.isArray(a) !== Array.isArray(b)) return false;
  if (Array.isArray(a) && Array.isArray(b)) {
    if (a.length !== b.length) return false;
    for (let i = 0; i < a.length; i++) {
      if (!deepEqual(a[i], b[i])) return false;
    }
    return true;
  }
  const aObj = a as Record<string, unknown>;
  const bObj = b as Record<string, unknown>;
  const aKeys = Object.keys(aObj);
  const bKeys = Object.keys(bObj);
  if (aKeys.length !== bKeys.length) return false;
  for (const k of aKeys) {
    if (!Object.prototype.hasOwnProperty.call(bObj, k)) return false;
    if (!deepEqual(aObj[k], bObj[k])) return false;
  }
  return true;
}
