// Owner: harness-sensors
// Tool implementations for sensor.list / sensor.run / sensor.register.
// Inputs are pre-validated by the server layer against schemas in
// src/shared/schemas/tools/sensors.ts; we re-emit through Output schemas.
import type {
  SensorListInput,
  SensorListOutput,
  SensorRunInput,
  SensorRunOutput,
  SensorRegisterInput,
  SensorRegisterOutput,
} from '../shared/schemas/tools/sensors.js';
import {
  SensorListOutput as SensorListOutputSchema,
  SensorRunOutput as SensorRunOutputSchema,
  SensorRegisterOutput as SensorRegisterOutputSchema,
} from '../shared/schemas/tools/sensors.js';
import type { HarnessPaths } from '../storage/paths.js';
import { loadRegistry, writeSensor } from './registry.js';
import { runSensor, type RunSensorOptions } from './runner.js';

export async function handleSensorList(
  paths: HarnessPaths,
  input: SensorListInput,
): Promise<SensorListOutput> {
  const registry = await loadRegistry(paths);
  const sensors = [];
  for (const entry of registry.values()) {
    if (input.kind && entry.kind !== input.kind) continue;
    if (input.regulation && entry.regulation !== input.regulation) continue;
    sensors.push({
      id: entry.id,
      kind: entry.kind,
      regulation: entry.regulation,
      command: entry.command,
      ...(entry.description !== undefined ? { description: entry.description } : {}),
    });
  }
  sensors.sort((a, b) => a.id.localeCompare(b.id));
  return SensorListOutputSchema.parse({ sensors });
}

export async function handleSensorRun(
  paths: HarnessPaths,
  input: SensorRunInput,
  options: RunSensorOptions = {},
): Promise<SensorRunOutput> {
  const output = await runSensor(paths, input.id, input.target, options);
  return SensorRunOutputSchema.parse(output);
}

export async function handleSensorRegister(
  paths: HarnessPaths,
  input: SensorRegisterInput,
): Promise<SensorRegisterOutput> {
  const result = await writeSensor(paths, input);
  return SensorRegisterOutputSchema.parse({
    registered: result.registered,
    path: result.path,
    changed: result.changed,
  });
}
