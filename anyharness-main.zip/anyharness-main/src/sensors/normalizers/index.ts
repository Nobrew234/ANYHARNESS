// Owner: harness-sensors
// Normalizers: turn native tool output (ESLint JSON, tsc stderr, semgrep JSON)
// into the llm-json shape defined in SPEC §9.
import type { SensorOutput } from '../../shared/schemas/sensor-output.js';
import { eslint } from './eslint.js';
import { tsc } from './tsc.js';
import { semgrep } from './semgrep.js';
import { passthrough, type NormalizerContext } from './passthrough.js';

export type Normalizer = (
  stdout: string,
  stderr: string,
  exitCode: number,
  ctx: NormalizerContext,
) => SensorOutput;

const REGISTRY: Record<string, Normalizer> = {
  eslint,
  tsc,
  semgrep,
  passthrough,
};

export function getNormalizer(name: string): Normalizer {
  return REGISTRY[name] ?? passthrough;
}

export { eslint, tsc, semgrep, passthrough };
export type { NormalizerContext };
