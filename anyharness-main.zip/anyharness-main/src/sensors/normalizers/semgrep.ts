// Owner: harness-sensors
// Normalizer for `semgrep --json`. results[] -> Violations.
import type { Severity } from '../../shared/schemas/common.js';
import { SensorOutput } from '../../shared/schemas/sensor-output.js';
import type { Violation, LineRange } from '../../shared/schemas/violation.js';
import type { NormalizerContext } from './passthrough.js';

interface SemgrepStart {
  line?: number;
  col?: number;
}

interface SemgrepEnd {
  line?: number;
  col?: number;
}

interface SemgrepExtra {
  severity?: string;
  message?: string;
  metadata?: Record<string, unknown>;
  fix?: string;
}

interface SemgrepResult {
  check_id?: string;
  path?: string;
  start?: SemgrepStart;
  end?: SemgrepEnd;
  extra?: SemgrepExtra;
}

interface SemgrepRoot {
  results?: SemgrepResult[];
  errors?: unknown[];
}

export function semgrep(
  stdout: string,
  stderr: string,
  exitCode: number,
  ctx: NormalizerContext,
): SensorOutput {
  const trimmed = stdout.trim();
  if (!trimmed) {
    return SensorOutput.parse({
      tool: ctx.id,
      regulation: ctx.regulation,
      passed: exitCode === 0,
      summary:
        exitCode === 0
          ? 'semgrep: no JSON output, exit 0.'
          : `semgrep: no JSON output, exit ${exitCode}.`,
      inconclusive: exitCode !== 0,
      inconclusiveReason:
        exitCode !== 0
          ? `semgrep produced no JSON (stderr: ${truncate(stderr.trim())})`
          : undefined,
      violations: [],
    });
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(trimmed);
  } catch (err) {
    return SensorOutput.parse({
      tool: ctx.id,
      regulation: ctx.regulation,
      passed: false,
      summary: `semgrep: failed to parse JSON output (exit ${exitCode}).`,
      inconclusive: true,
      inconclusiveReason: `JSON parse failed: ${(err as Error).message}`,
      violations: [],
    });
  }

  const root = parsed as SemgrepRoot;
  const results = Array.isArray(root.results) ? root.results : [];
  const violations: Violation[] = results.map(toViolation);
  const passed = violations.length === 0;

  return SensorOutput.parse({
    tool: ctx.id,
    regulation: ctx.regulation,
    passed,
    summary: passed
      ? 'semgrep: clean.'
      : `semgrep: ${violations.length} finding(s).`,
    inconclusive: false,
    violations,
  });
}

function toViolation(result: SemgrepResult): Violation {
  const filePath = result.path ?? '<unknown>';
  const startLine = result.start?.line ?? 0;
  const endLine = result.end?.line ?? startLine;
  const linesAffected: LineRange[] = [[startLine, endLine]];
  const checkId = result.check_id ?? 'unknown-rule';
  const message = result.extra?.message ?? checkId;
  const severity = mapSeverity(result.extra?.severity);
  const remediation = result.extra?.fix
    ? `Apply suggested fix at ${filePath}:${startLine}.`
    : `Address semgrep finding ${checkId} at ${filePath}:${startLine}.`;
  return {
    severity,
    what: `${checkId}: ${message}`,
    why: message,
    remediation,
    filesAffected: [filePath],
    linesAffected,
  };
}

function mapSeverity(raw: string | undefined): Severity {
  switch ((raw ?? '').toUpperCase()) {
    case 'ERROR':
    case 'HIGH':
    case 'CRITICAL':
      return 'error';
    case 'WARNING':
    case 'MEDIUM':
      return 'warning';
    case 'INFO':
    case 'LOW':
    default:
      return 'info';
  }
}

function truncate(s: string, max = 200): string {
  if (s.length <= max) return s;
  return `${s.slice(0, max)}... (truncated)`;
}
