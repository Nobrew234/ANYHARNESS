// Owner: harness-sensors
// Normalizer for `eslint --format json`. Maps each ESLint message to a Violation.
import type { Severity } from '../../shared/schemas/common.js';
import { SensorOutput } from '../../shared/schemas/sensor-output.js';
import type { Violation, LineRange } from '../../shared/schemas/violation.js';
import type { NormalizerContext } from './passthrough.js';

interface EslintMessage {
  ruleId: string | null;
  severity: number;
  message: string;
  line?: number;
  endLine?: number;
  column?: number;
  endColumn?: number;
  fix?: { range: [number, number]; text: string };
}

interface EslintResult {
  filePath: string;
  messages: EslintMessage[];
  errorCount?: number;
  warningCount?: number;
}

export function eslint(
  stdout: string,
  stderr: string,
  exitCode: number,
  ctx: NormalizerContext,
): SensorOutput {
  const trimmed = stdout.trim();
  if (!trimmed) {
    return SensorOutput.parse({
      tool: ctx.id,
      regulation: ctx.regulation,
      passed: exitCode === 0,
      summary:
        exitCode === 0
          ? 'eslint: no output, exit 0 (no files matched or no issues).'
          : `eslint: no JSON output, exit ${exitCode}.`,
      inconclusive: exitCode !== 0,
      inconclusiveReason:
        exitCode !== 0
          ? `eslint produced no JSON (stderr: ${truncate(stderr.trim())})`
          : undefined,
      violations: [],
    });
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(trimmed);
  } catch (err) {
    return SensorOutput.parse({
      tool: ctx.id,
      regulation: ctx.regulation,
      passed: false,
      summary: `eslint: failed to parse JSON output (exit ${exitCode}).`,
      inconclusive: true,
      inconclusiveReason: `JSON parse failed: ${(err as Error).message}`,
      violations: [],
    });
  }

  if (!Array.isArray(parsed)) {
    return SensorOutput.parse({
      tool: ctx.id,
      regulation: ctx.regulation,
      passed: false,
      summary: 'eslint: unexpected JSON shape (expected array of results).',
      inconclusive: true,
      inconclusiveReason: 'eslint JSON output was not an array',
      violations: [],
    });
  }

  const violations: Violation[] = [];
  for (const rawResult of parsed) {
    const result = rawResult as EslintResult;
    if (!result || typeof result.filePath !== 'string' || !Array.isArray(result.messages)) {
      continue;
    }
    for (const message of result.messages) {
      violations.push(toViolation(result.filePath, message));
    }
  }

  const violationCount = violations.length;
  const errorCount = violations.filter((v) => v.severity === 'error').length;
  const warningCount = violations.filter((v) => v.severity === 'warning').length;
  const passed = exitCode === 0 && violationCount === 0;

  return SensorOutput.parse({
    tool: ctx.id,
    regulation: ctx.regulation,
    passed,
    summary: passed
      ? 'eslint: clean.'
      : `eslint: ${violationCount} issue(s) (${errorCount} error, ${warningCount} warning).`,
    inconclusive: false,
    violations,
  });
}

function toViolation(filePath: string, message: EslintMessage): Violation {
  const severity = mapSeverity(message.severity);
  const line = typeof message.line === 'number' ? message.line : 0;
  const endLine = typeof message.endLine === 'number' ? message.endLine : line;
  const ruleId = message.ruleId ?? 'unknown-rule';
  const linesAffected: LineRange[] = [[line, endLine]];
  return {
    severity,
    what: `${ruleId}: ${message.message}`,
    why: message.message,
    remediation: message.fix
      ? `Apply suggested fix at ${filePath}:${line}.`
      : `Fix occurrence at ${filePath}:${line}.`,
    filesAffected: [filePath],
    linesAffected,
  };
}

function mapSeverity(severity: number): Severity {
  if (severity === 2) return 'error';
  if (severity === 1) return 'warning';
  return 'info';
}

function truncate(s: string, max = 200): string {
  if (s.length <= max) return s;
  return `${s.slice(0, max)}... (truncated)`;
}
