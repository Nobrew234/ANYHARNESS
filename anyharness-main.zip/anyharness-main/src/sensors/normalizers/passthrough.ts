// Owner: harness-sensors
// Fallback normalizer for unknown adapters. Returns inconclusive=true and surfaces
// stdout/stderr in the summary so the calling agent has something to act on.
import type { Regulation } from '../../shared/schemas/common.js';
import { SensorOutput } from '../../shared/schemas/sensor-output.js';

export interface NormalizerContext {
  id: string;
  regulation: Regulation;
}

export function passthrough(
  stdout: string,
  stderr: string,
  exitCode: number,
  ctx: NormalizerContext,
): SensorOutput {
  const trimmedStdout = stdout.trim();
  const trimmedStderr = stderr.trim();
  const summaryParts: string[] = [`exit=${exitCode}`];
  if (trimmedStdout) summaryParts.push(`stdout: ${truncate(trimmedStdout)}`);
  if (trimmedStderr) summaryParts.push(`stderr: ${truncate(trimmedStderr)}`);
  return SensorOutput.parse({
    tool: ctx.id,
    regulation: ctx.regulation,
    passed: false,
    summary: summaryParts.join(' | '),
    inconclusive: true,
    inconclusiveReason: 'No normalizer registered for this adapter; raw output passed through.',
    violations: [],
  });
}

function truncate(s: string, max = 500): string {
  if (s.length <= max) return s;
  return `${s.slice(0, max)}... (truncated)`;
}
