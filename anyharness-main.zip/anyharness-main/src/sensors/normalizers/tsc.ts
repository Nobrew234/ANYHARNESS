// Owner: harness-sensors
// Normalizer for `tsc --noEmit`. tsc emits diagnostics on stdout (default) and may also
// surface them on stderr; we scan both for resilience. Lines look like:
//   src/foo.ts(12,5): error TS2304: Cannot find name 'foo'.
import type { Severity } from '../../shared/schemas/common.js';
import { SensorOutput } from '../../shared/schemas/sensor-output.js';
import type { Violation, LineRange } from '../../shared/schemas/violation.js';
import type { NormalizerContext } from './passthrough.js';

const DIAGNOSTIC_RE = /^(.+?)\((\d+),(\d+)\):\s+(error|warning)\s+(TS\d+):\s+(.+)$/gm;

export function tsc(
  stdout: string,
  stderr: string,
  exitCode: number,
  ctx: NormalizerContext,
): SensorOutput {
  const haystack = `${stdout}\n${stderr}`;
  const violations: Violation[] = [];
  for (const match of haystack.matchAll(DIAGNOSTIC_RE)) {
    const [, filePath, lineStr, , sevStr, code, message] = match;
    if (!filePath || !lineStr || !sevStr || !code || !message) continue;
    const line = Number.parseInt(lineStr, 10);
    if (!Number.isFinite(line)) continue;
    const severity: Severity = sevStr === 'warning' ? 'warning' : 'error';
    const linesAffected: LineRange[] = [[line, line]];
    violations.push({
      severity,
      what: `${code}: ${message.trim()}`,
      why: message.trim(),
      remediation: `Resolve TypeScript diagnostic ${code} at ${filePath}:${line}.`,
      filesAffected: [filePath],
      linesAffected,
    });
  }

  const passed = exitCode === 0 && violations.length === 0;

  if (exitCode !== 0 && violations.length === 0) {
    return SensorOutput.parse({
      tool: ctx.id,
      regulation: ctx.regulation,
      passed: false,
      summary: `tsc: failed (exit ${exitCode}) but no parseable diagnostics.`,
      inconclusive: true,
      inconclusiveReason: `tsc exit ${exitCode} with no recognizable diagnostics; stderr: ${truncate(stderr.trim())}`,
      violations: [],
    });
  }

  return SensorOutput.parse({
    tool: ctx.id,
    regulation: ctx.regulation,
    passed,
    summary: passed
      ? 'tsc: clean.'
      : `tsc: ${violations.length} diagnostic(s).`,
    inconclusive: false,
    violations,
  });
}

function truncate(s: string, max = 200): string {
  if (s.length <= max) return s;
  return `${s.slice(0, max)}... (truncated)`;
}
