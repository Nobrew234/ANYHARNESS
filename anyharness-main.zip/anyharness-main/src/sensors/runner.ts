// Owner: harness-sensors
// Executes a sensor: load registry entry, substitute {target}, shell out via execa,
// normalize via the registered adapter, return llm-json (SPEC §9). Falha gracioso
// para erros de infra (ENOENT, timeout) -> inconclusive=true.
import { execa, ExecaError } from 'execa';
import { SensorOutput } from '../shared/schemas/sensor-output.js';
import type { SteeringEvent } from '../shared/schemas/steering-event.js';
import type { HarnessPaths } from '../storage/paths.js';
import { getSensor, SensorNotFoundError } from './registry.js';
import { getNormalizer } from './normalizers/index.js';

export { SensorNotFoundError };

// Recorder injected by the server/sessions layer. Kept as a local interface so this
// module typechecks even before src/sessions/ exposes a real implementation.
// TODO(harness-sessions): once `recordSteeringEvent` is exported from
// '../sessions/index.js', wire the default recorder there and remove the fallback.
export interface SteeringEventRecorder {
  (event: SteeringEvent): Promise<void> | void;
}

export interface RunSensorOptions {
  recorder?: SteeringEventRecorder;
  timeoutMs?: number;
}

const DEFAULT_TIMEOUT_MS = 60_000;

export async function runSensor(
  paths: HarnessPaths,
  id: string,
  target?: string,
  options: RunSensorOptions = {},
): Promise<SensorOutput> {
  const entry = await getSensor(paths, id);
  if (!entry) {
    throw new SensorNotFoundError(id);
  }

  const effectiveTarget = target ?? entry.defaults?.target ?? '';
  const command = entry.command.replaceAll('{target}', effectiveTarget);

  const ctx = { id: entry.id, regulation: entry.regulation };
  const normalizer = getNormalizer(entry.adapter);

  let stdout = '';
  let stderr = '';
  let exitCode = 0;
  let infraFailure: { reason: string } | null = null;

  try {
    const result = await execa(command, {
      shell: true,
      reject: false,
      timeout: options.timeoutMs ?? DEFAULT_TIMEOUT_MS,
      all: false,
      stripFinalNewline: false,
    });
    stdout = typeof result.stdout === 'string' ? result.stdout : '';
    stderr = typeof result.stderr === 'string' ? result.stderr : '';
    exitCode = typeof result.exitCode === 'number' ? result.exitCode : -1;

    if (result.timedOut) {
      infraFailure = { reason: `Sensor command timed out after ${options.timeoutMs ?? DEFAULT_TIMEOUT_MS}ms.` };
    } else if (result.failed && exitCode === -1) {
      infraFailure = { reason: `Sensor command failed to start (no exit code). stderr: ${truncate(stderr)}` };
    }
  } catch (err) {
    const execErr = err as ExecaError;
    stdout = typeof execErr.stdout === 'string' ? execErr.stdout : '';
    stderr = typeof execErr.stderr === 'string' ? execErr.stderr : '';
    exitCode = typeof execErr.exitCode === 'number' ? execErr.exitCode : -1;
    const code = (execErr as unknown as { code?: string }).code;
    if (code === 'ENOENT' || exitCode === -1) {
      infraFailure = {
        reason: `Sensor command could not be executed (${code ?? 'unknown error'}): ${execErr.shortMessage ?? execErr.message}`,
      };
    } else if (execErr.timedOut) {
      infraFailure = { reason: `Sensor command timed out.` };
    } else {
      // Non-zero exit isn't an infra failure — adapters expect to see it.
      // execa shouldn't reach here when reject:false, but be defensive.
    }
  }

  let output: SensorOutput;
  if (infraFailure) {
    output = SensorOutput.parse({
      tool: entry.id,
      regulation: entry.regulation,
      passed: false,
      summary: `Sensor '${entry.id}' could not run.`,
      inconclusive: true,
      inconclusiveReason: infraFailure.reason,
      violations: [],
    });
  } else {
    output = normalizer(stdout, stderr, exitCode, ctx);
  }

  if (options.recorder) {
    const event: SteeringEvent = {
      timestamp: new Date().toISOString(),
      kind: 'sensor',
      id: entry.id,
      target: effectiveTarget,
      regulation: entry.regulation,
      passed: output.passed,
      inconclusive: output.inconclusive,
      violationCount: output.violations.length,
      violations: output.violations,
    };
    try {
      await options.recorder(event);
    } catch {
      // Recording must never fail the sensor run.
    }
  }

  return output;
}

function truncate(s: string, max = 200): string {
  if (s.length <= max) return s;
  return `${s.slice(0, max)}... (truncated)`;
}
