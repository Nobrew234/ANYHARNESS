# anyharness

Servidor MCP que expõe o **harness inteiro** de um coding agent — Guides, Sensors, Judges, Contracts e Sessions — como protocolo único, agnóstico ao cliente. Funciona em Claude Code, Cursor, Codex ou qualquer agente compatível com MCP.

`anyharness` é complementar a `@dotcontext/cli`:

- `@dotcontext/cli` cuida do **feedforward** (guides estáticos em `.context/`).
- `anyharness` cuida do **feedback + execução** (sensors, judges, contracts, sessions em `.harness/`).

Origem conceitual e source-of-truth detalhada: [`SPEC.md`](./SPEC.md).

---

## Sumário

- [Por que existe](#por-que-existe)
- [Visão geral da surface MCP](#visão-geral-da-surface-mcp)
- [Getting Started](#getting-started)
- [Instalação e configuração do servidor MCP](#instalação-e-configuração-do-servidor-mcp)
- [Estrutura `.harness/`](#estrutura-harness)
- [Sensors](#sensors)
- [Judges](#judges)
- [Contracts (Specs + Tasks)](#contracts-specs--tasks)
- [Sessions](#sessions)
- [Steering Loop](#steering-loop)
- [Workflows](#workflows)
- [Princípios de design](#princípios-de-design)
- [Conexão com `@dotcontext`](#conexão-com-dotcontext)
- [Roadmap e fora de escopo](#roadmap-e-fora-de-escopo)

---

## Por que existe

Hoje o harness de um coding agent está espalhado: guides em `CLAUDE.md`/`AGENTS.md`/`.cursor/rules`, sensors em linters cada um com sua interface, judges ad-hoc com prompts soltos, sessions isoladas por ferramenta, contracts inexistentes ou virando "prompt solto".

`anyharness` consolida tudo isso atrás de uma única superfície MCP — o agente descobre, executa e aprende com o harness; o humano edita o harness pela mesma surface (steering loop human-in-the-loop). MCP é o transporte certo porque funciona em qualquer cliente que fale o protocolo.

Três adições conceituais sobre o modelo da Birgitta Böckeler que o harness incorpora:

1. **Contracts (Specs + Tasks)** atacam o *behaviour harness* — o "elephant in the room".
2. **Sessions** materializam continuidade entre execuções e sustentam o steering loop.
3. **Judges como cidadão de primeira classe**, separados dos sensors computacionais.

---

## Visão geral da surface MCP

| Bloco | Tipo MCP | Nome | Direção |
| --- | --- | --- | --- |
| Guides | `resources/` | `harness://guides/{kind}/{id}` | feedforward |
| Sensors | `tools/` | `sensor.run`, `sensor.list`, `sensor.register` | feedback computacional |
| Judges | `tools/` | `judge.list`, `judge.review`, `judge.record` | feedback inferencial (cliente avalia) |
| Sessions | `tools/` + `resources/` | `session.start`, `session.append`, `session.get` | estado |
| Contracts → Specs | `resources/` + `tools/` | `harness://contracts/specs/{id}`, `contract.spec.validate` | feedforward (behaviour) |
| Contracts → Tasks | `tools/` | `contract.task.next`, `contract.task.complete` | execução |
| Workflows | `prompts/` | `workflow.PREVC`, `workflow.bug-fix` | orquestração |
| Steering loop | `tools/` | `harness.steer.suggest` | aprendizado |

Toda sensor/judge declara uma `regulation` — `maintainability` (legibilidade, dívida), `fitness` (arquitetura, segurança estrutural) ou `behaviour` (cumpre a spec). Permite filtrar `sensor.list({ regulation: "behaviour" })` e cruzar coverage por categoria.

---

## Getting Started

Pré-requisitos: Node 20+ e um cliente MCP (Claude Code, Cursor ou Codex). O servidor não chama LLM por conta própria — a inferência dos judges é feita pelo próprio cliente conectado, então **nenhuma API key extra** é necessária.

1. **Instale o pacote**

   ```bash
   npm install -g anyharness
   # ou, sem instalação global:
   npx anyharness
   ```

2. **Crie a pasta `.harness/`** na raiz do projeto. O layout completo está em [Estrutura `.harness/`](#estrutura-harness). Mínimo viável para começar:

   ```
   .harness/
   ├── guides/rules/
   ├── sensors/
   ├── judges/
   ├── contracts/specs/
   └── workflows/
   ```

3. **Registre o servidor no seu cliente MCP** (exemplo em Claude Code, `.mcp.json` na raiz):

   ```json
   {
     "mcpServers": {
       "anyharness": {
         "command": "anyharness"
       }
     }
   }
   ```

4. **Adicione um sensor** — copie um dos adapters built-in (eslint, tsc, semgrep) para `.harness/sensors/`, ou registre via tool:

   ```json
   {
     "id": "tsc",
     "kind": "type-check",
     "regulation": "maintainability",
     "command": "tsc --noEmit",
     "adapter": "tsc"
   }
   ```

5. **Rode o primeiro sensor** a partir do agente: `sensor.run({ id: "tsc" })`. O output normalizado já vem pronto para a LLM consumir.

6. **Adicione uma spec** em `.harness/contracts/specs/<id>.yaml` com `acceptanceCriteria`, `checks` e `tasks`. Use `contract.task.next({ spec_id })` para iterar.

7. **Rode um judge** quando precisar de feedback semântico: o cliente chama `judge.review({ rubric_id, target })`, recebe `{ instructions, schema, context }`, raciocina e devolve a review estruturada via `judge.record({ rubric_id, target, result })`. Sem chamada de LLM saindo do servidor.

8. **Inspecione o steering loop** depois de algumas execuções: `harness.steer.suggest()` consome o log em `.harness/.local/steering/log.jsonl` e propõe novos guides quando o mesmo problema recorre.

A partir daqui, cada subsistema tem seção dedicada abaixo.

---

## Instalação e configuração do servidor MCP

### Instalação

```bash
npm install -g anyharness
```

O binário `anyharness` fica disponível no PATH e inicializa o servidor via transporte stdio.

Para uso em projeto sem instalação global:

```bash
npx anyharness
```

Requisito mínimo: Node.js 20 ou superior.

### Variáveis de ambiente

| Variável | Obrigatória | Descrição |
| --- | --- | --- |
| `HARNESS_ROOT` | Não | Caminho para a pasta `.harness/` do projeto. Default: `.harness` (relativo ao cwd do processo). |

O servidor **não** lê `ANTHROPIC_API_KEY` (nem qualquer chave de modelo). Como a inferência dos judges fica a cargo do cliente MCP, o servidor é stateless em relação a credenciais de LLM.

### Configuração no Claude Code

Crie ou edite `.mcp.json` na raiz do repositório:

```json
{
  "mcpServers": {
    "anyharness": {
      "command": "anyharness",
      "env": {
        "HARNESS_ROOT": ".harness"
      }
    }
  }
}
```

Se o pacote não estiver instalado globalmente, substitua `"command"` por `"npx"` e adicione `"args": ["anyharness"]`:

```json
{
  "mcpServers": {
    "anyharness": {
      "command": "npx",
      "args": ["anyharness"],
      "env": {
        "HARNESS_ROOT": ".harness"
      }
    }
  }
}
```

### Configuração no Cursor

Em `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "anyharness": {
      "command": "anyharness",
      "env": {
        "HARNESS_ROOT": ".harness"
      }
    }
  }
}
```

### Configuração no Codex (OpenAI)

Em `codex.yaml` ou na seção `mcp_servers` da configuração do agente:

```yaml
mcp_servers:
  - name: anyharness
    command: anyharness
    env:
      HARNESS_ROOT: .harness
```

### Transporte e cold start

O servidor usa exclusivamente transporte **stdio**. HTTP/SSE está fora do escopo do MVP. O processo deve ser iniciado pelo cliente MCP como subprocesso; não há porta a abrir nem daemon a gerenciar.

Cold start garantido em menos de 1 segundo (SPEC §12). O watcher `chokidar` sobre `.harness/` é iniciado no mesmo `start()`, antes de conectar o transporte, de forma que notificações de mudança em arquivos já estão ativas quando o primeiro request chega.

---

## Estrutura `.harness/`

`.harness/` é a source-of-truth do harness. O servidor lê em runtime e observa via watcher centralizado. Todo conteúdo fora de `.local/` é versionável no Git. `.local/` é gitignored por default.

```
.harness/
├── guides/
│   ├── rules/
│   │   └── <id>.md
│   ├── skills/
│   │   └── <id>.md
│   └── subagents/
│       └── <id>.md
├── sensors/
│   └── <id>.yaml
├── judges/
│   ├── <rubric_id>.md
│   └── <rubric_id>.schema.json
├── contracts/
│   ├── specs/
│   │   └── <id>.{yaml,md}
│   └── tasks/
│       └── <id>.yaml
├── workflows/
│   └── <id>.md
└── .local/                          # gitignored
    ├── sessions/
    │   └── <session_id>.jsonl
    ├── steering/
    │   └── log.jsonl
    └── telemetry/
        └── mcp.jsonl
```

### `guides/`

Exposto como resources MCP sob o scheme `harness://guides/{kind}/{id}`. Três subpastas fixas:

- `rules/` — regras de código, convenções, restrições. Mapeiam para `harness://guides/rules/<id>`.
- `skills/` — guias de habilidade ou padrões de execução. Mapeiam para `harness://guides/skills/<id>`.
- `subagents/` — definições de subagentes e suas responsabilidades. Mapeiam para `harness://guides/subagents/<id>`.

Todos os arquivos são Markdown (`.md`). O watcher emite `notifications/resources/list_changed` quando um arquivo é adicionado ou removido, e `notifications/resources/updated` quando um arquivo existente é modificado.

### `sensors/`

Um arquivo `.yaml` por sensor registrado. Cada arquivo declara o `command` a executar, o `regulation` (`maintainability`, `fitness` ou `behaviour`) e o schema de output esperado. O tool `sensor.register` escreve nesta pasta; é a única write path além do humano. Mudanças disparam `notifications/tools/list_changed`.

### `judges/`

Dois arquivos por rubrica:

- `<rubric_id>.md` — prompt versionado, renderizado pelo servidor e devolvido ao cliente MCP em `judge.review` (o cliente é quem executa a inferência).
- `<rubric_id>.schema.json` — JSON Schema que valida o output da review antes que `judge.record` o aceite e o agregue no envelope SPEC §9.

Mudanças disparam `notifications/tools/list_changed`.

### `contracts/`

- `specs/` — especificações comportamentais em YAML ou Markdown. Cada spec declara `acceptanceCriteria`, `checks` (sensores e/ou judges a invocar) e `tasks`. Exposta como resource `harness://contracts/specs/<id>` e acessível via tool `contract.spec.validate`. Mudanças disparam `notifications/resources/list_changed`.
- `tasks/` — estado das tasks ativas e concluídas. Escrito pelo servidor via `contract.task.complete`. Não exposto como resource (acessado via tools `contract.task.next` e `contract.task.complete`).

### `workflows/`

Arquivos Markdown com o conteúdo dos prompts de workflow (`PREVC.md`, `bug-fix.md`). Expostos primariamente como `prompts/` MCP (`workflow.PREVC`, `workflow.bug-fix`) e como fallback resource `harness://workflows/<id>` para clientes que não suportam `prompts/`. Mudanças disparam `notifications/resources/list_changed`.

### `.local/`

Dados de runtime, gitignored. Criados automaticamente pelo servidor no `start()`.

- `sessions/` — um arquivo `.jsonl` por sessão (append-only), escrito por `session.append`.
- `steering/log.jsonl` — eventos de execução de sensor e judge, consumidos por `harness.steer.suggest`.
- `telemetry/mcp.jsonl` — log estruturado de todas as tool calls (nome, timestamp, resultado ok/erro).

---

## Sensors

Sensors são a camada de feedback computacional do harness: ferramentas determinísticas, baratas e rápidas que rodam em todo commit (e opcionalmente em pre-commit) para capturar problemas antes de qualquer chamada a um judge. Qualquer coisa que um linter, type-checker ou analisador estrutural consegue detectar fica aqui, não em judges.

Cada sensor declara uma `regulation`, que classifica a categoria de qualidade que ele cobre:

- `maintainability` — legibilidade, consistência e cobertura de tipos. Sensores de lint e type-check ficam aqui.
- `fitness` — segurança, conformidade estrutural, padrões arquiteturais. Scans estáticos como semgrep ficam aqui.
- `behaviour` — verificações de comportamento em runtime (ainda não há adapters built-in para esta categoria; ela existe para sensores customizados).

A latência alvo por execução é abaixo de 5 segundos. Sensores lentos por natureza (scans completos de dependências, por exemplo) devem ser marcados como `regulation: fitness` e incluídos em fases opt-in, não no ciclo padrão.

### Tools MCP

#### `sensor.list`

Lista todos os sensores registrados em `.harness/sensors/`. Aceita filtros opcionais por `kind` e por `regulation`.

```json
// input
{ "kind": "linter" }

// output
{
  "sensors": [
    {
      "id": "eslint",
      "kind": "linter",
      "regulation": "maintainability",
      "command": "eslint --format json {target}",
      "description": "ESLint with the project config; emits JSON consumed by the eslint normalizer."
    }
  ]
}
```

Valores válidos para `kind`: `linter`, `type-check`, `structural`, `custom`.
Valores válidos para `regulation`: `maintainability`, `fitness`, `behaviour`.

#### `sensor.run`

Executa um sensor pelo `id`. O campo `target` sobrescreve o `defaults.target` declarado no YAML; se omitido, o default do registro é usado.

```json
// input
{ "id": "eslint", "target": "src/sensors/**/*.ts" }

// output (SPEC §9) — exemplo com uma violação
{
  "tool": "eslint",
  "regulation": "maintainability",
  "passed": false,
  "summary": "eslint: 1 issue(s) (1 error, 0 warning).",
  "inconclusive": false,
  "violations": [
    {
      "severity": "error",
      "what": "no-unused-vars: 'foo' is defined but never used.",
      "why": "'foo' is defined but never used.",
      "remediation": "Fix occurrence at src/sensors/runner.ts:12.",
      "filesAffected": ["src/sensors/runner.ts"],
      "linesAffected": [[12, 12]]
    }
  ]
}
```

#### `sensor.register`

Adiciona ou atualiza um sensor em `.harness/sensors/<id>.yaml`. A operação é idempotente: se o arquivo já existe com conteúdo idêntico (mesmo `id`, `command`, `adapter`, `regulation`, `kind`), retorna `changed: false` sem escrever no disco.

```json
// input
{
  "id": "custom-arch",
  "kind": "structural",
  "regulation": "fitness",
  "command": "node scripts/arch-check.js {target}",
  "adapter": "passthrough",
  "description": "Verifica dependências proibidas entre camadas.",
  "defaults": { "target": "src" }
}

// output
{
  "registered": true,
  "path": ".harness/sensors/custom-arch.yaml",
  "changed": true
}
```

### Adapters registrados

Os três adapters built-in vivem em `src/sensors/normalizers/` e seus registros em `.harness/sensors/`.

**`eslint`** — `kind: linter`, `regulation: maintainability`

```yaml
# .harness/sensors/eslint.yaml
id: eslint
kind: linter
regulation: maintainability
command: "eslint --format json {target}"
adapter: eslint
description: "ESLint with the project config; emits JSON consumed by the eslint normalizer."
defaults:
  target: "src/**/*.ts"
```

Executa `eslint --format json`, faz parse do array de resultados e mapeia cada `messages[]` para um `Violation`. O campo `remediation` indica arquivo e linha exatos; quando o ESLint emite um `fix` automático, a remediation especifica onde aplicar.

**`tsc`** — `kind: type-check`, `regulation: maintainability`

```yaml
# .harness/sensors/tsc.yaml
id: tsc
kind: type-check
regulation: maintainability
command: "tsc --noEmit"
adapter: tsc
description: "TypeScript compile check (no emit); diagnostics parsed from stdout/stderr."
```

Executa `tsc --noEmit` e faz parse de stdout e stderr via regex no formato `arquivo(linha,coluna): error TSxxxx: mensagem`. `passed` é `true` somente quando `exit_code === 0` e nenhuma linha de diagnóstico for encontrada.

**`semgrep`** — `kind: structural`, `regulation: fitness`

```yaml
# .harness/sensors/semgrep.yaml
id: semgrep
kind: structural
regulation: fitness
command: "semgrep --config=auto --json {target}"
adapter: semgrep
description: "Semgrep structural scan with auto config; emits JSON consumed by the semgrep normalizer."
defaults:
  target: "."
```

Executa `semgrep --config=auto --json`, faz parse de `results[]` e mapeia cada entrada para um `Violation`. Severidades do semgrep (`ERROR`, `HIGH`, `CRITICAL`, `WARNING`, `MEDIUM`, `INFO`, `LOW`) são normalizadas para `error`, `warning` e `info`.

### Output normalizado (SPEC §9)

Todo `sensor.run` retorna o mesmo envelope, independente do adapter:

```json
{
  "tool": "<id>",
  "regulation": "maintainability | fitness | behaviour",
  "passed": true,
  "summary": "string curta legível",
  "inconclusive": false,
  "violations": [
    {
      "severity": "error | warning | info",
      "what": "descrição do problema",
      "why": "explicação",
      "remediation": "instrução específica de correção",
      "filesAffected": ["src/foo.ts"],
      "linesAffected": [[12, 14]],
      "guideUri": "harness://guides/rules/<id>"
    }
  ]
}
```

O campo `guideUri` é opcional e presente quando o sensor cobre uma regra documentada em `.harness/guides/rules/<id>.md`, permitindo ao agente buscar contexto adicional via `resources/read`.

**`passed: false` vs `inconclusive: true`**

A distinção é precisa e não deve ser confundida:

- `passed: false`, `inconclusive: false` — o sensor rodou corretamente e encontrou violações reais no código. O agente deve ler `violations[]` e aplicar as remediações.
- `inconclusive: true` — o sensor não conseguiu produzir um resultado confiável por razão de infraestrutura: binário não encontrado (`ENOENT`), timeout, output em formato inesperado, falha ao parsear JSON. Nesse caso `violations[]` está vazio e `inconclusiveReason` descreve o problema. O agente não deve tratar isso como código limpo nem como código quebrado.

Exemplos concretos de `inconclusive`:

- `eslint` não instalado no projeto → `ENOENT` ao tentar executar → `inconclusive: true, inconclusiveReason: "Sensor command could not be executed (ENOENT): ..."`.
- `tsc` termina com exit não-zero mas não emite nenhuma linha no formato de diagnóstico → `inconclusive: true, inconclusiveReason: "tsc exit 1 with no recognizable diagnostics; ..."`.
- Qualquer sensor ultrapassa 60 segundos (timeout padrão do runner) → `inconclusive: true, inconclusiveReason: "Sensor command timed out after 60000ms."`.

### Adicionando um sensor customizado

1. Chame `sensor.register` com os campos obrigatórios (`id`, `kind`, `regulation`, `command`, `adapter`). O arquivo `.harness/sensors/<id>.yaml` é criado ou atualizado.
2. Se o `adapter` for `passthrough`, o stdout cru é repassado como `summary` sem normalização de `violations`.
3. Para um adapter com normalização completa, implemente uma função pura em `src/sensors/normalizers/<id>.ts` com assinatura `(stdout, stderr, exitCode, ctx) => SensorOutput` e exporte-a em `src/sensors/normalizers/index.ts`.
4. O registry é lido em runtime; após gravar o YAML o sensor aparece imediatamente em `sensor.list`.

---

## Judges

Judges são avaliadores **inferenciais**: feedback semântico sobre propriedades que sensors computacionais (ESLint, tsc, Semgrep) não conseguem inspecionar — adesão a spec, qualidade de teste, over-engineering. Sensors fecham o *maintainability harness*; judges fecham o *behaviour harness*.

### Servidor não chama LLM

Diferente do modelo "LLM-as-judge clássico", o `anyharness` **não chama nenhum LLM por conta própria**. A inferência é feita pelo próprio cliente MCP que está conectado — Claude Code, Cursor, Codex, ou qualquer outro agente compatível —, que já é um modelo capaz de raciocinar sobre o prompt da rubric. O servidor cuida exclusivamente de:

1. Versionar a rubric (`.harness/judges/<id>.md`).
2. Renderizar o prompt com o contexto certo (target + spec opcional).
3. Validar o output da review contra o schema (`.harness/judges/<id>.schema.json`).
4. Normalizar e logar o resultado para o steering loop.

Resultado: zero `ANTHROPIC_API_KEY` no servidor, zero dependência de SDK de modelo, zero custo extra de inferência (a chamada já está acontecendo no cliente). O modelo do cliente é o modelo do judge.

### Tools MCP

Três tools no namespace raiz (sem prefixo, conforme decisão fechada SPEC §15):

- `judge.list({ rubric? })` — lista rubrics disponíveis lidas de `.harness/judges/<rubric>.md`. Filtro opcional por id.
- `judge.review({ rubric_id, target, spec_id? })` — renderiza o prompt versionado e devolve `{ instructions, schema, context, submission }` para o cliente MCP avaliar. **Não chama LLM.**
- `judge.record({ rubric_id, target, result, spec_id? })` — recebe a review estruturada produzida pelo cliente, valida contra `<rubric>.schema.json`, devolve o envelope normalizado SPEC §9 e grava no steering log.

### Fluxo em duas fases

```
agente  ──► judge.review(rubric_id, target, spec_id?)
                                              │
                                              ▼
                              servidor renderiza prompt + schema + contexto
                                              │
            ◄─── { instructions, schema, context, submission } ───
agente raciocina sobre o prompt e produz JSON conforme schema
agente  ──► judge.record(rubric_id, target, result)
                                              │
                                              ▼
                       servidor valida pelo schema, normaliza, loga
                                              │
                              ◄─── { tool, regulation, passed, ... } ───
```

#### `judge.list`

```json
// input
{ "rubric": "spec-adherence" }

// output
{
  "rubrics": [
    {
      "rubric_id": "spec-adherence",
      "regulation": "behaviour",
      "description": "Avalia se a implementação cumpre a spec sem add/subtract escopo"
    }
  ]
}
```

Sem `model` no listing: a rubric não dita qual modelo usar — quem decide é o cliente.

#### `judge.review` (fase 1 — preparação)

```json
// input
{
  "rubric_id": "spec-adherence",
  "target": "src/auth/login.ts",
  "spec_id": "auth.login"
}

// output
{
  "rubric_id": "spec-adherence",
  "regulation": "behaviour",
  "instructions": "<prompt renderizado, com placeholders <<<SPEC>>>, <<<TARGET>>>, <<<SCHEMA>>> já substituídos>",
  "schema": {
    "type": "object",
    "properties": {
      "passed": { "type": "boolean" },
      "summary": { "type": "string" },
      "violations": { "type": "array", "items": { "$ref": "#/definitions/Violation" } }
    }
  },
  "context": {
    "spec": "id: auth.login\ntitle: ...\nacceptanceCriteria:\n  - ...",
    "target": "// content of src/auth/login.ts ..."
  },
  "submission": {
    "tool": "judge.record",
    "correlation": { "rubric_id": "spec-adherence", "target": "src/auth/login.ts" }
  }
}
```

`instructions` é o que o agente lê e interpreta com o próprio modelo. `schema` é o contrato de saída. `context` traz a spec e o target já carregados (servidor faz o IO). `submission` é só uma dica explícita de qual tool chamar a seguir.

#### `judge.record` (fase 2 — verdict)

O cliente raciocina sobre `instructions`, gera o JSON conforme `schema` e devolve:

```json
// input
{
  "rubric_id": "spec-adherence",
  "target": "src/auth/login.ts",
  "spec_id": "auth.login",
  "result": {
    "passed": false,
    "summary": "Implementação adiciona rate-limit não previsto na spec e omite o 401 para credencial inválida.",
    "violations": [
      {
        "severity": "error",
        "what": "Credencial inválida retorna 500 em vez de 401.",
        "why": "Spec auth.login, AC-2, exige 401 para credencial inválida.",
        "remediation": "Mapear AuthError para HTTP 401 antes do handler genérico.",
        "filesAffected": ["src/auth/login.ts"],
        "linesAffected": [[42, 47]]
      },
      {
        "severity": "warning",
        "what": "Adiciona rate-limit por IP não previsto na spec.",
        "why": "Scope addition: nenhum critério menciona rate-limit.",
        "remediation": "Remover o middleware ou abrir uma nova spec.",
        "filesAffected": ["src/auth/login.ts"],
        "linesAffected": [[12, 18]]
      }
    ]
  }
}

// output (envelope normalizado SPEC §9 — mesmo schema dos sensors)
{
  "tool": "spec-adherence",
  "regulation": "behaviour",
  "passed": false,
  "summary": "Implementação adiciona rate-limit não previsto na spec e omite o 401 para credencial inválida.",
  "inconclusive": false,
  "violations": [
    { "severity": "error",   "what": "...", "why": "...", "remediation": "...", "filesAffected": ["..."], "linesAffected": [[42,47]] },
    { "severity": "warning", "what": "...", "why": "...", "remediation": "...", "filesAffected": ["..."], "linesAffected": [[12,18]] }
  ]
}
```

Se `result` não bater com o schema da rubric, `judge.record` retorna `inconclusive: true` com `inconclusiveReason: "result_failed_schema_validation"` e a lista dos campos que falharam — o cliente pode tentar de novo com correção. Quando o cliente próprio sinaliza que não consegue decidir (target enorme, spec ambígua), envia `result.passed: false` com `result.inconclusive: true` e `result.inconclusiveReason` — o servidor preserva isso no envelope final.

### Estrutura de uma rubric

Cada rubric vive em dois arquivos versionados em `.harness/judges/`:

- `<rubric>.md` — frontmatter YAML (id, regulation, description, inputs) + corpo do prompt com placeholders `<<<SPEC>>>`, `<<<TARGET>>>`, `<<<SCHEMA>>>`.
- `<rubric>.schema.json` — JSON Schema do output, derivado do schema compartilhado `SensorOutput` da SPEC §9.

A rubric MVP `.harness/judges/spec-adherence.md` traz o frontmatter:

```yaml
---
id: spec-adherence
regulation: behaviour
description: Avalia se a implementação cumpre a spec sem add/subtract escopo
inputs:
  - kind: target
    optional: false
  - kind: spec-ref
    optional: false
---
```

Sem `model:` e sem `budget:` — essas decisões pertencem ao cliente que vai executar a inferência. O prompt instrui o juiz a usar `passed: true` somente quando o artefato satisfaz **cada** critério de aceitação **e** não introduz comportamento fora da spec, com regras explícitas para subtração de escopo, adição de escopo e contradição direta. Cada `violation` carrega `severity`, `what`, `why` (referência à cláusula da spec), `remediation`, `filesAffected` e `linesAffected`.

O schema acompanhante `.harness/judges/spec-adherence.schema.json` fixa a identidade do output:

```json
{
  "tool": { "type": "string", "const": "spec-adherence" },
  "regulation": { "type": "string", "const": "behaviour" }
}
```

e define `Violation` com `severity` em `error | warning | info`, `linesAffected` como array de tuplas `[startLine, endLine]` e `guideUri` opcional no scheme `harness://`.

### Determinismo e qualidade da review

Sem chamada de LLM no servidor, três decisões mantêm a review verificável:

- **Prompt versionado em arquivo.** Mudança em `.harness/judges/<rubric>.md` passa por commit/review como qualquer código. O agente nunca improvisa o prompt.
- **Schema obrigatório.** A resposta do cliente é validada antes de virar evidência. JSON inválido vira `inconclusive: true` com motivo estruturado.
- **Steering log audita o passado.** Toda chamada de `judge.record` deixa rastro em `.harness/.local/steering/log.jsonl`. Padrões de violations recorrentes podem virar guides via `harness.steer.suggest`.

Determinismo do modelo (temperatura, seed, top-p) é decisão **do cliente**: cliente que quer review reprodutível roda em modo determinístico; cliente que prefere modelo barato escolhe outro. O servidor não tem opinião.

### Por que sem LLM no servidor

Razões deliberadas:

- **Zero lock-in de modelo.** Funciona com qualquer cliente MCP — Claude Code (Sonnet/Opus), Cursor (multi-modelo), Codex, agentes custom com Llama local.
- **Zero gestão de chave de API no servidor.** Não há `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, etc. O servidor é stateless de credencial.
- **Zero custo extra.** A chamada de inferência já está acontecendo no loop do cliente — reaproveitamos o mesmo modelo, tokens e contexto.
- **MCP-nativo.** O cliente é, por definição, o LLM. Pedir para ele realizar a inferência é mais alinhado ao protocolo do que abrir um caller paralelo no servidor.

### Output normalizado

Judge e sensor compartilham o mesmo formato de saída (SPEC §9):

```
{ tool, regulation, passed, summary, inconclusive, violations[] }
```

Isso permite ao agente tratar resultado de `sensor.run` e de `judge.record` pela mesma pipeline de leitura, agregação e steering log. `regulation` é obrigatório em toda rubric — judges defaultam para `behaviour`, que é o lar natural do bloco de avaliação inferencial.

---

## Contracts (Specs + Tasks)

Contracts são o bloco que ataca o **behaviour harness** — a parte que sensors estáticos e judges isolados não fecham sozinhos. Uma **Spec** é feedforward: descreve em prosa estruturada o comportamento esperado de uma feature (acceptance criteria, exemplos, checks que provam adesão). Uma **Task** é a unidade verificável que materializa parte daquela spec — granular o suficiente para um agente executar e marcar como concluída com evidência.

A regra implícita: Spec é resource (passivo, lido), Task é tool (transita estado, escreve em disco). Quem lê a spec sabe o que precisa acontecer; quem completa a task prova que aconteceu.

### Resource: `harness://contracts/specs/{id}`

Lazy-loaded. Retorna o markdown (ou YAML) cru do arquivo em `.harness/contracts/specs/<id>.{yaml,md}`. Útil quando o agente quer mostrar a spec original ao usuário em vez do schema parseado.

Formato mínimo conforme SPEC §10 — exemplo real em `.harness/contracts/specs/example-signup.yaml`:

```yaml
id: example-signup
title: User can sign up via magic link
acceptanceCriteria:
  - POST /auth/signup returns 200 with email param
  - Email is sent via SES
checks:
  - kind: sensor
    id: tsc
  - kind: judge
    rubric: spec-adherence
tasks:
  - id: signup-handler
    description: Implement /auth/signup handler
    acceptanceRefs: [0]
  - id: signup-ses
    description: Wire SES sender
    acceptanceRefs: [1]
```

Markdown com frontmatter equivalente também é aceito; bullets sob `## Acceptance Criteria` no corpo são colhidos automaticamente quando `acceptanceCriteria:` está ausente do frontmatter (`src/contracts/spec-loader.ts`). O `id` declarado no arquivo precisa bater com o nome do arquivo — discrepância vira `SpecParseError`.

`acceptanceRefs` indexa o array `acceptanceCriteria` (zero-based), conectando cada task aos critérios que ela cobre.

### Tool: `contract.spec.validate`

Carrega a spec, executa cada item de `checks[]` contra o `artifact` informado, e agrega tudo num único `SensorOutput` normalizado (mesmo formato de qualquer sensor — ver SPEC §9). Por definição, `regulation: "behaviour"`.

Para cada `check`:

- `{ kind: sensor, id: <sensor_id> }` → invoca o runner equivalente a `sensor.run({ id, target: artifact })` **in-line** e adiciona o resultado ao agregado.
- `{ kind: judge, rubric: <rubric_id> }` → **não é executado pelo servidor.** O servidor renderiza o prompt da rubric (igual `judge.review` faria) e devolve um sub-resultado `pending: requires_agent_review` com `instructions`, `schema`, `context` e `submission`. O agente é responsável por avaliar cada review com seu próprio modelo e registrar via `judge.record`, ou anexar a review como `evidence` em `contract.task.complete`.

Sensor ou rubric inexistente, timeout, command not found — tudo vira um sub-resultado `inconclusive: true` com `inconclusiveReason`, nunca exception. O agregado segue a regra: `passed` só é `true` se todos os sensor checks passaram **e** não há judge checks pendentes; `inconclusive` é `true` quando nada falhou de fato mas algum check ficou inconclusivo. Quando há judge checks pendentes, `passed: false`, `inconclusive: false` e o campo `pending[]` lista o que falta o agente resolver. Violations são concatenadas (`flatMap`) preservando proveniência.

É essa orquestração que materializa o princípio "Behaviour harness = Contracts + Judges": sensor determinístico roda no servidor, judge inferencial roda no cliente, e a spec é a régua que amarra os dois sob o mesmo artefato.

Input:

```json
{
  "id": "example-signup",
  "artifact": "src/auth/signup.ts"
}
```

Output (todos os checks passaram):

```json
{
  "tool": "contract.spec.validate:example-signup",
  "regulation": "behaviour",
  "passed": true,
  "summary": "2/2 checks passed",
  "inconclusive": false,
  "violations": []
}
```

Output (judge falhou, sensor inconclusivo):

```json
{
  "tool": "contract.spec.validate:example-signup",
  "regulation": "behaviour",
  "passed": false,
  "summary": "0/2 checks passed",
  "inconclusive": false,
  "violations": [
    {
      "rule": "spec-adherence:ses-wiring",
      "message": "SES sender not invoked in signup handler",
      "severity": "error"
    }
  ]
}
```

Spec não encontrada retorna `passed: false` + `inconclusive: true` com `inconclusiveReason: "spec_not_found"` — não throw. `contract.spec.validate` é puramente leitura: nunca escreve em `.harness/contracts/tasks/`.

### Tool: `contract.task.next`

Itera `spec.tasks[]` na ordem do array (sem priorização sofisticada no MVP) e devolve a primeira task que não esteja `completed`. Se a task ainda não existe em `.harness/contracts/tasks/<id>.yaml`, é criada com `status: pending`. Se está `pending`, transita para `in_progress` e persiste antes de retornar. Se já estava `in_progress`, retorna como está.

Input:

```json
{ "spec_id": "example-signup" }
```

Output:

```json
{
  "task": {
    "id": "signup-handler",
    "spec_id": "example-signup",
    "description": "Implement /auth/signup handler",
    "status": "in_progress",
    "evidence": [],
    "completedAt": null
  }
}
```

Quando todas as tasks da spec estão completas, retorna `{ "task": null }`.

### Tool: `contract.task.complete`

Marca a task como `completed`, anexa a `evidence` informada (append-only — evidence prévia preservada) e grava `completedAt` em ISO 8601.

**Idempotência:** chamar `contract.task.complete` em task já `completed` falha com `TaskAlreadyCompletedError`. Não é no-op silencioso. Task inexistente → `TaskNotFoundError`. As duas decisões refletem o princípio de erros estruturados em vez de tolerância silenciosa que mascara bugs do agente.

Input:

```json
{
  "task_id": "signup-handler",
  "evidence": [
    {
      "kind": "sensor_run",
      "sensor": "tsc",
      "passed": true,
      "timestamp": "2026-04-30T14:22:01.000Z"
    },
    {
      "kind": "pr_link",
      "url": "https://github.com/acme/app/pull/482",
      "timestamp": "2026-04-30T14:22:05.000Z"
    }
  ]
}
```

Output:

```json
{
  "task": {
    "id": "signup-handler",
    "spec_id": "example-signup",
    "description": "Implement /auth/signup handler",
    "status": "completed",
    "evidence": [
      { "kind": "sensor_run", "sensor": "tsc", "passed": true, "timestamp": "2026-04-30T14:22:01.000Z" },
      { "kind": "pr_link", "url": "https://github.com/acme/app/pull/482", "timestamp": "2026-04-30T14:22:05.000Z" }
    ],
    "completedAt": "2026-04-30T14:22:06.123Z"
  }
}
```

### Estado das tasks em disco

Tasks são persistidas em `.harness/contracts/tasks/<task_id>.yaml`. O schema (`src/shared/schemas/task.ts`) é:

```yaml
id: signup-handler
spec_id: example-signup
description: Implement /auth/signup handler
status: in_progress         # pending | in_progress | completed
evidence:                   # discriminated union por `kind`
  - kind: sensor_run
    sensor: tsc
    passed: true
    timestamp: 2026-04-30T14:22:01.000Z
  - kind: judge_review
    rubric: spec-adherence
    passed: false
    timestamp: 2026-04-30T14:25:00.000Z
  - kind: pr_link
    url: https://github.com/acme/app/pull/482
    timestamp: 2026-04-30T14:22:05.000Z
  - kind: note
    text: Aguardando review humano do template de email
    timestamp: 2026-04-30T14:30:00.000Z
completedAt: null
```

Os quatro `kind` de evidence suportados são `sensor_run`, `judge_review`, `pr_link` e `note`. Re-runs de `contract.spec.validate` enquanto a task está `in_progress` podem acumular evidence; a transição para `completed` só acontece via `contract.task.complete`.

Specs não são versionadas no MVP: editar a spec edita o contrato corrente. Tasks já criadas a partir de uma versão anterior podem ficar inconsistentes — responsabilidade humana resolver até ter `?version=` no resource URI.

---

## Sessions

Uma sessão representa **uma execução do agente conectada a uma task ou workflow** — o canal pelo qual o harness ganha continuidade entre invocações isoladas de tools. Sem sessão, cada chamada de `sensor.run` ou `judge.review` é amnésica; com sessão, todas elas formam um rastro append-only que pode ser retomado, replayado e analisado.

Três tools compõem a API:

- `session.start({ workflow?, contract_id? })` — abre uma nova sessão, gera `session_id` (UUID v4) e grava o header como primeira linha do arquivo.
- `session.append({ session_id, event })` — anexa um evento validado por schema ao final do jsonl.
- `session.get({ session_id })` — relê header + eventos preservando ordem de gravação.

Exemplo de fluxo:

```json
// session.start
{ "workflow": "PREVC", "contract_id": "spec-001" }

// resposta
{ "session_id": "9c4e1f2a-7b3d-4e6a-8f12-aa01bd5e7c90", "startedAt": "2026-04-30T14:22:10.412Z" }
```

```json
// session.append
{
  "session_id": "9c4e1f2a-7b3d-4e6a-8f12-aa01bd5e7c90",
  "event": {
    "kind": "sensor_run",
    "sensor": "eslint",
    "passed": false,
    "violationCount": 3,
    "regulation": "maintainability",
    "timestamp": "2026-04-30T14:22:48.901Z"
  }
}

// resposta
{ "appended": true, "eventCount": 1 }
```

```json
// session.get
{ "session_id": "9c4e1f2a-7b3d-4e6a-8f12-aa01bd5e7c90" }

// resposta
{
  "header": { "session_id": "...", "workflow": "PREVC", "contract_id": "spec-001", "startedAt": "..." },
  "events": [ { "kind": "sensor_run", "...": "..." } ]
}
```

Cinco tipos de evento canônicos cobrem o ciclo de execução (mais `task_started` / `task_completed` para amarração com contracts):

- `tool_call` — qualquer ferramenta invocada pelo agente; carrega `tool` e `args`.
- `sensor_run` — resultado de `sensor.run`; carrega `sensor`, `passed`, `violationCount`, `regulation`.
- `judge_review` — resultado de `judge.review`; carrega `rubric`, `passed`, `violationCount`.
- `decision` — escolha do agente com justificativa; carrega `what` e `rationale`.
- `human_intervention` — momento em que o humano interveio diretamente; carrega `what`.

Todos os eventos são validados por `zod` (`src/shared/schemas/session-event.ts`) antes de serem persistidos.

Persistência é **append-only em `.harness/.local/sessions/<id>.jsonl`** — header na linha 0, eventos nas linhas seguintes, um JSON por linha. O diretório `.harness/.local/` é gitignored por default conforme decisão fechada da SPEC §15: argumentos de tool e paths podem conter informação sensível, então sessões ficam locais à máquina do desenvolvedor. Append-only significa que correções retroativas viram eventos novos, nunca reescrita do arquivo. Toda escrita passa pela API single-writer em `src/sessions/session-store.ts`.

Sessões alimentam `harness.steer.suggest` de forma **indireta**: o steer.suggest consome primariamente o steering log, mas padrões observáveis em sessões (sequências de `tool_call` que sempre precedem um `judge_review` falho, decisões repetidas, intervenções humanas recorrentes no mesmo ponto) entram nas heurísticas de iterações futuras. A sessão é a matéria-prima auditável; o steering log é o sinal pré-agregado.

---

## Steering Loop

O steering loop é o ciclo **human-in-the-loop** descrito na SPEC §8 que fecha o aprendizado sobre o próprio harness: cada execução de sensor ou judge produz evidência estruturada → uma tool agrega essa evidência e propõe melhorias → o humano aprova → o harness ganha um novo guide e fica mais inteligente na execução seguinte. Esse ciclo é o **entregável estratégico do produto** — sem ele, `anyharness` vira mais uma biblioteca de wrappers genéricos sobre ESLint e a Anthropic API. Com ele, o harness evolui junto com o time.

Toda chamada de `sensor.run` e `judge.record` registra um evento no log estruturado em `.harness/.local/steering/log.jsonl`. O log é append-only e tem **único ponto de escrita**: `recordSteeringEvent` em `src/sessions/steering-log.ts`. Sensors e judges não escrevem direto no arquivo — chamam essa função, que valida o evento contra `SteeringEvent` (zod) e anexa. Note que `judge.review` por si só (fase de preparação) não emite evento — só `judge.record`, que carrega o verdict real do cliente.

Formato real do evento conforme SPEC §8 e schema em `src/shared/schemas/steering-event.ts`:

```json
{
  "timestamp": "2026-04-30T14:22:48.901Z",
  "kind": "sensor",
  "id": "eslint",
  "target": "src/auth/signup.ts",
  "regulation": "maintainability",
  "passed": false,
  "inconclusive": false,
  "violationCount": 2,
  "violations": [
    {
      "severity": "error",
      "what": "no-unused-vars",
      "why": "Variável 'token' declarada e nunca usada",
      "remediation": "Remover declaração ou usar a variável",
      "filesAffected": ["src/auth/signup.ts"],
      "linesAffected": [[42, 42]],
      "guideUri": "harness://guides/rules/avoid-unused-vars"
    }
  ]
}
```

`kind` discrimina entre `sensor` e `judge`; ambos compartilham o mesmo envelope.

A tool que consome o log é `harness.steer.suggest`. Ela é o **único caso com prefixo `harness.`** por convenção da spec (decisão fechada §15) — o resto do namespace de tools é flat (`sensor.list`, `judge.review`, `session.start`). O prefixo sinaliza que essa tool reflete sobre o harness inteiro, não sobre um artefato isolado.

Comportamento em `src/steering/suggest.ts`:

- Lê o log filtrando pela janela (`windowDays`, default 30).
- Agrega ocorrências de violation por sensor (`sensorAggregates`) e por judge (`judgeAggregates`).
- Aplica heurísticas determinísticas:
  - **`new-rule`**: sensor que falhou pelo menos 3 vezes cobrindo 3 ou mais `what` distintos vira sugestão de guide consolidado em `harness://guides/rules/avoid-<sensorId>-violations`, com `templateContent` inicial pré-preenchido.
  - **`recurring-judge-flag`**: judge que sinalizou problema 3+ vezes vira sugestão para o humano avaliar se o problema deveria ser pego antes por um sensor computacional ou um guide.
- Retorna `{ suggestions, windowDays, eventCountAnalyzed }` — read-only, **propostas, nunca aplicadas**. Nenhum guide é criado automaticamente.

O ciclo fechado é:

1. Sensors e judges rodam ao longo do desenvolvimento e gravam eventos em `.harness/.local/steering/log.jsonl`.
2. Em algum momento (semanal, ao fim de um workflow, sob demanda), o agente ou o humano chama `harness.steer.suggest`.
3. A tool devolve sugestões estruturadas com `rationale`, `evidence` e `proposedAction` (ex: `createGuide` com `kind`, `suggestedId`, `uri`, `templateContent`).
4. O **humano** revê as sugestões — esse é o passo human-in-the-loop não-negociável.
5. Quando aprovada, a sugestão vira um arquivo concreto em `.harness/guides/rules/<id>.md`, escrito pelo humano (ou por um agente sob direção humana). A próxima execução do servidor MCP descobre o guide via watcher e o expõe como resource `harness://guides/rules/<id>`.

Esse é o ciclo que a Birgitta Böckeler chama de "iterating on the harness": o harness mede o que está dando errado, propõe a regra, o humano aprova, e o conhecimento fica codificado para todas as execuções seguintes.

---

## Workflows

Workflows orquestram sequências de tools/resources/prompts em alto nível — são prompts MCP que orientam o agente a executar uma rotina conhecida (planejar antes de codar, investigar antes de corrigir). Vivem em `.harness/workflows/<id>.md` e são expostos primariamente como `prompts/` MCP (`workflow.PREVC`, `workflow.bug-fix`), com fallback resource `harness://workflows/<id>` para clientes que não suportam `prompts/` (decisão fechada SPEC §15).

Os dois workflows iniciais:

- **`workflow.PREVC`** — Plan, Research, Execute, Verify, Commit. Cobre o caminho padrão de uma feature do zero ao merge.
- **`workflow.bug-fix`** — investigação dirigida por sensor/judge → reproduzir → fix mínimo → spec/regression → completar task.

Para adicionar um workflow novo, crie `.harness/workflows/<id>.md` com instruções de orquestração — o servidor expõe automaticamente como prompt e resource.

---

## Princípios de design

1. **MCP é a única surface.** Tudo que o agente faz com o harness passa por tool/resource/prompt. CLI é conveniência humana, não substituto.
2. **Guides são resources, não prompts.** Conteúdo passivo, lazy-loaded. URIs estáveis em `harness://`.
3. **Sensors e judges são duais.** Computational primeiro (rápido, barato); inferencial quando preciso (semântico).
4. **Contracts atacam behaviour explicitamente.** Spec é feedforward; Task é unidade verificável; `contract.spec.validate` é o teste comportamental.
5. **Sessions persistem o steering loop.** Toda execução de sensor/judge alimenta um log que `harness.steer.suggest` consulta.
6. **Local-first, filesystem-first.** `.harness/` versionável no Git, igual `.context/` do `@dotcontext/cli`.
7. **Judges não chamam LLM no servidor.** `judge.review` devolve prompt+schema+contexto; o cliente MCP conectado faz a inferência; `judge.record` valida pelo schema. Determinismo é do cliente; o servidor garante validação e versionamento do prompt.
8. **Sem lock-in de cliente.** Funciona em Claude Code, Cursor, Codex (qualquer cliente MCP).
9. **Plugável, não monolítico.** Sensor adapters fazem shell-out pra ferramentas existentes (eslint, tsc, semgrep, ArchUnit). Não substitui.
10. **Steering humano é cidadão de primeira classe.** `sensor.register` e `harness.steer.suggest` existem porque o harness evolui.

---

## Conexão com `@dotcontext`

`anyharness` (este MCP) e `@dotcontext/cli` são complementares e podem coexistir:

- `@dotcontext/cli` é o **feedforward** (guides estáticos em `.context/`).
- `anyharness` é o **feedback + execução** (sensors, judges, contracts, sessions em `.harness/`).

Posicionamento na tese "Contexto é o Novo Código": harness engineering é uma forma específica de context engineering, e o MCP é a surface que torna isso operável. O nome `anyharness` reforça a neutralidade de cliente — funciona em Claude Code, Cursor, Codex ou qualquer agente MCP-compatível.

---

## Roadmap e fora de escopo

**No MVP (SPEC §12):**

- Servidor MCP rodando em stdio em <1s cold start.
- Cliente MCP de teste consegue: listar guides, ler guide via URI, listar sensors, rodar sensor, rodar judge, abrir/anexar/recuperar session, ler/validar spec, pegar task, completar task.
- `sensor.run` para 3 adapters reais (eslint, tsc, semgrep) com output normalizado.
- 1 rubric funcional (`spec-adherence`) com prompt versionado e schema; cliente MCP recebe via `judge.review`, executa a review no próprio modelo e registra via `judge.record` com validação por schema.
- `harness.steer.suggest` retorna sugestões coerentes a partir de log com 20+ eventos.
- Funciona em Claude Code com `.mcp.json` simples; testado também em Cursor.

**Fora do escopo do MVP (SPEC §13):**

- Harness templates por topologia (passo seguinte, depois que 2-3 projetos validarem o core).
- UI web (CLI + MCP bastam pro primeiro round).
- Multi-tenant (começa single-repo, igual o `dotcontext` começou).
- Auth/RBAC.
- Multi-judge ensembling.
- Streaming de output do judge.
- Auto-improvement de prompts.
- Sandbox de `sensor.run`.

---

## Referências

- [`SPEC.md`](./SPEC.md) — spec completa, source-of-truth do projeto.
- [`CLAUDE.md`](./CLAUDE.md) — convenções de desenvolvimento e princípios para agentes contribuindo no repo.
- [Model Context Protocol](https://modelcontextprotocol.io) — protocolo subjacente.
- [`@dotcontext/cli`](https://github.com/dotcontext/cli) — projeto irmão, lado feedforward.
